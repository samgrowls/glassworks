import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createapikeyop.js").CreateApiKeyRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createapikeyop.js").CreateApiKeyRequest, unknown>>;
};
export declare const tool$apiKeysCreateAPIKey: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=apiKeysCreateAPIKey.d.ts.map