import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getagentsusingartifactcomponentop.js").GetAgentsUsingArtifactComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getagentsusingartifactcomponentop.js").GetAgentsUsingArtifactComponentRequest, unknown>>;
};
export declare const tool$agentArtifactComponentRelationsGetAgentsUsingArtifactComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentArtifactComponentRelationsGetAgentsUsingArtifactComponent.d.ts.map