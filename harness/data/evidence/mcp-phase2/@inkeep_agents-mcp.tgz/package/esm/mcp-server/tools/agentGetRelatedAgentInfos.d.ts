import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getrelatedagentinfosop.js").GetRelatedAgentInfosRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getrelatedagentinfosop.js").GetRelatedAgentInfosRequest, unknown>>;
};
export declare const tool$agentGetRelatedAgentInfos: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentGetRelatedAgentInfos.d.ts.map