import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/associateartifactcomponentwithagentop.js").AssociateArtifactComponentWithAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/associateartifactcomponentwithagentop.js").AssociateArtifactComponentWithAgentRequest, unknown>>;
};
export declare const tool$agentArtifactComponentRelationsAssociateArtifactComponentWithAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentArtifactComponentRelationsAssociateArtifactComponentWithAgent.d.ts.map