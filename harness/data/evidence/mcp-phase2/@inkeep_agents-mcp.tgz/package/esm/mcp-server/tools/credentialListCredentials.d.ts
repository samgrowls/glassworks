import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listcredentialsop.js").ListCredentialsRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listcredentialsop.js").ListCredentialsRequest, unknown>>;
};
export declare const tool$credentialListCredentials: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialListCredentials.d.ts.map