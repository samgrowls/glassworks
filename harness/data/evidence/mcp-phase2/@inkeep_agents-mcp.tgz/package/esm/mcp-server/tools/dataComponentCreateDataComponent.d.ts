import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createdatacomponentop.js").CreateDataComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createdatacomponentop.js").CreateDataComponentRequest, unknown>>;
};
export declare const tool$dataComponentCreateDataComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=dataComponentCreateDataComponent.d.ts.map