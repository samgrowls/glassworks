import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listapikeysop.js").ListApiKeysRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listapikeysop.js").ListApiKeysRequest, unknown>>;
};
export declare const tool$apiKeysListAPIKeys: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=apiKeysListAPIKeys.d.ts.map