import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/removeartifactcomponentfromagentop.js").RemoveArtifactComponentFromAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/removeartifactcomponentfromagentop.js").RemoveArtifactComponentFromAgentRequest, unknown>>;
};
export declare const tool$agentArtifactComponentRelationsRemoveArtifactComponentFromAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentArtifactComponentRelationsRemoveArtifactComponentFromAgent.d.ts.map