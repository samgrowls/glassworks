import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/checkartifactcomponentagentassociationop.js").CheckArtifactComponentAgentAssociationRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/checkartifactcomponentagentassociationop.js").CheckArtifactComponentAgentAssociationRequest, unknown>>;
};
export declare const tool$agentArtifactComponentRelationsCheckArtifactComponentAgentAssociation: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentArtifactComponentRelationsCheckArtifactComponentAgentAssociation.d.ts.map