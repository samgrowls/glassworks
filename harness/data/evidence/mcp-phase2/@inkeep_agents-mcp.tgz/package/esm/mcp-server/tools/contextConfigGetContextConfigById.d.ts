import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getcontextconfigbyidop.js").GetContextConfigByIdRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getcontextconfigbyidop.js").GetContextConfigByIdRequest, unknown>>;
};
export declare const tool$contextConfigGetContextConfigById: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=contextConfigGetContextConfigById.d.ts.map