import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listartifactcomponentsop.js").ListArtifactComponentsRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listartifactcomponentsop.js").ListArtifactComponentsRequest, unknown>>;
};
export declare const tool$artifactComponentListArtifactComponents: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=artifactComponentListArtifactComponents.d.ts.map