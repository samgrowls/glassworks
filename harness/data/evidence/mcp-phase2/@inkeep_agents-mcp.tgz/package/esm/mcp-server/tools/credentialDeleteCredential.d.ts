import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deletecredentialop.js").DeleteCredentialRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deletecredentialop.js").DeleteCredentialRequest, unknown>>;
};
export declare const tool$credentialDeleteCredential: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialDeleteCredential.d.ts.map