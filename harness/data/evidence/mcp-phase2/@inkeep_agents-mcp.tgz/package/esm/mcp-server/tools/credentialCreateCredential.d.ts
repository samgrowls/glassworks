import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createcredentialop.js").CreateCredentialRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createcredentialop.js").CreateCredentialRequest, unknown>>;
};
export declare const tool$credentialCreateCredential: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialCreateCredential.d.ts.map