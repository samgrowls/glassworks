import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/updatedatacomponentop.js").UpdateDataComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/updatedatacomponentop.js").UpdateDataComponentRequest, unknown>>;
};
export declare const tool$dataComponentUpdateDataComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=dataComponentUpdateDataComponent.d.ts.map