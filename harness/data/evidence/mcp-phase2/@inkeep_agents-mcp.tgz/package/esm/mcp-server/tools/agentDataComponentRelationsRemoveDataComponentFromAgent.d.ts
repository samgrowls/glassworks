import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/removedatacomponentfromagentop.js").RemoveDataComponentFromAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/removedatacomponentfromagentop.js").RemoveDataComponentFromAgentRequest, unknown>>;
};
export declare const tool$agentDataComponentRelationsRemoveDataComponentFromAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentDataComponentRelationsRemoveDataComponentFromAgent.d.ts.map