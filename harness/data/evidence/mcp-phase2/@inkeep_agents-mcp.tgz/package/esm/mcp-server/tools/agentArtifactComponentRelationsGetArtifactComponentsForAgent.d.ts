import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getartifactcomponentsforagentop.js").GetArtifactComponentsForAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getartifactcomponentsforagentop.js").GetArtifactComponentsForAgentRequest, unknown>>;
};
export declare const tool$agentArtifactComponentRelationsGetArtifactComponentsForAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentArtifactComponentRelationsGetArtifactComponentsForAgent.d.ts.map