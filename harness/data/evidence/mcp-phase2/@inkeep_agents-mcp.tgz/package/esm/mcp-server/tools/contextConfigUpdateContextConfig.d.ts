import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/updatecontextconfigop.js").UpdateContextConfigRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/updatecontextconfigop.js").UpdateContextConfigRequest, unknown>>;
};
export declare const tool$contextConfigUpdateContextConfig: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=contextConfigUpdateContextConfig.d.ts.map