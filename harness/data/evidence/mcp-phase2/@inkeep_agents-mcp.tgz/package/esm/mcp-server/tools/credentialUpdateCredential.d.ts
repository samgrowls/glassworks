import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/updatecredentialop.js").UpdateCredentialRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/updatecredentialop.js").UpdateCredentialRequest, unknown>>;
};
export declare const tool$credentialUpdateCredential: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialUpdateCredential.d.ts.map