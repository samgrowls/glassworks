import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getagentsusingdatacomponentop.js").GetAgentsUsingDataComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getagentsusingdatacomponentop.js").GetAgentsUsingDataComponentRequest, unknown>>;
};
export declare const tool$agentDataComponentRelationsGetAgentsUsingDataComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentDataComponentRelationsGetAgentsUsingDataComponent.d.ts.map