import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getbranchop.js").GetBranchRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getbranchop.js").GetBranchRequest, unknown>>;
};
export declare const tool$branchesGetBranch: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=branchesGetBranch.d.ts.map