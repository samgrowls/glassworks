import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createcontextconfigop.js").CreateContextConfigRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createcontextconfigop.js").CreateContextConfigRequest, unknown>>;
};
export declare const tool$contextConfigCreateContextConfig: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=contextConfigCreateContextConfig.d.ts.map