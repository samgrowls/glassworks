import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getdatacomponentsforagentop.js").GetDataComponentsForAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getdatacomponentsforagentop.js").GetDataComponentsForAgentRequest, unknown>>;
};
export declare const tool$agentDataComponentRelationsGetDataComponentsForAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentDataComponentRelationsGetDataComponentsForAgent.d.ts.map