import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/updateapikeyop.js").UpdateApiKeyRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/updateapikeyop.js").UpdateApiKeyRequest, unknown>>;
};
export declare const tool$apiKeysUpdateAPIKey: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=apiKeysUpdateAPIKey.d.ts.map