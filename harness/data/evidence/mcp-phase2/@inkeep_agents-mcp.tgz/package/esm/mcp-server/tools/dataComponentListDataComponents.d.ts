import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listdatacomponentsop.js").ListDataComponentsRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listdatacomponentsop.js").ListDataComponentsRequest, unknown>>;
};
export declare const tool$dataComponentListDataComponents: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=dataComponentListDataComponents.d.ts.map