import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getdatacomponentbyidop.js").GetDataComponentByIdRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getdatacomponentbyidop.js").GetDataComponentByIdRequest, unknown>>;
};
export declare const tool$dataComponentGetDataComponentById: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=dataComponentGetDataComponentById.d.ts.map