import { ToolDefinition } from "../tools.js";
export declare const tool$capabilities: ToolDefinition;
//# sourceMappingURL=capabilities.d.ts.map