import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/associatedatacomponentwithagentop.js").AssociateDataComponentWithAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/associatedatacomponentwithagentop.js").AssociateDataComponentWithAgentRequest, unknown>>;
};
export declare const tool$agentDataComponentRelationsAssociateDataComponentWithAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentDataComponentRelationsAssociateDataComponentWithAgent.d.ts.map