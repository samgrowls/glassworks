import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listagentsop.js").ListAgentsRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listagentsop.js").ListAgentsRequest, unknown>>;
};
export declare const tool$agentsListAgents: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentsListAgents.d.ts.map