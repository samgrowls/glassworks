import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createbranchop.js").CreateBranchRequestRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createbranchop.js").CreateBranchRequestRequest, unknown>>;
};
export declare const tool$branchesCreateBranch: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=branchesCreateBranch.d.ts.map