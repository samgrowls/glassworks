import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deletebranchop.js").DeleteBranchRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deletebranchop.js").DeleteBranchRequest, unknown>>;
};
export declare const tool$branchesDeleteBranch: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=branchesDeleteBranch.d.ts.map