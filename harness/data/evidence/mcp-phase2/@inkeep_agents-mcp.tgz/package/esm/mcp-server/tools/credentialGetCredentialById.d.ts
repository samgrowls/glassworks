import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getcredentialbyidop.js").GetCredentialByIdRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getcredentialbyidop.js").GetCredentialByIdRequest, unknown>>;
};
export declare const tool$credentialGetCredentialById: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialGetCredentialById.d.ts.map