import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getfullagentdefinitionop.js").GetFullAgentDefinitionRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getfullagentdefinitionop.js").GetFullAgentDefinitionRequest, unknown>>;
};
export declare const tool$agentGetFullAgentDefinition: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentGetFullAgentDefinition.d.ts.map