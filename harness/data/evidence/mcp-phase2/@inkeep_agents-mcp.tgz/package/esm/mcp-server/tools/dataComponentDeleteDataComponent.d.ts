import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deletedatacomponentop.js").DeleteDataComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deletedatacomponentop.js").DeleteDataComponentRequest, unknown>>;
};
export declare const tool$dataComponentDeleteDataComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=dataComponentDeleteDataComponent.d.ts.map