import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deleteapikeyop.js").DeleteApiKeyRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deleteapikeyop.js").DeleteApiKeyRequest, unknown>>;
};
export declare const tool$apiKeysDeleteAPIKey: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=apiKeysDeleteAPIKey.d.ts.map