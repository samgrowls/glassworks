import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createartifactcomponentop.js").CreateArtifactComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createartifactcomponentop.js").CreateArtifactComponentRequest, unknown>>;
};
export declare const tool$artifactComponentCreateArtifactComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=artifactComponentCreateArtifactComponent.d.ts.map