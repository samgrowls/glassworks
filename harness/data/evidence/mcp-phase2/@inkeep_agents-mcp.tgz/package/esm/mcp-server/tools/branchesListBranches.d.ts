import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listbranchesop.js").ListBranchesRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listbranchesop.js").ListBranchesRequest, unknown>>;
};
export declare const tool$branchesListBranches: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=branchesListBranches.d.ts.map