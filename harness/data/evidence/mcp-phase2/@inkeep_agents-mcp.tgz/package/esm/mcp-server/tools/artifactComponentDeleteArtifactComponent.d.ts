import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deleteartifactcomponentop.js").DeleteArtifactComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deleteartifactcomponentop.js").DeleteArtifactComponentRequest, unknown>>;
};
export declare const tool$artifactComponentDeleteArtifactComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=artifactComponentDeleteArtifactComponent.d.ts.map