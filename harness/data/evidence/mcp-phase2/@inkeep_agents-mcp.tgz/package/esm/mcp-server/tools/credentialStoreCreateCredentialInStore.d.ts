import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/createcredentialinstoreop.js").CreateCredentialInStoreRequestRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/createcredentialinstoreop.js").CreateCredentialInStoreRequestRequest, unknown>>;
};
export declare const tool$credentialStoreCreateCredentialInStore: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialStoreCreateCredentialInStore.d.ts.map