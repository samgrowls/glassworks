import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listcontextconfigsop.js").ListContextConfigsRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listcontextconfigsop.js").ListContextConfigsRequest, unknown>>;
};
export declare const tool$contextConfigListContextConfigs: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=contextConfigListContextConfigs.d.ts.map