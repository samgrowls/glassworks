import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/deletecontextconfigop.js").DeleteContextConfigRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/deletecontextconfigop.js").DeleteContextConfigRequest, unknown>>;
};
export declare const tool$contextConfigDeleteContextConfig: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=contextConfigDeleteContextConfig.d.ts.map