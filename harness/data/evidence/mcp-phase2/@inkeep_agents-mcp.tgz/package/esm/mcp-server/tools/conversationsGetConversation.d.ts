import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getconversationop.js").GetConversationRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getconversationop.js").GetConversationRequest, unknown>>;
};
export declare const tool$conversationsGetConversation: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=conversationsGetConversation.d.ts.map