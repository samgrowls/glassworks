import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/updateartifactcomponentop.js").UpdateArtifactComponentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/updateartifactcomponentop.js").UpdateArtifactComponentRequest, unknown>>;
};
export declare const tool$artifactComponentUpdateArtifactComponent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=artifactComponentUpdateArtifactComponent.d.ts.map