import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listbranchesforagentop.js").ListBranchesForAgentRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listbranchesforagentop.js").ListBranchesForAgentRequest, unknown>>;
};
export declare const tool$branchesListBranchesForAgent: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=branchesListBranchesForAgent.d.ts.map