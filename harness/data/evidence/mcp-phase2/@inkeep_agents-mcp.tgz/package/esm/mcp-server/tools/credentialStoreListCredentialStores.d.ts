import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/listcredentialstoresop.js").ListCredentialStoresRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/listcredentialstoresop.js").ListCredentialStoresRequest, unknown>>;
};
export declare const tool$credentialStoreListCredentialStores: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=credentialStoreListCredentialStores.d.ts.map