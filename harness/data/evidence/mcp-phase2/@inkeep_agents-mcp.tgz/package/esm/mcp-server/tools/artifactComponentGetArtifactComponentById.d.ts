import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getartifactcomponentbyidop.js").GetArtifactComponentByIdRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getartifactcomponentbyidop.js").GetArtifactComponentByIdRequest, unknown>>;
};
export declare const tool$artifactComponentGetArtifactComponentById: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=artifactComponentGetArtifactComponentById.d.ts.map