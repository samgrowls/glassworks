import { ToolDefinition } from "../tools.js";
export declare const tool$cliGetManageApiCliMe: ToolDefinition;
//# sourceMappingURL=cliGetManageApiCliMe.d.ts.map