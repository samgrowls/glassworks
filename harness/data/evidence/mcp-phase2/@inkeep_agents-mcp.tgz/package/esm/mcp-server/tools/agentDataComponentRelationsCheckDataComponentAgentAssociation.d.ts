import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/checkdatacomponentagentassociationop.js").CheckDataComponentAgentAssociationRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/checkdatacomponentagentassociationop.js").CheckDataComponentAgentAssociationRequest, unknown>>;
};
export declare const tool$agentDataComponentRelationsCheckDataComponentAgentAssociation: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=agentDataComponentRelationsCheckDataComponentAgentAssociation.d.ts.map