import { ToolDefinition } from "../tools.js";
declare const args: {
    request: import("zod").ZodType<import("../../models/getapikeybyidop.js").GetApiKeyByIdRequest, unknown, import("zod/v4/core").$ZodTypeInternals<import("../../models/getapikeybyidop.js").GetApiKeyByIdRequest, unknown>>;
};
export declare const tool$apiKeysGetAPIKeyById: ToolDefinition<typeof args>;
export {};
//# sourceMappingURL=apiKeysGetAPIKeyById.d.ts.map