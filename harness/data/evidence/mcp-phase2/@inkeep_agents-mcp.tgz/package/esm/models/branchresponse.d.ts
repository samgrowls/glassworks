import * as z from "zod";
import { BranchInfo } from "./branchinfo.js";
export type BranchResponse = {
    data: BranchInfo;
};
export declare const BranchResponse$zodSchema: z.ZodType<BranchResponse>;
//# sourceMappingURL=branchresponse.d.ts.map