import * as z from "zod";
export type DatasetItemCreate = {
    input?: any | null | undefined;
    expectedOutput?: any | null | undefined;
    simulationAgent?: any | null | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const DatasetItemCreate$zodSchema: z.ZodType<DatasetItemCreate>;
//# sourceMappingURL=datasetitemcreate.d.ts.map