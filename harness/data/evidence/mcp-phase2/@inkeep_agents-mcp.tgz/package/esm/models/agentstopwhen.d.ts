import * as z from "zod";
export type AgentStopWhen = {
    transferCountIs?: number | undefined;
};
export declare const AgentStopWhen$zodSchema: z.ZodType<AgentStopWhen>;
//# sourceMappingURL=agentstopwhen.d.ts.map