import * as z from "zod";
import { ComponentAssociation } from "./componentassociation.js";
export type ComponentAssociationListResponse = {
    data: Array<ComponentAssociation>;
};
export declare const ComponentAssociationListResponse$zodSchema: z.ZodType<ComponentAssociationListResponse>;
//# sourceMappingURL=componentassociationlistresponse.d.ts.map