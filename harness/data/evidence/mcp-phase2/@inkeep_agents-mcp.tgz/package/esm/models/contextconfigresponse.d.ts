import * as z from "zod";
import { ContextConfig } from "./contextconfig.js";
export type ContextConfigResponse = {
    data: ContextConfig;
};
export declare const ContextConfigResponse$zodSchema: z.ZodType<ContextConfigResponse>;
//# sourceMappingURL=contextconfigresponse.d.ts.map