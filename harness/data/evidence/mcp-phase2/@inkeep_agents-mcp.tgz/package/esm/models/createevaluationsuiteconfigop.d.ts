import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { EvaluationSuiteConfig } from "./evaluationsuiteconfig.js";
import { EvaluationSuiteConfigCreate } from "./evaluationsuiteconfigcreate.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateEvaluationSuiteConfigRequest = {
    tenantId: string;
    projectId: string;
    body?: EvaluationSuiteConfigCreate | undefined;
};
export declare const CreateEvaluationSuiteConfigRequest$zodSchema: z.ZodType<CreateEvaluationSuiteConfigRequest>;
/**
 * Evaluation suite config created
 */
export type CreateEvaluationSuiteConfigResponseBody = {
    data: EvaluationSuiteConfig;
};
export declare const CreateEvaluationSuiteConfigResponseBody$zodSchema: z.ZodType<CreateEvaluationSuiteConfigResponseBody>;
export type CreateEvaluationSuiteConfigResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: CreateEvaluationSuiteConfigResponseBody | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateEvaluationSuiteConfigResponse$zodSchema: z.ZodType<CreateEvaluationSuiteConfigResponse>;
//# sourceMappingURL=createevaluationsuiteconfigop.d.ts.map