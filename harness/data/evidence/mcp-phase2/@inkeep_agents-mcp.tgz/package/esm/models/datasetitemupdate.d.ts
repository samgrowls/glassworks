import * as z from "zod";
export type DatasetItemUpdate = {
    input?: any | null | undefined;
    expectedOutput?: any | null | undefined;
    simulationAgent?: any | null | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const DatasetItemUpdate$zodSchema: z.ZodType<DatasetItemUpdate>;
//# sourceMappingURL=datasetitemupdate.d.ts.map