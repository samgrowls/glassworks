import * as z from "zod";
import { ErrorResponse } from "./errorresponse.js";
export type DeleteSubAgentTeamAgentRelationRequest = {
    tenantId: string;
    projectId: string;
    agentId: string;
    subAgentId: string;
    id: string;
};
export declare const DeleteSubAgentTeamAgentRelationRequest$zodSchema: z.ZodType<DeleteSubAgentTeamAgentRelationRequest>;
export type DeleteSubAgentTeamAgentRelationResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    ErrorResponse?: ErrorResponse | undefined;
};
export declare const DeleteSubAgentTeamAgentRelationResponse$zodSchema: z.ZodType<DeleteSubAgentTeamAgentRelationResponse>;
//# sourceMappingURL=deletesubagentteamagentrelationop.d.ts.map