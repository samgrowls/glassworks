import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * A short code indicating the error code returned.
 */
export declare const BadRequestCode1: {
    readonly BadRequest: "bad_request";
};
/**
 * A short code indicating the error code returned.
 */
export type BadRequestCode1 = ClosedEnum<typeof BadRequestCode1>;
export declare const BadRequestCode1$zodSchema: z.ZodEnum<{
    bad_request: "bad_request";
}>;
/**
 * A short code indicating the error code returned.
 */
export declare const BadRequestCode2: {
    readonly BadRequest: "bad_request";
};
/**
 * A short code indicating the error code returned.
 */
export type BadRequestCode2 = ClosedEnum<typeof BadRequestCode2>;
export declare const BadRequestCode2$zodSchema: z.ZodEnum<{
    bad_request: "bad_request";
}>;
/**
 * Legacy error format for backward compatibility.
 */
export type BadRequestError = {
    code: BadRequestCode2;
    message: string;
};
export declare const BadRequestError$zodSchema: z.ZodType<BadRequestError>;
export type BadRequest = {
    title: string;
    status: number;
    detail: string;
    instance?: string | undefined;
    requestId?: string | undefined;
    code: BadRequestCode1;
    error: BadRequestError;
};
export declare const BadRequest$zodSchema: z.ZodType<BadRequest>;
//# sourceMappingURL=badrequest.d.ts.map