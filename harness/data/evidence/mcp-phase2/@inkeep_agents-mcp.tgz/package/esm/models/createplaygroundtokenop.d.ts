import * as z from "zod";
import { ErrorResponse } from "./errorresponse.js";
export type CreatePlaygroundTokenSecurity = {
    cookieAuth: string;
};
export declare const CreatePlaygroundTokenSecurity$zodSchema: z.ZodType<CreatePlaygroundTokenSecurity>;
export type CreatePlaygroundTokenRequestBody = {
    projectId: string;
    agentId: string;
};
export declare const CreatePlaygroundTokenRequestBody$zodSchema: z.ZodType<CreatePlaygroundTokenRequestBody>;
export type CreatePlaygroundTokenRequest = {
    tenantId: string;
    body?: CreatePlaygroundTokenRequestBody | undefined;
};
export declare const CreatePlaygroundTokenRequest$zodSchema: z.ZodType<CreatePlaygroundTokenRequest>;
/**
 * Temporary API key generated successfully
 */
export type CreatePlaygroundTokenResponseBody = {
    apiKey: string;
    expiresAt: string;
};
export declare const CreatePlaygroundTokenResponseBody$zodSchema: z.ZodType<CreatePlaygroundTokenResponseBody>;
export type CreatePlaygroundTokenResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: CreatePlaygroundTokenResponseBody | undefined;
    ErrorResponse?: ErrorResponse | undefined;
};
export declare const CreatePlaygroundTokenResponse$zodSchema: z.ZodType<CreatePlaygroundTokenResponse>;
//# sourceMappingURL=createplaygroundtokenop.d.ts.map