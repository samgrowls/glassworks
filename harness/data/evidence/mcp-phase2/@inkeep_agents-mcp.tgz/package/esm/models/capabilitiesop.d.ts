import * as z from "zod";
import { CapabilitiesResponseSchema } from "./capabilitiesresponseschema.js";
export type CapabilitiesResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    CapabilitiesResponseSchema?: CapabilitiesResponseSchema | undefined;
};
export declare const CapabilitiesResponse$zodSchema: z.ZodType<CapabilitiesResponse>;
//# sourceMappingURL=capabilitiesop.d.ts.map