import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { EvaluationJobConfig } from "./evaluationjobconfig.js";
import { EvaluationJobConfigCreate } from "./evaluationjobconfigcreate.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateEvaluationJobConfigRequest = {
    tenantId: string;
    projectId: string;
    body?: EvaluationJobConfigCreate | undefined;
};
export declare const CreateEvaluationJobConfigRequest$zodSchema: z.ZodType<CreateEvaluationJobConfigRequest>;
/**
 * Evaluation job config created
 */
export type CreateEvaluationJobConfigResponseBody = {
    data: EvaluationJobConfig;
};
export declare const CreateEvaluationJobConfigResponseBody$zodSchema: z.ZodType<CreateEvaluationJobConfigResponseBody>;
export type CreateEvaluationJobConfigResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: CreateEvaluationJobConfigResponseBody | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateEvaluationJobConfigResponse$zodSchema: z.ZodType<CreateEvaluationJobConfigResponse>;
//# sourceMappingURL=createevaluationjobconfigop.d.ts.map