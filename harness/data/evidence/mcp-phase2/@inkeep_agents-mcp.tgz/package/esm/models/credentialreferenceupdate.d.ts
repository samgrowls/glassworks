import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
export declare const CredentialReferenceUpdateType: {
    readonly Memory: "memory";
    readonly Keychain: "keychain";
    readonly Nango: "nango";
};
export type CredentialReferenceUpdateType = ClosedEnum<typeof CredentialReferenceUpdateType>;
export declare const CredentialReferenceUpdateType$zodSchema: z.ZodEnum<{
    memory: "memory";
    keychain: "keychain";
    nango: "nango";
}>;
export type CredentialReferenceUpdate = {
    id?: string | undefined;
    name?: string | undefined;
    type?: CredentialReferenceUpdateType | undefined;
    credentialStoreId?: string | undefined;
    retrievalParams?: {
        [k: string]: any | null;
    } | null | undefined;
    toolId?: string | null | undefined;
    userId?: string | null | undefined;
    createdBy?: string | null | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const CredentialReferenceUpdate$zodSchema: z.ZodType<CredentialReferenceUpdate>;
//# sourceMappingURL=credentialreferenceupdate.d.ts.map