import * as z from "zod";
import { ExternalAgent } from "./externalagent.js";
import { FullAgentSubAgentSelectWithRelationIds } from "./fullagentsubagentselectwithrelationids.js";
import { FunctionT } from "./function.js";
import { FunctionTool } from "./functiontool.js";
import { ModelSettings } from "./modelsettings.js";
import { StatusComponent } from "./statuscomponent.js";
import { TeamAgent } from "./teamagent.js";
import { Tool } from "./tool.js";
export type AgentWithinContextOfProjectSelectWithRelationIdsModels = {
    base?: ModelSettings | undefined;
    structuredOutput?: ModelSettings | undefined;
    summarizer?: ModelSettings | undefined;
};
export declare const AgentWithinContextOfProjectSelectWithRelationIdsModels$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIdsModels>;
export type AgentWithinContextOfProjectSelectWithRelationIdsStatusUpdates = {
    enabled?: boolean | undefined;
    numEvents?: number | undefined;
    timeInSeconds?: number | undefined;
    prompt?: string | undefined;
    statusComponents?: Array<StatusComponent> | undefined;
};
export declare const AgentWithinContextOfProjectSelectWithRelationIdsStatusUpdates$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIdsStatusUpdates>;
export type AgentWithinContextOfProjectSelectWithRelationIdsStopWhen = {
    transferCountIs?: number | undefined;
};
export declare const AgentWithinContextOfProjectSelectWithRelationIdsStopWhen$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIdsStopWhen>;
/**
 * JSON Schema for validating request headers
 */
export type AgentWithinContextOfProjectSelectWithRelationIdsHeadersSchema = {};
export declare const AgentWithinContextOfProjectSelectWithRelationIdsHeadersSchema$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIdsHeadersSchema>;
export type AgentWithinContextOfProjectSelectWithRelationIdsContextConfig = {
    id: string;
    headersSchema?: AgentWithinContextOfProjectSelectWithRelationIdsHeadersSchema | undefined;
    contextVariables?: any | null | undefined;
    createdAt: string;
    updatedAt: string;
};
export declare const AgentWithinContextOfProjectSelectWithRelationIdsContextConfig$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIdsContextConfig>;
export type AgentWithinContextOfProjectSelectWithRelationIds = {
    id: string;
    name: string;
    description: string | null;
    defaultSubAgentId: string | null;
    contextConfigId: string | null;
    models: AgentWithinContextOfProjectSelectWithRelationIdsModels | null;
    statusUpdates: AgentWithinContextOfProjectSelectWithRelationIdsStatusUpdates | null;
    prompt: string | null;
    stopWhen: AgentWithinContextOfProjectSelectWithRelationIdsStopWhen | null;
    createdAt: string;
    updatedAt: string;
    subAgents: {
        [k: string]: FullAgentSubAgentSelectWithRelationIds;
    };
    tools: {
        [k: string]: Tool;
    } | null;
    externalAgents: {
        [k: string]: ExternalAgent;
    } | null;
    teamAgents: {
        [k: string]: TeamAgent;
    } | null;
    functionTools: {
        [k: string]: FunctionTool;
    } | null;
    functions: {
        [k: string]: FunctionT;
    } | null;
    contextConfig: AgentWithinContextOfProjectSelectWithRelationIdsContextConfig | null;
};
export declare const AgentWithinContextOfProjectSelectWithRelationIds$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectWithRelationIds>;
//# sourceMappingURL=agentwithincontextofprojectselectwithrelationids.d.ts.map