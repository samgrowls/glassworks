import * as z from "zod";
import { Agent } from "./agent.js";
export type AgentResponse = {
    data: Agent;
};
export declare const AgentResponse$zodSchema: z.ZodType<AgentResponse>;
//# sourceMappingURL=agentresponse.d.ts.map