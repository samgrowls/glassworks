import * as z from "zod";
export type ArtifactComponent = {
    id: string;
    name: string;
    description: string | null;
    props?: any | null | undefined;
    render?: any | null | undefined;
    createdAt: string;
    updatedAt: string;
};
export declare const ArtifactComponent$zodSchema: z.ZodType<ArtifactComponent>;
//# sourceMappingURL=artifactcomponent.d.ts.map