import * as z from "zod";
import { ArtifactComponent } from "./artifactcomponent.js";
export type ArtifactComponentArrayResponse = {
    data: Array<ArtifactComponent>;
};
export declare const ArtifactComponentArrayResponse$zodSchema: z.ZodType<ArtifactComponentArrayResponse>;
//# sourceMappingURL=artifactcomponentarrayresponse.d.ts.map