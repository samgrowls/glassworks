import * as z from "zod";
export type CanDelegateToTeamAgentInsert = {
    agentId: string;
    subAgentTeamAgentRelationId?: string | undefined;
    headers?: {
        [k: string]: string;
    } | null | undefined;
};
export declare const CanDelegateToTeamAgentInsert$zodSchema: z.ZodType<CanDelegateToTeamAgentInsert>;
//# sourceMappingURL=candelegatetoteamagentinsert.d.ts.map