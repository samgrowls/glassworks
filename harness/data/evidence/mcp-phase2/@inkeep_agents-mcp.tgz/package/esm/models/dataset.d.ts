import * as z from "zod";
export type Dataset = {
    id: string;
    name: string;
    createdAt: string;
    updatedAt: string;
};
export declare const Dataset$zodSchema: z.ZodType<Dataset>;
//# sourceMappingURL=dataset.d.ts.map