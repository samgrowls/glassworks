import * as z from "zod";
export type DatasetRunItem = {
    id?: string | undefined;
    input?: any | null | undefined;
    expectedOutput?: any | null | undefined;
    simulationAgent?: any | null | undefined;
    agentId: string;
};
export declare const DatasetRunItem$zodSchema: z.ZodType<DatasetRunItem>;
//# sourceMappingURL=datasetrunitem.d.ts.map