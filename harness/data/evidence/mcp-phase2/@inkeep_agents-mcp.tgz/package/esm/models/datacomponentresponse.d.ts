import * as z from "zod";
import { DataComponent } from "./datacomponent.js";
export type DataComponentResponse = {
    data: DataComponent;
};
export declare const DataComponentResponse$zodSchema: z.ZodType<DataComponentResponse>;
//# sourceMappingURL=datacomponentresponse.d.ts.map