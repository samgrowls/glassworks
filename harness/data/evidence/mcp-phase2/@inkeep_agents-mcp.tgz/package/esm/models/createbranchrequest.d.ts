import * as z from "zod";
export type CreateBranchRequest = {
    name: string;
    from?: string | undefined;
};
export declare const CreateBranchRequest$zodSchema: z.ZodType<CreateBranchRequest>;
//# sourceMappingURL=createbranchrequest.d.ts.map