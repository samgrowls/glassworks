import * as z from "zod";
import { CredentialStore } from "./credentialstore.js";
export type CredentialStoreListResponse = {
    data: Array<CredentialStore>;
};
export declare const CredentialStoreListResponse$zodSchema: z.ZodType<CredentialStoreListResponse>;
//# sourceMappingURL=credentialstorelistresponse.d.ts.map