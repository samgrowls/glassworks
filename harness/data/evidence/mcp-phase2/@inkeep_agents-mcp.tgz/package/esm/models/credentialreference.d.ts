import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
export declare const CredentialReferenceType: {
    readonly Memory: "memory";
    readonly Keychain: "keychain";
    readonly Nango: "nango";
};
export type CredentialReferenceType = ClosedEnum<typeof CredentialReferenceType>;
export declare const CredentialReferenceType$zodSchema: z.ZodEnum<{
    memory: "memory";
    keychain: "keychain";
    nango: "nango";
}>;
export type CredentialReferenceTool = {
    tenantId: string;
    id: string;
    projectId: string;
    name: string;
    description: string | null;
    config?: any | null | undefined;
    credentialReferenceId: string | null;
    credentialScope: string;
    headers?: any | null | undefined;
    imageUrl: string | null;
    capabilities?: any | null | undefined;
    lastError: string | null;
    createdAt: string;
    updatedAt: string;
};
export declare const CredentialReferenceTool$zodSchema: z.ZodType<CredentialReferenceTool>;
export type CredentialReferenceExternalAgent = {
    tenantId: string;
    id: string;
    projectId: string;
    name: string;
    description: string | null;
    baseUrl: string;
    credentialReferenceId?: string | null | undefined;
    createdAt: string;
    updatedAt: string;
};
export declare const CredentialReferenceExternalAgent$zodSchema: z.ZodType<CredentialReferenceExternalAgent>;
export type CredentialReference = {
    id: string;
    name: string;
    type: CredentialReferenceType;
    credentialStoreId: string;
    retrievalParams?: any | null | undefined;
    toolId: string | null;
    userId: string | null;
    createdBy: string | null;
    createdAt: string;
    updatedAt: string;
    tools?: Array<CredentialReferenceTool> | undefined;
    externalAgents?: Array<CredentialReferenceExternalAgent> | undefined;
};
export declare const CredentialReference$zodSchema: z.ZodType<CredentialReference>;
//# sourceMappingURL=credentialreference.d.ts.map