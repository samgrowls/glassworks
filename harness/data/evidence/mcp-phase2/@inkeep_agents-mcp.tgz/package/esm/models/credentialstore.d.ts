import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
export declare const CredentialStoreType: {
    readonly Memory: "memory";
    readonly Keychain: "keychain";
    readonly Nango: "nango";
};
export type CredentialStoreType = ClosedEnum<typeof CredentialStoreType>;
export declare const CredentialStoreType$zodSchema: z.ZodEnum<{
    memory: "memory";
    keychain: "keychain";
    nango: "nango";
}>;
export type CredentialStore = {
    id: string;
    type: CredentialStoreType;
    available: boolean;
    reason: string | null;
};
export declare const CredentialStore$zodSchema: z.ZodType<CredentialStore>;
//# sourceMappingURL=credentialstore.d.ts.map