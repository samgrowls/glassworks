import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * The configured sandbox provider, if enabled.
 */
export declare const Provider: {
    readonly Native: "native";
    readonly Vercel: "vercel";
};
/**
 * The configured sandbox provider, if enabled.
 */
export type Provider = ClosedEnum<typeof Provider>;
export declare const Provider$zodSchema: z.ZodEnum<{
    native: "native";
    vercel: "vercel";
}>;
/**
 * The configured sandbox runtime, if enabled.
 */
export declare const Runtime: {
    readonly Node22: "node22";
    readonly Typescript: "typescript";
};
/**
 * The configured sandbox runtime, if enabled.
 */
export type Runtime = ClosedEnum<typeof Runtime>;
export declare const Runtime$zodSchema: z.ZodEnum<{
    typescript: "typescript";
    node22: "node22";
}>;
/**
 * Sandbox execution capabilities (used by Function Tools).
 */
export type Sandbox = {
    configured: boolean;
    provider?: Provider | undefined;
    runtime?: Runtime | undefined;
};
export declare const Sandbox$zodSchema: z.ZodType<Sandbox>;
/**
 * Optional server capabilities and configuration.
 */
export type CapabilitiesResponseSchema = {
    sandbox: Sandbox;
};
export declare const CapabilitiesResponseSchema$zodSchema: z.ZodType<CapabilitiesResponseSchema>;
//# sourceMappingURL=capabilitiesresponseschema.d.ts.map