import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { BranchResponse } from "./branchresponse.js";
import { CreateBranchRequest } from "./createbranchrequest.js";
import { ErrorResponse } from "./errorresponse.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateBranchRequestRequest = {
    tenantId: string;
    projectId: string;
    body?: CreateBranchRequest | undefined;
};
export declare const CreateBranchRequestRequest$zodSchema: z.ZodType<CreateBranchRequestRequest>;
export type CreateBranchResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    BranchResponse?: BranchResponse | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    ErrorResponse?: ErrorResponse | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateBranchResponse$zodSchema: z.ZodType<CreateBranchResponse>;
//# sourceMappingURL=createbranchop.d.ts.map