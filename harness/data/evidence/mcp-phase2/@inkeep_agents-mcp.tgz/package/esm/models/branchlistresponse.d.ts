import * as z from "zod";
import { BranchInfo } from "./branchinfo.js";
export type BranchListResponse = {
    data: Array<BranchInfo>;
};
export declare const BranchListResponse$zodSchema: z.ZodType<BranchListResponse>;
//# sourceMappingURL=branchlistresponse.d.ts.map