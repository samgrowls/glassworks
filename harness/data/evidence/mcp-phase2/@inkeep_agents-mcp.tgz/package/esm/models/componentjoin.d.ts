import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
/**
 * Strategy for joining components
 */
export declare const Strategy: {
    readonly Concatenate: "concatenate";
};
/**
 * Strategy for joining components
 */
export type Strategy = ClosedEnum<typeof Strategy>;
export declare const Strategy$zodSchema: z.ZodEnum<{
    concatenate: "concatenate";
}>;
/**
 * How to join signed components
 */
export type ComponentJoin = {
    strategy: Strategy;
    separator: string;
};
export declare const ComponentJoin$zodSchema: z.ZodType<ComponentJoin>;
//# sourceMappingURL=componentjoin.d.ts.map