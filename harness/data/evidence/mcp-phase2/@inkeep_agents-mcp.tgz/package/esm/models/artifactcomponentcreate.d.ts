import * as z from "zod";
export type ArtifactComponentCreate = {
    id: string;
    name: string;
    description?: string | null | undefined;
    props?: any | null | undefined;
    render?: any | null | undefined;
};
export declare const ArtifactComponentCreate$zodSchema: z.ZodType<ArtifactComponentCreate>;
//# sourceMappingURL=artifactcomponentcreate.d.ts.map