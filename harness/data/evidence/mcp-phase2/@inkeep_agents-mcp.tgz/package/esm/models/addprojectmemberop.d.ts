import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
import { BadRequest } from "./badrequest.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export declare const AddProjectMemberRoleRequest: {
    readonly ProjectAdmin: "project_admin";
    readonly ProjectMember: "project_member";
    readonly ProjectViewer: "project_viewer";
};
export type AddProjectMemberRoleRequest = ClosedEnum<typeof AddProjectMemberRoleRequest>;
export declare const AddProjectMemberRoleRequest$zodSchema: z.ZodEnum<{
    project_admin: "project_admin";
    project_member: "project_member";
    project_viewer: "project_viewer";
}>;
export type AddProjectMemberRequestBody = {
    userId: string;
    role: AddProjectMemberRoleRequest;
};
export declare const AddProjectMemberRequestBody$zodSchema: z.ZodType<AddProjectMemberRequestBody>;
export type AddProjectMemberRequest = {
    tenantId: string;
    projectId: string;
    body?: AddProjectMemberRequestBody | undefined;
};
export declare const AddProjectMemberRequest$zodSchema: z.ZodType<AddProjectMemberRequest>;
export declare const AddProjectMemberRoleResponse: {
    readonly ProjectAdmin: "project_admin";
    readonly ProjectMember: "project_member";
    readonly ProjectViewer: "project_viewer";
};
export type AddProjectMemberRoleResponse = ClosedEnum<typeof AddProjectMemberRoleResponse>;
export declare const AddProjectMemberRoleResponse$zodSchema: z.ZodEnum<{
    project_admin: "project_admin";
    project_member: "project_member";
    project_viewer: "project_viewer";
}>;
export type AddProjectMemberData = {
    userId: string;
    role: AddProjectMemberRoleResponse;
    projectId: string;
};
export declare const AddProjectMemberData$zodSchema: z.ZodType<AddProjectMemberData>;
/**
 * Member added successfully
 */
export type AddProjectMemberResponseBody = {
    data: AddProjectMemberData;
};
export declare const AddProjectMemberResponseBody$zodSchema: z.ZodType<AddProjectMemberResponseBody>;
export type AddProjectMemberResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: AddProjectMemberResponseBody | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const AddProjectMemberResponse$zodSchema: z.ZodType<AddProjectMemberResponse>;
//# sourceMappingURL=addprojectmemberop.d.ts.map