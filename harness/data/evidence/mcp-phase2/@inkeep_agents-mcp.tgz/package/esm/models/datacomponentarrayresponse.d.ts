import * as z from "zod";
import { DataComponent } from "./datacomponent.js";
export type DataComponentArrayResponse = {
    data: Array<DataComponent>;
};
export declare const DataComponentArrayResponse$zodSchema: z.ZodType<DataComponentArrayResponse>;
//# sourceMappingURL=datacomponentarrayresponse.d.ts.map