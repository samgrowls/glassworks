import * as z from "zod";
export type DatasetUpdate = {
    name?: string | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const DatasetUpdate$zodSchema: z.ZodType<DatasetUpdate>;
//# sourceMappingURL=datasetupdate.d.ts.map