import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { ExistsResponse } from "./existsresponse.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CheckFunctionToolSubAgentAssociationRequest = {
    tenantId: string;
    projectId: string;
    agentId: string;
    subAgentId: string;
    functionToolId: string;
};
export declare const CheckFunctionToolSubAgentAssociationRequest$zodSchema: z.ZodType<CheckFunctionToolSubAgentAssociationRequest>;
export type CheckFunctionToolSubAgentAssociationResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    ExistsResponse?: ExistsResponse | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CheckFunctionToolSubAgentAssociationResponse$zodSchema: z.ZodType<CheckFunctionToolSubAgentAssociationResponse>;
//# sourceMappingURL=checkfunctiontoolsubagentassociationop.d.ts.map