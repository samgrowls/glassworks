import * as z from "zod";
export type DatasetItem = {
    id: string;
    datasetId: string;
    input?: any | null | undefined;
    expectedOutput?: any | null | undefined;
    simulationAgent?: any | null | undefined;
    createdAt: string;
    updatedAt: string;
};
export declare const DatasetItem$zodSchema: z.ZodType<DatasetItem>;
//# sourceMappingURL=datasetitem.d.ts.map