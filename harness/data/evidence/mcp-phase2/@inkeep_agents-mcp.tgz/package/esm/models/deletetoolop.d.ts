import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type DeleteToolRequest = {
    tenantId: string;
    projectId: string;
    id: string;
};
export declare const DeleteToolRequest$zodSchema: z.ZodType<DeleteToolRequest>;
export type DeleteToolResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const DeleteToolResponse$zodSchema: z.ZodType<DeleteToolResponse>;
//# sourceMappingURL=deletetoolop.d.ts.map