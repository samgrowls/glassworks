import * as z from "zod";
import { ErrorResponse } from "./errorresponse.js";
export type DeleteApiKeyRequest = {
    tenantId: string;
    projectId: string;
    id: string;
};
export declare const DeleteApiKeyRequest$zodSchema: z.ZodType<DeleteApiKeyRequest>;
export type DeleteApiKeyResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    ErrorResponse?: ErrorResponse | undefined;
};
export declare const DeleteApiKeyResponse$zodSchema: z.ZodType<DeleteApiKeyResponse>;
//# sourceMappingURL=deleteapikeyop.d.ts.map