import * as z from "zod";
import { ClosedEnum } from "../types/enums.js";
export declare const CredentialReferenceCreateType: {
    readonly Memory: "memory";
    readonly Keychain: "keychain";
    readonly Nango: "nango";
};
export type CredentialReferenceCreateType = ClosedEnum<typeof CredentialReferenceCreateType>;
export declare const CredentialReferenceCreateType$zodSchema: z.ZodEnum<{
    memory: "memory";
    keychain: "keychain";
    nango: "nango";
}>;
export type CredentialReferenceCreate = {
    id: string;
    name: string;
    type: CredentialReferenceCreateType;
    credentialStoreId: string;
    retrievalParams?: {
        [k: string]: any | null;
    } | null | undefined;
    toolId?: string | null | undefined;
    userId?: string | null | undefined;
    createdBy?: string | null | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const CredentialReferenceCreate$zodSchema: z.ZodType<CredentialReferenceCreate>;
//# sourceMappingURL=credentialreferencecreate.d.ts.map