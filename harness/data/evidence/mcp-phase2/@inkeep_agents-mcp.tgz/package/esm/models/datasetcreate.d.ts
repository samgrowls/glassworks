import * as z from "zod";
export type DatasetCreate = {
    name: string;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const DatasetCreate$zodSchema: z.ZodType<DatasetCreate>;
//# sourceMappingURL=datasetcreate.d.ts.map