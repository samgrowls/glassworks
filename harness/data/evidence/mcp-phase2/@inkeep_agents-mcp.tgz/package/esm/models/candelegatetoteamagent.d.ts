import * as z from "zod";
export type CanDelegateToTeamAgent = {
    agentId: string;
    subAgentTeamAgentRelationId: string;
    headers?: {
        [k: string]: string;
    } | null | undefined;
};
export declare const CanDelegateToTeamAgent$zodSchema: z.ZodType<CanDelegateToTeamAgent>;
//# sourceMappingURL=candelegatetoteamagent.d.ts.map