import * as z from "zod";
import { AgentWithinContextOfProject } from "./agentwithincontextofproject.js";
export type AgentWithinContextOfProjectResponse = {
    data: AgentWithinContextOfProject;
};
export declare const AgentWithinContextOfProjectResponse$zodSchema: z.ZodType<AgentWithinContextOfProjectResponse>;
//# sourceMappingURL=agentwithincontextofprojectresponse.d.ts.map