import * as z from "zod";
import { ExternalAgent } from "./externalagent.js";
import { FullAgentSubAgentSelect } from "./fullagentsubagentselect.js";
import { FunctionT } from "./function.js";
import { FunctionTool } from "./functiontool.js";
import { ModelSettings } from "./modelsettings.js";
import { StatusComponent } from "./statuscomponent.js";
import { TeamAgent } from "./teamagent.js";
import { Tool } from "./tool.js";
export type AgentWithinContextOfProjectSelectModels = {
    base?: ModelSettings | undefined;
    structuredOutput?: ModelSettings | undefined;
    summarizer?: ModelSettings | undefined;
};
export declare const AgentWithinContextOfProjectSelectModels$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectModels>;
export type AgentWithinContextOfProjectSelectStatusUpdates = {
    enabled?: boolean | undefined;
    numEvents?: number | undefined;
    timeInSeconds?: number | undefined;
    prompt?: string | undefined;
    statusComponents?: Array<StatusComponent> | undefined;
};
export declare const AgentWithinContextOfProjectSelectStatusUpdates$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectStatusUpdates>;
export type AgentWithinContextOfProjectSelectStopWhen = {
    transferCountIs?: number | undefined;
};
export declare const AgentWithinContextOfProjectSelectStopWhen$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectStopWhen>;
/**
 * JSON Schema for validating request headers
 */
export type AgentWithinContextOfProjectSelectHeadersSchema = {};
export declare const AgentWithinContextOfProjectSelectHeadersSchema$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectHeadersSchema>;
export type AgentWithinContextOfProjectSelectContextConfig = {
    id: string;
    headersSchema?: AgentWithinContextOfProjectSelectHeadersSchema | undefined;
    contextVariables?: any | null | undefined;
    createdAt: string;
    updatedAt: string;
};
export declare const AgentWithinContextOfProjectSelectContextConfig$zodSchema: z.ZodType<AgentWithinContextOfProjectSelectContextConfig>;
export type AgentWithinContextOfProjectSelect = {
    id: string;
    name: string;
    description: string | null;
    defaultSubAgentId: string | null;
    contextConfigId: string | null;
    models: AgentWithinContextOfProjectSelectModels | null;
    statusUpdates: AgentWithinContextOfProjectSelectStatusUpdates | null;
    prompt: string | null;
    stopWhen: AgentWithinContextOfProjectSelectStopWhen | null;
    createdAt: string;
    updatedAt: string;
    subAgents: {
        [k: string]: FullAgentSubAgentSelect;
    };
    tools: {
        [k: string]: Tool;
    } | null;
    externalAgents: {
        [k: string]: ExternalAgent;
    } | null;
    teamAgents: {
        [k: string]: TeamAgent;
    } | null;
    functionTools: {
        [k: string]: FunctionTool;
    } | null;
    functions: {
        [k: string]: FunctionT;
    } | null;
    contextConfig: AgentWithinContextOfProjectSelectContextConfig | null;
};
export declare const AgentWithinContextOfProjectSelect$zodSchema: z.ZodType<AgentWithinContextOfProjectSelect>;
//# sourceMappingURL=agentwithincontextofprojectselect.d.ts.map