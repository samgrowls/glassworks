import * as z from "zod";
export type ComponentAssociation = {
    subAgentId: string;
    createdAt: string;
};
export declare const ComponentAssociation$zodSchema: z.ZodType<ComponentAssociation>;
//# sourceMappingURL=componentassociation.d.ts.map