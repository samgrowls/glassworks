import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { EvaluationRunConfigCreate } from "./evaluationrunconfigcreate.js";
import { EvaluationRunConfigWithSuiteConfigs } from "./evaluationrunconfigwithsuiteconfigs.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateEvaluationRunConfigRequest = {
    tenantId: string;
    projectId: string;
    body?: EvaluationRunConfigCreate | undefined;
};
export declare const CreateEvaluationRunConfigRequest$zodSchema: z.ZodType<CreateEvaluationRunConfigRequest>;
/**
 * Evaluation run config created
 */
export type CreateEvaluationRunConfigResponseBody = {
    data: EvaluationRunConfigWithSuiteConfigs;
};
export declare const CreateEvaluationRunConfigResponseBody$zodSchema: z.ZodType<CreateEvaluationRunConfigResponseBody>;
export type CreateEvaluationRunConfigResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: CreateEvaluationRunConfigResponseBody | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateEvaluationRunConfigResponse$zodSchema: z.ZodType<CreateEvaluationRunConfigResponse>;
//# sourceMappingURL=createevaluationrunconfigop.d.ts.map