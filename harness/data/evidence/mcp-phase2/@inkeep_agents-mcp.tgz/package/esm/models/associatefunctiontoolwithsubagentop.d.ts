import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { ErrorResponse } from "./errorresponse.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { SubAgentFunctionToolRelationCreate } from "./subagentfunctiontoolrelationcreate.js";
import { SubAgentFunctionToolRelationResponse } from "./subagentfunctiontoolrelationresponse.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type AssociateFunctionToolWithSubAgentRequest = {
    tenantId: string;
    projectId: string;
    agentId: string;
    body?: SubAgentFunctionToolRelationCreate | undefined;
};
export declare const AssociateFunctionToolWithSubAgentRequest$zodSchema: z.ZodType<AssociateFunctionToolWithSubAgentRequest>;
export type AssociateFunctionToolWithSubAgentResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    SubAgentFunctionToolRelationResponse?: SubAgentFunctionToolRelationResponse | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    ErrorResponse?: ErrorResponse | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const AssociateFunctionToolWithSubAgentResponse$zodSchema: z.ZodType<AssociateFunctionToolWithSubAgentResponse>;
//# sourceMappingURL=associatefunctiontoolwithsubagentop.d.ts.map