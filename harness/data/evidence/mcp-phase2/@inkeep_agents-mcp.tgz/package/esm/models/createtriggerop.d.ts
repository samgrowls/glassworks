import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { TriggerCreate } from "./triggercreate.js";
import { TriggerWithWebhookUrlResponse } from "./triggerwithwebhookurlresponse.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateTriggerRequest = {
    tenantId: string;
    projectId: string;
    agentId: string;
    body?: TriggerCreate | undefined;
};
export declare const CreateTriggerRequest$zodSchema: z.ZodType<CreateTriggerRequest>;
export type CreateTriggerResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    TriggerWithWebhookUrlResponse?: TriggerWithWebhookUrlResponse | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateTriggerResponse$zodSchema: z.ZodType<CreateTriggerResponse>;
//# sourceMappingURL=createtriggerop.d.ts.map