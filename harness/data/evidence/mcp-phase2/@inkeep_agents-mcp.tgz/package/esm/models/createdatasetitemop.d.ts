import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { DatasetItem } from "./datasetitem.js";
import { DatasetItemCreate } from "./datasetitemcreate.js";
import { Forbidden } from "./forbidden.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type CreateDatasetItemRequest = {
    tenantId: string;
    projectId: string;
    datasetId: string;
    body?: DatasetItemCreate | undefined;
};
export declare const CreateDatasetItemRequest$zodSchema: z.ZodType<CreateDatasetItemRequest>;
/**
 * Dataset item created
 */
export type CreateDatasetItemResponseBody = {
    data: DatasetItem;
};
export declare const CreateDatasetItemResponseBody$zodSchema: z.ZodType<CreateDatasetItemResponseBody>;
export type CreateDatasetItemResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    object?: CreateDatasetItemResponseBody | undefined;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    Forbidden?: Forbidden | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const CreateDatasetItemResponse$zodSchema: z.ZodType<CreateDatasetItemResponse>;
//# sourceMappingURL=createdatasetitemop.d.ts.map