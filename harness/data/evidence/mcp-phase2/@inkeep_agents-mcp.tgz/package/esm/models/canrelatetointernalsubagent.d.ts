import * as z from "zod";
export type CanRelateToInternalSubAgent = {
    subAgentId: string;
    subAgentSubAgentRelationId: string;
};
export declare const CanRelateToInternalSubAgent$zodSchema: z.ZodType<CanRelateToInternalSubAgent>;
//# sourceMappingURL=canrelatetointernalsubagent.d.ts.map