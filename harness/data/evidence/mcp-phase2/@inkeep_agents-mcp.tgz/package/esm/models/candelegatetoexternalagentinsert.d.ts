import * as z from "zod";
export type CanDelegateToExternalAgentInsert = {
    externalAgentId: string;
    subAgentExternalAgentRelationId?: string | undefined;
    headers?: {
        [k: string]: string;
    } | null | undefined;
};
export declare const CanDelegateToExternalAgentInsert$zodSchema: z.ZodType<CanDelegateToExternalAgentInsert>;
//# sourceMappingURL=candelegatetoexternalagentinsert.d.ts.map