import * as z from "zod";
/**
 * JSON Schema for validating request headers
 */
export type ContextConfigCreateHeadersSchema = {};
export declare const ContextConfigCreateHeadersSchema$zodSchema: z.ZodType<ContextConfigCreateHeadersSchema>;
/**
 * Context variables configuration with fetch definitions
 */
export type ContextConfigCreateContextVariables = {};
export declare const ContextConfigCreateContextVariables$zodSchema: z.ZodType<ContextConfigCreateContextVariables>;
export type ContextConfigCreate = {
    id?: string | undefined;
    headersSchema?: ContextConfigCreateHeadersSchema | undefined;
    contextVariables?: ContextConfigCreateContextVariables | undefined;
};
export declare const ContextConfigCreate$zodSchema: z.ZodType<ContextConfigCreate>;
//# sourceMappingURL=contextconfigcreate.d.ts.map