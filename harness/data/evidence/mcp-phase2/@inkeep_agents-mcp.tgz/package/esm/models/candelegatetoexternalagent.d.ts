import * as z from "zod";
export type CanDelegateToExternalAgent = {
    externalAgentId: string;
    subAgentExternalAgentRelationId: string;
    headers?: {
        [k: string]: string;
    } | null | undefined;
};
export declare const CanDelegateToExternalAgent$zodSchema: z.ZodType<CanDelegateToExternalAgent>;
//# sourceMappingURL=candelegatetoexternalagent.d.ts.map