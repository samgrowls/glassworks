import * as z from "zod";
export type ArtifactComponentUpdate = {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    props?: any | null | undefined;
    render?: any | null | undefined;
    createdAt?: string | undefined;
    updatedAt?: string | undefined;
};
export declare const ArtifactComponentUpdate$zodSchema: z.ZodType<ArtifactComponentUpdate>;
//# sourceMappingURL=artifactcomponentupdate.d.ts.map