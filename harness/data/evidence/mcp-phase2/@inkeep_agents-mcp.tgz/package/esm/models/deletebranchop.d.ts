import * as z from "zod";
import { BadRequest } from "./badrequest.js";
import { ErrorResponse } from "./errorresponse.js";
import { InternalServerError } from "./internalservererror.js";
import { NotFound } from "./notfound.js";
import { Unauthorized } from "./unauthorized.js";
import { UnprocessableEntity } from "./unprocessableentity.js";
export type DeleteBranchRequest = {
    tenantId: string;
    projectId: string;
    branchName: string;
};
export declare const DeleteBranchRequest$zodSchema: z.ZodType<DeleteBranchRequest>;
export type DeleteBranchResponse = {
    ContentType: string;
    StatusCode: number;
    RawResponse: Response;
    BadRequest?: BadRequest | undefined;
    Unauthorized?: Unauthorized | undefined;
    ErrorResponse?: ErrorResponse | undefined;
    NotFound?: NotFound | undefined;
    UnprocessableEntity?: UnprocessableEntity | undefined;
    InternalServerError?: InternalServerError | undefined;
};
export declare const DeleteBranchResponse$zodSchema: z.ZodType<DeleteBranchResponse>;
//# sourceMappingURL=deletebranchop.d.ts.map