import * as z from "zod";
export type BranchInfo = {
    baseName: string;
    fullName: string;
    hash: string;
};
export declare const BranchInfo$zodSchema: z.ZodType<BranchInfo>;
//# sourceMappingURL=branchinfo.d.ts.map