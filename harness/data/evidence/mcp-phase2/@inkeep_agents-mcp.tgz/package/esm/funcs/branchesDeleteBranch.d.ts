import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { DeleteBranchRequest, DeleteBranchResponse } from "../models/deletebranchop.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
export declare enum DeleteBranchAcceptEnum {
    applicationJsonAccept = "application/json",
    applicationProblemPlusJsonAccept = "application/problem+json"
}
/**
 * Delete Branch
 *
 * @remarks
 * Delete a branch. Cannot delete protected branches like main.
 */
export declare function branchesDeleteBranch(client$: InkeepAgentsCore, request: DeleteBranchRequest, options?: RequestOptions): APIPromise<Result<DeleteBranchResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=branchesDeleteBranch.d.ts.map