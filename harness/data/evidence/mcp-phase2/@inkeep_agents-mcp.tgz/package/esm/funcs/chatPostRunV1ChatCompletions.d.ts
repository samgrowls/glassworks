import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { PostRunV1ChatCompletionsRequest, PostRunV1ChatCompletionsResponse, PostRunV1ChatCompletionsSecurity } from "../models/postrunv1chatcompletionsop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
export declare enum PostRunV1ChatCompletionsAcceptEnum {
    applicationJsonAccept = "application/json",
    textEventStreamAccept = "text/event-stream"
}
/**
 * Create chat completion
 *
 * @remarks
 * Creates a new chat completion with streaming SSE response using the configured agent
 */
export declare function chatPostRunV1ChatCompletions(client$: InkeepAgentsCore, security: PostRunV1ChatCompletionsSecurity, request?: PostRunV1ChatCompletionsRequest | undefined, options?: RequestOptions): APIPromise<Result<PostRunV1ChatCompletionsResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=chatPostRunV1ChatCompletions.d.ts.map