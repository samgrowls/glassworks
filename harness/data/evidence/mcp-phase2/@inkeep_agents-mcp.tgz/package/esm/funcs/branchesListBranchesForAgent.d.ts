import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { ListBranchesForAgentRequest, ListBranchesForAgentResponse } from "../models/listbranchesforagentop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
export declare enum ListBranchesForAgentAcceptEnum {
    applicationJsonAccept = "application/json",
    applicationProblemPlusJsonAccept = "application/problem+json"
}
/**
 * List Branches for Agent
 *
 * @remarks
 * List all branches within a project that contain the agent
 */
export declare function branchesListBranchesForAgent(client$: InkeepAgentsCore, request: ListBranchesForAgentRequest, options?: RequestOptions): APIPromise<Result<ListBranchesForAgentResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=branchesListBranchesForAgent.d.ts.map