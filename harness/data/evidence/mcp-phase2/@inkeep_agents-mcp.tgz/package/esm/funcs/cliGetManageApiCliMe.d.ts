import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { GetManageApiCliMeResponse } from "../models/getmanageapiclimeop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Get CLI user info
 *
 * @remarks
 * Get the current authenticated user and their organization for CLI usage
 */
export declare function cliGetManageApiCliMe(client$: InkeepAgentsCore, options?: RequestOptions): APIPromise<Result<GetManageApiCliMeResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=cliGetManageApiCliMe.d.ts.map