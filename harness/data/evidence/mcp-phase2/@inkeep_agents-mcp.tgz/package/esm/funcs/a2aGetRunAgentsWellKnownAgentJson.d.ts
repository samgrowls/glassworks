import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { GetRunAgentsWellKnownAgentJsonRequest, GetRunAgentsWellKnownAgentJsonResponse, GetRunAgentsWellKnownAgentJsonSecurity } from "../models/getrunagentswellknownagentjsonop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
export declare function a2aGetRunAgentsWellKnownAgentJson(client$: InkeepAgentsCore, security: GetRunAgentsWellKnownAgentJsonSecurity, request?: GetRunAgentsWellKnownAgentJsonRequest | undefined, options?: RequestOptions): APIPromise<Result<GetRunAgentsWellKnownAgentJsonResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=a2aGetRunAgentsWellKnownAgentJson.d.ts.map