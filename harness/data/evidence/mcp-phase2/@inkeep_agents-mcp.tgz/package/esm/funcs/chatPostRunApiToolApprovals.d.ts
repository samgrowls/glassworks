import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { PostRunApiToolApprovalsRequest, PostRunApiToolApprovalsResponse, PostRunApiToolApprovalsSecurity } from "../models/postrunapitoolapprovalsop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Approve or deny tool execution
 *
 * @remarks
 * Handle user approval/denial of tool execution requests during conversations
 */
export declare function chatPostRunApiToolApprovals(client$: InkeepAgentsCore, security: PostRunApiToolApprovalsSecurity, request?: PostRunApiToolApprovalsRequest | undefined, options?: RequestOptions): APIPromise<Result<PostRunApiToolApprovalsResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=chatPostRunApiToolApprovals.d.ts.map