import { InkeepAgentsCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { APIError } from "../models/errors/apierror.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/errors/httpclienterrors.js";
import { SDKValidationError } from "../models/errors/sdkvalidationerror.js";
import { PostRunApiChatRequest, PostRunApiChatResponse, PostRunApiChatSecurity } from "../models/postrunapichatop.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Chat (Vercel Streaming Protocol)
 *
 * @remarks
 * Chat completion endpoint streaming with Vercel data stream protocol.
 */
export declare function chatPostRunApiChat(client$: InkeepAgentsCore, security: PostRunApiChatSecurity, request?: PostRunApiChatRequest | undefined, options?: RequestOptions): APIPromise<Result<PostRunApiChatResponse, APIError | SDKValidationError | UnexpectedClientError | InvalidRequestError | RequestAbortedError | RequestTimeoutError | ConnectionError>>;
//# sourceMappingURL=chatPostRunApiChat.d.ts.map