import { Transport } from "@modelcontextprotocol/sdk/shared/transport.js";
export default class Server {
    private server;
    private context;
    constructor();
    connect(transport?: Transport): Promise<void>;
    handleServerInitialized(): Promise<void>;
    updateRoots(): Promise<void>;
    close(): Promise<void>;
}
