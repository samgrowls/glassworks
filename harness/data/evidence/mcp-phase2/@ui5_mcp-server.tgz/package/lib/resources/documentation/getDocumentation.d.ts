export declare enum AvailableVersions {
    "1.136.11" = "1.136.11"
}
export interface DocumentationResource {
    title: string;
    text: string;
    uri: string;
}
export interface DocumentationIndexEntry {
    shortIdentifier: string;
    identifier: string;
    uri: string;
    title: string;
    filePath: string;
}
export declare function getDocumentationIndex(version?: AvailableVersions): Promise<DocumentationIndexEntry[]>;
export declare function getDocumentationByLoio(loioIdentifier: string, version?: AvailableVersions): Promise<DocumentationResource>;
export declare function getDocumentationByUrl(url: string): Promise<DocumentationResource>;
