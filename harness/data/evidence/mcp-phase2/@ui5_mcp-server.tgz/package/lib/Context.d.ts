interface Root {
    /**
     * @property uri - The unique identifier for the root, which must be a file:// URI.
    */
    uri: string;
    /**
     * @property name - An optional human-readable name for the root, used for display purposes.
    */
    name?: string;
}
type Roots = Root[];
export default class Context {
    private useStructuredContentInResponse;
    private useResourcesInResponse;
    private allowedRootPaths;
    constructor(useStructuredContentInResponse?: boolean, useResourcesInResponse?: boolean);
    /**
     * Normalizes a path, ensuring it is absolute, exists, and is inside one of the configured roots (if configured).
     *
     * @param fsPath - The directory path to normalize.
     * @returns A promise that resolves to the normalized absolute path.
     * @throws InvalidInputError if the path is not absolute or not inside the allowed roots.
     */
    normalizePath(fsPath: string): Promise<string>;
    setRoots(roots: Roots): void;
    isInsideRoots(absolutePath: string): boolean;
}
export {};
