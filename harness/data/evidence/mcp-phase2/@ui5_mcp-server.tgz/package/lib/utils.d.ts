export declare function dirExists(dirPath: string): Promise<boolean>;
export declare function fileExists(dirPath: string): Promise<boolean>;
export declare class InvalidInputError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
export declare class NotFoundError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
export declare function handleError(error: unknown): never;
export declare const PKG_VERSION: string;
