/**
 * UI5 Version Info Tool
 *
 * This tool provides version information for UI5 (OpenUI5 and SAPUI5)
 * by fetching data from the respective version.json files.
 */
import Context from "../../Context.js";
import { RegisterTool } from "../../registerTools.js";
export default function registerTool(registerTool: RegisterTool, _context: Context): void;
