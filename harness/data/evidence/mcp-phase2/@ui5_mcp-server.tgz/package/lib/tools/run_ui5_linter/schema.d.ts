import { z } from "zod";
export declare const inputSchema: {
    projectDir: z.ZodString;
    fix: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    filePatterns: z.ZodOptional<z.ZodArray<z.ZodString>>;
    provideContextInformation: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
};
export declare const inputSchemaObject: z.ZodObject<{
    projectDir: z.ZodString;
    fix: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    filePatterns: z.ZodOptional<z.ZodArray<z.ZodString>>;
    provideContextInformation: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
}, z.core.$strip>;
export declare const outputSchema: {
    projectDir: z.ZodString;
    frameworkVersion: z.ZodOptional<z.ZodString>;
    results: z.ZodArray<z.ZodObject<{
        filePath: z.ZodString;
        messages: z.ZodArray<z.ZodObject<{
            ruleId: z.ZodString;
            severity: z.ZodNumber;
            line: z.ZodOptional<z.ZodNumber>;
            column: z.ZodOptional<z.ZodNumber>;
            fatal: z.ZodOptional<z.ZodBoolean>;
            message: z.ZodString;
            messageDetails: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    contextInformation: z.ZodOptional<z.ZodObject<{
        ruleDescriptions: z.ZodArray<z.ZodObject<{
            ruleId: z.ZodString;
            description: z.ZodString;
        }, z.core.$strip>>;
        migrationGuides: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            text: z.ZodString;
            uri: z.ZodString;
        }, z.core.$strip>>;
        apiReferences: z.ZodArray<z.ZodAny>;
        documentationResources: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            text: z.ZodString;
            uri: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
};
export declare const outputSchemaObject: z.ZodObject<{
    projectDir: z.ZodString;
    frameworkVersion: z.ZodOptional<z.ZodString>;
    results: z.ZodArray<z.ZodObject<{
        filePath: z.ZodString;
        messages: z.ZodArray<z.ZodObject<{
            ruleId: z.ZodString;
            severity: z.ZodNumber;
            line: z.ZodOptional<z.ZodNumber>;
            column: z.ZodOptional<z.ZodNumber>;
            fatal: z.ZodOptional<z.ZodBoolean>;
            message: z.ZodString;
            messageDetails: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    contextInformation: z.ZodOptional<z.ZodObject<{
        ruleDescriptions: z.ZodArray<z.ZodObject<{
            ruleId: z.ZodString;
            description: z.ZodString;
        }, z.core.$strip>>;
        migrationGuides: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            text: z.ZodString;
            uri: z.ZodString;
        }, z.core.$strip>>;
        apiReferences: z.ZodArray<z.ZodAny>;
        documentationResources: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            text: z.ZodString;
            uri: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type RunUi5LinterParams = z.infer<typeof inputSchemaObject>;
export type RunUi5LinterResult = z.infer<typeof outputSchemaObject>;
export type RunUi5LinterResultContext = z.infer<typeof outputSchema.contextInformation>;
