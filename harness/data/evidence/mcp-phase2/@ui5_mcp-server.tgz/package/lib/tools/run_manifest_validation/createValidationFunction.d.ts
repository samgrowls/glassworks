import { ValidateFunction } from "ajv/dist/2020.js";
export declare function createValidateFunction(ui5ManifestSchema: object): Promise<ValidateFunction>;
