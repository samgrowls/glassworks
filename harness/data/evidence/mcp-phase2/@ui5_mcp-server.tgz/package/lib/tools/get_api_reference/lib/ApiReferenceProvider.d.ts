import { ApiReferenceIndex } from "./apiReferenceResources.js";
import type { ConcreteSymbol, ObjMethod, ObjProperty, Ui5Property, ObjEvent, Ui5Event, EnumProperty, Ui5Aggregation, Ui5Association, Ui5SpecialSetting, ObjConstructor, ObjCallableParameter, NamespaceSymbol, SymbolBase, InterfaceSymbol, ClassSymbol, EnumSymbol } from "./api-json.js";
import { Ui5TypeInfo } from "@ui5/linter/Ui5TypeInfoMatcher";
import { FormattedSymbol, FormattedSymbolSummary } from "./formatSymbol.js";
interface SymbolCache {
    symbols: Map<string, ConcreteSymbol>;
    library: string;
}
interface SymbolInfo {
    symbol: ConcreteSymbol | ConcreteSymbolField;
    library: string;
    moduleName: string | undefined;
}
type AddToUnion<T, U> = T extends unknown ? T & U : never;
export declare enum SymbolKind {
    Class = "class",
    Interface = "interface",
    Namespace = "namespace",
    Enum = "enum",
    Member = "member",// 'member' is treated like 'namespace' or 'object'
    Object = "object",
    Typedef = "typedef",
    Function = "function",
    Property = "property",
    Constructor = "constructor",
    Method = "method",
    Event = "event",
    Parameter = "parameter",
    EnumProperty = "enum-property",
    Ui5Property = "ui5-property",
    Ui5Event = "ui5-event",
    Ui5Aggregation = "ui5-aggregation",
    Ui5Association = "ui5-association",
    Ui5SpecialSetting = "ui5-specialSetting"
}
export type ConcreteSymbolField = AddToUnion<ObjMethod | ObjProperty | Ui5Property | ObjEvent | Ui5Event | EnumProperty | Ui5Aggregation | Ui5Association | Ui5SpecialSetting | ObjConstructor | ObjCallableParameter, {
    kind: SymbolKind;
}>;
export default class ApiReferenceProvider {
    private apiJsonsRootDir;
    private index;
    private symbolCache;
    private apiJsonLoadMutex;
    constructor(apiJsonsRootDir: string, index: ApiReferenceIndex);
    static create(apiJsonsRootDir: string): Promise<ApiReferenceProvider>;
    findSymbol(query: string): Promise<FormattedSymbol | FormattedSymbol[]>;
    findSymbolAndSummarize(query: string): Promise<FormattedSymbol | FormattedSymbolSummary | (FormattedSymbol | FormattedSymbolSummary)[]>;
    _findSymbol(query: string): Promise<SymbolInfo | SymbolInfo[]>;
    _findSymbolsInModule(moduleName: string, symbolCache: SymbolCache): SymbolInfo[];
    /**
     * Searches for a field (e.g. method, property, event) by name within a UI5 symbol.
     *
     * @param symbol The ConcreteSymbol to search within.
     * @param field The name of the field to find.
     * @returns The found entity (method, property, event, etc.) or undefined if not found.
     */
    _getFieldInSymbol(symbol: ConcreteSymbol, field: string): ConcreteSymbolField | undefined;
    _findFieldByName<T extends {
        name: string;
    }>(fieldName: string, symbolFields: T[] | undefined, fieldKind: SymbolKind): ConcreteSymbolField | undefined;
    getSymbolForUi5Type(ui5TypeInfo: Ui5TypeInfo): Promise<FormattedSymbol>;
    getSymbolForUi5TypeAndSummarize(ui5TypeInfo: Ui5TypeInfo): Promise<FormattedSymbol | FormattedSymbolSummary>;
    _getSymbolForUi5Type(ui5TypeInfo: Ui5TypeInfo): Promise<SymbolInfo>;
    _parseUi5TypeInfo(ui5TypeInfo: Ui5TypeInfo): {
        moduleName: string;
        relevantNode: Ui5TypeInfo;
    } | undefined;
    _findSymbolForSubType(symbol: ClassSymbol | InterfaceSymbol | NamespaceSymbol | EnumSymbol, ui5TypeInfo: Ui5TypeInfo): ConcreteSymbol | ConcreteSymbolField | undefined;
    _getApiJson(filePath: string): Promise<SymbolCache>;
    /**
     * Normalizes the search query by removing white space, replacing slashes and hashes with dots,
     * and making it lower case (to allow case-insensitive search).
     *
     * @param query - The search query to normalize. E.g. " module:sap/ui/core/Component#onInit "
     * @returns The normalized query. E.g. "sap.ui.core.Component"
     */
    _normalizeForIndex(query: string): string;
    _normalizeForModuleName(query: string): string;
}
export declare function isUi5ClassSymbol(symbol: SymbolBase): symbol is ClassSymbol;
export declare function isUi5InterfaceSymbol(symbol: SymbolBase): symbol is InterfaceSymbol;
export declare function isUi5NamespaceSymbol(symbol: SymbolBase): symbol is NamespaceSymbol;
export declare function isUi5EnumSymbol(symbol: SymbolBase): symbol is EnumSymbol;
export declare function isConcreteSymbol(symbol: ConcreteSymbol | ConcreteSymbolField): symbol is ConcreteSymbol;
export {};
