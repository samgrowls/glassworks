import { z } from "zod";
export declare const inputSchema: {
    projectDir: z.ZodString;
    query: z.ZodString;
};
export declare const inputSchemaObject: z.ZodObject<{
    projectDir: z.ZodString;
    query: z.ZodString;
}, z.core.$strip>;
export type GetApiReferenceParams = z.infer<typeof inputSchemaObject>;
