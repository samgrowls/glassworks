import z from "zod";
export declare const supportedCardTypes: readonly ["Analytical", "Calendar", "List", "Object", "Table", "Timeline"];
export type SupportedCardType = typeof supportedCardTypes[number];
declare const destinationSchema: z.ZodObject<{
    name: z.ZodString;
    defaultUrl: z.ZodString;
}, z.z.core.$strip>;
export type Destination = z.infer<typeof destinationSchema>;
export declare const inputSchema: {
    basePath: z.ZodString;
    cardFolderName: z.ZodDefault<z.ZodString>;
    cardType: z.ZodDefault<z.ZodEnum<{
        Analytical: "Analytical";
        Calendar: "Calendar";
        List: "List";
        Object: "Object";
        Table: "Table";
        Timeline: "Timeline";
    }>>;
    destinations: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        defaultUrl: z.ZodString;
    }, z.z.core.$strip>>>;
};
export {};
