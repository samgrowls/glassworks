import { LintResult } from "@ui5/linter";
export default function getMigrationGuidesForResults(results: LintResult[]): Promise<{
    title: string;
    text: string;
    uri: string;
}[]>;
