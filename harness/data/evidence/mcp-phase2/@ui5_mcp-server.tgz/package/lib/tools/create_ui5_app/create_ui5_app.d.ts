import { CreateUi5AppParams, CreateUi5AppResult } from "./schema.js";
/**
 * Creates a new SAPUI5/OpenUI5 application using templating.
 *
 * @param {CreateUi5AppParams} params - Parameters for the application to be created.
 * @returns {Promise<CreateUi5AppResult>} Result object indicating success, message, and final location.
 */
export declare function createUi5App(params: CreateUi5AppParams): Promise<CreateUi5AppResult>;
