import { RunUi5LinterParams, RunUi5LinterResult } from "./schema.js";
export default function runUi5Linter({ projectDir, filePatterns, fix, provideContextInformation, }: RunUi5LinterParams): Promise<RunUi5LinterResult>;
