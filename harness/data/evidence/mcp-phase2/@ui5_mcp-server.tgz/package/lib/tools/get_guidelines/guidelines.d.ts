export declare function getGuidelines(): Promise<string>;
