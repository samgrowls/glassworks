import { Ui5Framework } from "../../utils/ui5Framework.js";
/**
 * Template variable definitions for EJS templates.
 */
export interface TemplateVars {
    /** Namespace for the application */
    namespace: string;
    /** Framework used, either OpenUI5 or SAPUI5 */
    framework: Ui5Framework;
    /** Version of the framework */
    frameworkVersion: string;
    /** Author of the application */
    author: string;
    /** TypeScript types npm package (only in TS case) */
    tstypes?: string;
    /** Version of TypeScript types npm package (only in TS case) */
    tstypesVersion?: string;
    /** Application ID */
    appId: string;
    /** Application URI (ID with slashes instead of dots) */
    appURI: string;
    /** CDN domain for resources */
    cdnDomain: string;
    /** OData V4 service URL */
    oDataV4Url?: string;
    /** OData entity set name */
    oDataEntitySet?: string;
    /** Properties of the entity to display */
    entityProperties?: string[];
    /** Indicates if server requires X-CSRF token , for optimized model config */
    serverRequiresXCSRF?: boolean;
    /** Default theme for the application */
    defaultTheme: string;
    /** QUnit coverage file - depends on UI5 version */
    qunitCoverageFile: string;
    /** Version of the MCP server, for source template metadata */
    mcpServerVersion: string;
    /** Flags for version-specific features */
    gte1_98_0: boolean;
    gte1_100_0: boolean;
    gte1_104_0: boolean;
    lt1_110_0: boolean;
    gte1_115_0: boolean;
    gte1_120_0: boolean;
    lt1_124_0: boolean;
    gte1_141_0: boolean;
    gte1_142_0: boolean;
    gte1_136_0: boolean;
}
/**
 * Options for processing EJS templates with UI5-specific version handling.
 */
export interface TemplateProcessingOptions {
    /** Directory containing the template files */
    templateDir: string;
    /** Target directory where processed files should be written */
    targetDir: string;
    /** Variables to pass to EJS template rendering */
    templateVars: TemplateVars;
    /** Version-specific logic flags */
    versionSpecificLogic?: {
        lt1_124_0: boolean;
    };
}
/**
 * Processes EJS templates from a source directory to a target directory.
 * Handles UI5-specific version logic for test folder structure.
 *
 * @param options - Configuration for template processing
 * @throws Error if template processing fails
 */
export declare function processTemplates(options: TemplateProcessingOptions): Promise<string[]>;
