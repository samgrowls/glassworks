import Context from "../../Context.js";
import { RegisterTool } from "../../registerTools.js";
export default function registerTool(registerTool: RegisterTool, _context: Context): void;
