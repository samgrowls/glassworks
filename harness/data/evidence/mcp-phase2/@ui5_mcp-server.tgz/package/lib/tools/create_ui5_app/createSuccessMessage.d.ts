export declare function createSuccessMessage({ finalODataV4Url, oDataEntitySet, entityProperties, basePath, appNamespace, framework, frameworkVersion, runNpmInstall, finalLocation, typescript, generatedFiles, }: {
    finalODataV4Url?: string;
    oDataEntitySet?: string;
    entityProperties?: string[];
    basePath: string;
    appNamespace: string;
    framework: string;
    frameworkVersion: string;
    runNpmInstall: boolean;
    finalLocation: string;
    typescript: boolean;
    generatedFiles: string[];
}): string;
