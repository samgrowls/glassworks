import { Ui5Framework } from "../../utils/ui5Framework.js";
export declare function getLatestUi5Version(framework: Ui5Framework): Promise<string>;
