import { Destination, SupportedCardType } from "./schema.js";
interface CreateIntegrationCardParams {
    folderPath: string;
    cardType: SupportedCardType;
    manifestVersion: string;
    destinations?: Destination[];
}
export declare function createIntegrationCard({ folderPath, cardType, manifestVersion, destinations, }: CreateIntegrationCardParams): Promise<string[]>;
export {};
