import { Ui5Framework } from "../../../utils/ui5Framework.js";
interface ApiReferenceIndexEntry {
    /**
     * Value of the "name" property of the respective symbol in the api.json
     */
    name: string;
    /**
     * Path to the api.json file containing the symbol, relative to the directory containing the index.json
     */
    filePath: string;
}
export type ApiReferenceIndex = Record<string, ApiReferenceIndexEntry>;
export declare function getApiJsonDir(frameworkName: Ui5Framework, frameworkVersion: string): Promise<string>;
export declare function fetchApiJsons(targetDir: string, frameworkName: Ui5Framework, frameworkVersion: string): Promise<string[]>;
export declare function _createApiIndex(targetDir: string, apiJsonPaths: string[]): Promise<void>;
export declare function _fetchApiJson(targetPath: string, url: string): Promise<string>;
export declare function getLibrariesForVersion(baseUrl: string): Promise<string[]>;
export {};
