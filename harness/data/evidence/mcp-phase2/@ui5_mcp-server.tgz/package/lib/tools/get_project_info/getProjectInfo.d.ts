import { GetProjectInfoResult } from "./schema.js";
export default function getProjectInfo(projectDir: string, includeVersionInfo?: boolean): Promise<GetProjectInfoResult>;
