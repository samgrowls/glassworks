export declare function getTypescriptConversionGuidelines(): Promise<string>;
