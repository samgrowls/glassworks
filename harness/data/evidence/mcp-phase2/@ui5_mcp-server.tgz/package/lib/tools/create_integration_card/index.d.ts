import Context from "../../Context.js";
import { RegisterTool } from "../../registerTools.js";
export default function registerTool(registerTool: RegisterTool, context: Context): import("@modelcontextprotocol/sdk/server/mcp.js").RegisteredTool;
