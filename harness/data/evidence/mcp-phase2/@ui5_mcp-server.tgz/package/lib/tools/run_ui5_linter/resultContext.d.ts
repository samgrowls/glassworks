import { LintResult } from "@ui5/linter";
import { RunUi5LinterResultContext } from "./schema.js";
export declare function createResultContext(results: LintResult[]): Promise<RunUi5LinterResultContext>;
