import { Ui5TypeInfo } from "@ui5/linter/Ui5TypeInfoMatcher";
import { Ui5Framework } from "../../utils/ui5Framework.js";
import { FormattedSymbol, FormattedSymbolSummary } from "./lib/formatSymbol.js";
/**
 * Example: await getApiReference("sapui5", 1.120.30", "sap.ui.table.Table");
 */
export declare function getApiReference(query: string, frameworkName: Ui5Framework, frameworkVersion: string): Promise<FormattedSymbol[]>;
export declare function getApiReferenceSummary(query: string, frameworkName: Ui5Framework, frameworkVersion: string): Promise<(FormattedSymbol | FormattedSymbolSummary)[]>;
export declare function getApiReferenceForUi5Type(ui5TypeInfo: Ui5TypeInfo, frameworkName: Ui5Framework, frameworkVersion: string): Promise<FormattedSymbol>;
export declare function getApiReferenceSummaryForUi5Type(ui5TypeInfo: Ui5TypeInfo, frameworkName: Ui5Framework, frameworkVersion: string): Promise<FormattedSymbol | FormattedSymbolSummary>;
