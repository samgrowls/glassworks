import { z } from "zod";
export declare const inputSchema: {
    projectDir: z.ZodString;
};
export declare const inputSchemaObject: z.ZodObject<{
    projectDir: z.ZodString;
}, z.core.$strip>;
export declare const outputSchema: {
    projectDir: z.ZodString;
    projectName: z.ZodString;
    projectType: z.ZodString;
    frameworkName: z.ZodOptional<z.ZodEnum<{
        OpenUI5: "OpenUI5";
        SAPUI5: "SAPUI5";
    }>>;
    frameworkVersion: z.ZodOptional<z.ZodString>;
    frameworkLibraries: z.ZodOptional<z.ZodArray<z.ZodString>>;
    versionInfo: z.ZodOptional<z.ZodObject<{
        supportStatus: z.ZodString;
        isLts: z.ZodOptional<z.ZodBoolean>;
        latestVersion: z.ZodString;
        latestLtsVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
};
export declare const outputSchemaObject: z.ZodObject<{
    projectDir: z.ZodString;
    projectName: z.ZodString;
    projectType: z.ZodString;
    frameworkName: z.ZodOptional<z.ZodEnum<{
        OpenUI5: "OpenUI5";
        SAPUI5: "SAPUI5";
    }>>;
    frameworkVersion: z.ZodOptional<z.ZodString>;
    frameworkLibraries: z.ZodOptional<z.ZodArray<z.ZodString>>;
    versionInfo: z.ZodOptional<z.ZodObject<{
        supportStatus: z.ZodString;
        isLts: z.ZodOptional<z.ZodBoolean>;
        latestVersion: z.ZodString;
        latestLtsVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type GetProjectInfoParams = z.infer<typeof inputSchemaObject>;
export type GetProjectInfoResult = z.infer<typeof outputSchemaObject>;
