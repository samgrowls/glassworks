import { z } from "zod";
export declare const inputSchema: {
    manifestPath: z.ZodString;
};
export declare const outputSchema: {
    isValid: z.ZodBoolean;
    errors: z.ZodArray<z.ZodObject<{
        keyword: z.ZodString;
        instancePath: z.ZodString;
        schemaPath: z.ZodString;
        params: z.ZodRecord<z.ZodAny, z.ZodAny>;
        propertyName: z.ZodOptional<z.ZodString>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
};
declare const _outputSchemaObject: z.ZodObject<{
    isValid: z.ZodBoolean;
    errors: z.ZodArray<z.ZodObject<{
        keyword: z.ZodString;
        instancePath: z.ZodString;
        schemaPath: z.ZodString;
        params: z.ZodRecord<z.ZodAny, z.ZodAny>;
        propertyName: z.ZodOptional<z.ZodString>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type RunSchemaValidationResult = z.infer<typeof _outputSchemaObject>;
export {};
