import { z } from "zod";
export declare const inputSchema: {
    frameworkName: z.ZodEnum<{
        OpenUI5: "OpenUI5";
        SAPUI5: "SAPUI5";
    }>;
};
export declare const inputSchemaObject: z.ZodObject<{
    frameworkName: z.ZodEnum<{
        OpenUI5: "OpenUI5";
        SAPUI5: "SAPUI5";
    }>;
}, z.core.$strip>;
export declare const versionsSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    version: z.ZodString;
    support: z.ZodString;
    lts: z.ZodBoolean;
}, z.core.$strip>>;
export declare const outputSchema: {
    versions: z.ZodRecord<z.ZodString, z.ZodObject<{
        version: z.ZodString;
        support: z.ZodString;
        lts: z.ZodBoolean;
    }, z.core.$strip>>;
};
export declare const outputSchemaObject: z.ZodObject<{
    versions: z.ZodRecord<z.ZodString, z.ZodObject<{
        version: z.ZodString;
        support: z.ZodString;
        lts: z.ZodBoolean;
    }, z.core.$strip>>;
}, z.core.$strip>;
