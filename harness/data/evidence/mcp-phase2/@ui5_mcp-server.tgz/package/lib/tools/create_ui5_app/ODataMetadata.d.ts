interface PropertyRef {
    Name: string;
}
interface Property {
    Name: string;
    Type: string;
}
interface EntityType {
    Name: string;
    Key?: {
        PropertyRef: PropertyRef | PropertyRef[];
    };
    Property?: Property | Property[];
}
interface EntitySet {
    Name: string;
    EntityType: string;
}
interface Schema {
    Namespace: string;
    EntityType?: EntityType | EntityType[];
    EntityContainer?: {
        EntitySet?: EntitySet | EntitySet[];
    };
}
interface DataServices {
    Schema: Schema | Schema[];
}
interface Edmx {
    DataServices: DataServices;
}
interface ServiceMetadata {
    Edmx: Edmx;
}
export default class ODataMetadata {
    private serviceMetadata;
    private entityTypes;
    private entitySets;
    private static serviceUrl;
    constructor(serviceMetadata: ServiceMetadata);
    static load(serviceUrl: string): Promise<ODataMetadata | undefined>;
    getEntitySets(): string[];
    getEntitySet(name: string): {
        namespace: string;
        name: string;
        keys: string[];
        properties: {
            name: string;
            type: string;
        }[];
    } | undefined;
    getKeys(entitySet: string): string[] | undefined;
    getProperties(entitySet: string): string[] | undefined;
}
export {};
