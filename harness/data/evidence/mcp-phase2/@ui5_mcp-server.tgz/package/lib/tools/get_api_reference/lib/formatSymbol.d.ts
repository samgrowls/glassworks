import { ConcreteSymbol } from "./api-json.js";
import { ConcreteSymbolField, SymbolKind } from "./ApiReferenceProvider.js";
export interface FormattedSymbol {
    kind: SymbolKind;
    name: string;
    library: string;
    module?: string;
    export?: string;
    [k: string]: unknown;
}
export interface FormattedSymbolSummary {
    _summaryInfo: string;
    kind: SymbolKind;
    name: string;
    library: string;
    module?: string;
    export?: string;
    description?: string;
    deprecatedText?: string;
    experimentalText?: string;
    extends?: string | string[];
}
export declare function formatSymbol(inputSymbol: ConcreteSymbol | ConcreteSymbolField, libraryName: string, moduleName: string | undefined): FormattedSymbol;
export declare function summarizeSymbol(inputSymbol: ConcreteSymbol, libraryName: string, moduleName: string | undefined): FormattedSymbolSummary;
