import { GetVersionInfoParams, GetVersionInfoResult } from "./types.js";
/**
 * Fetch version information for the specified UI5 framework
 * @param framework The UI5 framework (OpenUI5 or SAPUI5)
 * @returns The version information
 * @throws {Error} If the version information cannot be fetched
 */
export default function getVersionInfo(params: GetVersionInfoParams): Promise<GetVersionInfoResult>;
