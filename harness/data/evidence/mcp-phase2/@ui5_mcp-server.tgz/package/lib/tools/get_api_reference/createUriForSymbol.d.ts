import { FormattedSymbol, FormattedSymbolSummary } from "./lib/formatSymbol.js";
export default function createUriForSymbol(symbol: FormattedSymbol | FormattedSymbolSummary, frameworkName: string, frameworkVersion: string): string;
