import { RunSchemaValidationResult } from "./schema.js";
export default function runValidation(manifestPath: string): Promise<RunSchemaValidationResult>;
