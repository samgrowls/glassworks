export declare function getDataDir(identifier: string): string;
export declare function synchronize<T>(lockName: string, callback: () => T): Promise<T>;
