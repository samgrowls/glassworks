/**
 * Get the manifest schema for a specific manifest version.
 * @param manifestVersion The manifest version
 * @returns The manifest schema
 * @throws Error if the manifest version is unsupported
 */
export declare function getManifestSchema(manifestVersion: string): Promise<object>;
/**
 * Get the manifest version from the manifest object.
 * @param manifest The manifest object
 * @returns The manifest version
 * @throws Error if the manifest version is missing or invalid
 */
export declare function getManifestVersion(manifest: object): Promise<string>;
/**
 * @returns The latest manifest version
 */
export declare function getLatestManifestVersion(): Promise<string>;
