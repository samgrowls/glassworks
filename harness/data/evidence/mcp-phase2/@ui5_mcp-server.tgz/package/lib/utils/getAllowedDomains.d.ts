export default function getAllowedDomains(): string[];
