/**
 * Validates a URL against a set of specified rules, including protocol and domain allow lists.
 *
 * @param urlString The string to validate as a URL.
 * @param domainAllowList An array of allowed domain names.
 *                        - An empty array allows any domain.
 *                        - e.g., ["localhost", "example.com", "sub.example.com"]
 *                        - For wildcard subdomains, prefix the domain with a dot: ".example.com".
 *                          This will match "www.example.com" but not "example.com".
 * @param protocolAllowList An array of allowed protocols (without the trailing colon).
 *                         - An empty array allows any protocol.
 *                         - e.g., ["http", "https"]
 * @returns `true` if the URL is valid according to the rules, otherwise `false`.
 * @throws {InvalidInputError} if the URL's domain is not in the provided allow list.
 */
export default function isValidUrl(urlString: string, domainAllowList?: string[], protocolAllowList?: string[]): boolean;
