import { Ui5Framework } from "./ui5Framework.js";
/**
 * Get the base URL for the UI5 CDN based on the framework
 * @param frameworkName The UI5 framework (OpenUI5 or SAPUI5)
 * @returns The CDN base URL
 */
export declare function getBaseUrl(frameworkName: Ui5Framework, frameworkVersion?: string): string;
export declare function fetchCdnRaw(url: string): Promise<import("node-fetch").Response>;
export declare function fetchCdn(url: string): Promise<object>;
