import { z } from "zod";
export declare const Ui5FrameworkSchema: z.ZodEnum<{
    OpenUI5: "OpenUI5";
    SAPUI5: "SAPUI5";
}>;
export type Ui5Framework = z.infer<typeof Ui5FrameworkSchema>;
export declare function isUi5Framework(value: unknown): value is Ui5Framework;
