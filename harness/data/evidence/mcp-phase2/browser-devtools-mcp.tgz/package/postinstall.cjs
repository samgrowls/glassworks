'use strict';

/**
 * Postinstall script for browser-devtools-mcp.
 * Installs Playwright browser binaries only when env vars are set:
 *   - BROWSER_DEVTOOLS_INSTALL_CHROMIUM=true  → chromium, chromium-headless-shell, ffmpeg
 *   - BROWSER_DEVTOOLS_INSTALL_FIREFOX=true   → firefox
 *   - BROWSER_DEVTOOLS_INSTALL_WEBKIT=true    → webkit
 * If none are set, we do nothing; Playwright's own install scripts behave as usual.
 * Does not fail npm install on error.
 */

const CHROMIUM_BROWSERS = ['chromium', 'chromium-headless-shell', 'ffmpeg'];
const FIREFOX_BROWSERS = ['firefox'];
const WEBKIT_BROWSERS = ['webkit'];

function envTruthy(name) {
    const v = process.env[name];
    return v === '1' || v === 'true';
}

/** Returns list of browser names to install based on env vars only. */
function getBrowsersToInstall() {
    const list = [];
    if (envTruthy('BROWSER_DEVTOOLS_INSTALL_CHROMIUM')) {
        list.push(...CHROMIUM_BROWSERS);
    }
    if (envTruthy('BROWSER_DEVTOOLS_INSTALL_FIREFOX')) {
        list.push(...FIREFOX_BROWSERS);
    }
    if (envTruthy('BROWSER_DEVTOOLS_INSTALL_WEBKIT')) {
        list.push(...WEBKIT_BROWSERS);
    }
    return list;
}

async function main() {
    const toInstall = getBrowsersToInstall();
    if (toInstall.length === 0) {
        return;
    }

    try {
        const { installBrowsersForNpmInstall } = require('playwright-core/lib/server');
        console.log(`[browser-devtools-mcp] Installing browser binaries: ${toInstall} ...`);
        const hadSkip = process.env.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD;
        if (hadSkip !== undefined) {
            delete process.env.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD;
        }
        await installBrowsersForNpmInstall(toInstall);
        if (hadSkip !== undefined) {
            process.env.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = hadSkip;
        }
        console.log(`[browser-devtools-mcp] Installed browser binaries: ${toInstall} `);
    } catch (e) {
        console.warn('[browser-devtools-mcp] Could not auto-install Playwright browsers:', e && e.message ? e.message : e);
        console.warn('[browser-devtools-mcp] Run "npx playwright install chromium" (or firefox/webkit) manually if needed.');
        if (process.env.DEBUG) {
            console.warn(e);
        }
    }
}

main();
