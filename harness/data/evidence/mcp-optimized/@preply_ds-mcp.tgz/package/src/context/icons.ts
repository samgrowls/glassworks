import path from 'node:path';
import { packageRoot, readJson } from '#/utils/fs';
import lunr from 'lunr';
import kebabCase from 'kebab-case';
import { z } from 'zod';

const root = packageRoot();
const rawIconNames = readJson(path.resolve(root, 'src/generated/icons.json'), z.array(z.string()));

type IconData = {
    name: string;
    kebabName: string;
};

const TOKYO_UI_PREFIX = 'TokyoUI';

const icons: IconData[] = rawIconNames.map(name => ({ name, kebabName: kebabCase(name, false) }));

const iconsByName: Record<string, IconData> = Object.fromEntries(
    icons.map(icon => [icon.name, icon]),
);

const index = lunr(function () {
    this.ref('name');
    // We'll use kebab-name so words will be split by hyphens
    this.field('kebabName');

    icons.forEach(icon => this.add(icon));
});

export function stripTokyoUiPrefix(name: string) {
    if (name.startsWith(TOKYO_UI_PREFIX)) {
        return name.slice(TOKYO_UI_PREFIX.length);
    }
    return name;
}

export function ensureTokyoUiPrefix(name: string) {
    if (!name.startsWith(TOKYO_UI_PREFIX)) {
        return `${TOKYO_UI_PREFIX}${name}`;
    }
    return name;
}

export function searchByName(query: string) {
    const normalized = stripTokyoUiPrefix(query);

    // Exact match first
    const exactMatch = iconsByName[normalized]?.name;
    // Fuzzy via lunr
    const fuzzyMatch = index
        .search(kebabCase(normalized, false))
        .map(res => iconsByName[res.ref].name)
        .filter(res => res !== exactMatch)
        .slice(0, 10);

    return {
        results: fuzzyMatch,
        exactMatch,
    };
}
