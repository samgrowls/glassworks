import path from 'node:path';
import { listDirFiles, packageRoot, readMd } from '#/utils/fs';
import { z } from 'zod';

const root = packageRoot();
const generatedDir = path.resolve(root, 'src/generated/components');

const componentFrontMatterSchema = z.object({
    name: z.string(),
    import: z.string(),
    description: z.string().optional(),
    deprecated: z.boolean().optional(),
});

export type ComponentFrontMatter = z.infer<typeof componentFrontMatterSchema>;

const componentsList: ComponentFrontMatter[] = [];
const componentDocs: Record<string, string> = {};

const files = listDirFiles(generatedDir).filter(f => f.endsWith('.md'));

for (const filename of files) {
    const absolutePath = path.join(generatedDir, filename);
    const parsed = readMd(absolutePath, componentFrontMatterSchema);

    const attributes = parsed.attributes;
    if (!attributes.name) continue;

    componentsList.push(attributes);
    componentDocs[attributes.name] = parsed.body?.trim() ?? '';
}

export { componentsList, componentDocs };
