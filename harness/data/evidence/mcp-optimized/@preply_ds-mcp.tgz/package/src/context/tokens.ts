/* eslint-disable import/no-named-as-default-member */
import path from 'node:path';
import { packageRoot, readJson } from '#/utils/fs';
import lunr, { Builder, Token } from 'lunr';
import dedent from 'dedent';
import { z } from 'zod';

const root = packageRoot();
const rawTokens = readJson(
    path.resolve(root, 'src/generated/tokens.json'),
    // prettier-ignore
    z.record(
        z.string(),
        z.object({
            value: z.union([z.string(), z.number()]),
            private: z.boolean(),
        }),
    ),
);

export type TokenData = {
    name: string;
    scss: string;
    less: string;
    typescript: string;
    value: string | number;
    private: boolean;
};

const tokens: TokenData[] = [];

/** @example formatScssName('dropShadow.1.shorthand') // '$drop-shadow-1-shorthand' */
const formatScssName = (name: string) => '$' + name.replace(/\./g, '-');
/** @example formatLessName('dropShadow.1.shorthand') // '@drop-shadow-1-shorthand' */
const formatLessName = (name: string) => '@' + name.replace(/\./g, '-');
/** @example formatTypescriptName('dropShadow.1.shorthand') // 'dropShadow[1].shorthand' */
const formatTypescriptName = (name: string) =>
    name
        .split('.')
        .map(part => {
            const isNumeric = !isNaN(Number(part));
            const hasHyphen = part.includes('-');
            if (isNumeric || hasHyphen) return `[${part}]`;

            return part;
        })
        .join('.')
        .replace(/\.\[/g, '[');

for (const [name, token] of Object.entries(rawTokens)) {
    tokens.push({
        scss: formatScssName(name),
        less: formatLessName(name),
        typescript: formatTypescriptName(name),
        name,
        value: token.value,
        private: token.private,
    });
}

const tokensByName = Object.fromEntries(tokens.map(token => [token.name, token]));
const tokensByScss = Object.fromEntries(tokens.map(token => [token.scss, token]));
const tokensByLess = Object.fromEntries(tokens.map(token => [token.less, token]));
const tokensByTypescript = Object.fromEntries(tokens.map(token => [token.typescript, token]));
const tokensByValue = tokens.reduce(
    (acc, token) => {
        const key = token.value.toString().toLowerCase();
        acc[key] = acc[key] ?? [];
        acc[key].push(token);
        return acc;
    },
    {} as Record<string, TokenData[]>,
);

function normalizeTokenSearchTerm(builder: Builder) {
    function pipeline(token: Token) {
        const originalToken = token.toString();
        const tokenParts = originalToken
            .replace(/[^a-zA-Z0-9]/g, ' ')
            .trim()
            .split(/\s+/);

        return tokenParts.map(part => token.clone().update(() => part));
    }

    lunr.Pipeline.registerFunction(pipeline, 'normalizeTokenSearchTerm');

    builder.pipeline.before(lunr.stemmer, pipeline);
    builder.searchPipeline.before(lunr.stemmer, pipeline);
}

const index = lunr(function () {
    this.ref('name');
    this.field('name');

    this.use(normalizeTokenSearchTerm);

    tokens.forEach(token => {
        this.add(token);
    });
});

export const examples = {
    scss: dedent`
        @use '@preply/ds-web-core/dist/generated/tokens' as *;

        .MyComponent {
            box-shadow: $dropShadow-1-shorthand;
        }
    `,
    less: dedent`
        @import '~@preply/ds-web-core/dist/generated/tokens.less';

        .MyComponent {
            box-shadow: @dropShadow-1-shorthand;
        }
    `,
    typescript: dedent`
        import styled from 'styled-components';
        import { dropShadow } from '@preply/ds-core';
        import { getTokenVar } from '@preply/ds-web-core';

        const MyComponent = styled.div\`
            box-shadow: \${getTokenVar(dropShadow[1].shorthand)};
        \`;
    `,
};

type Format = 'scss' | 'less' | 'typescript';

export function formatToken(token: TokenData, format: Format) {
    return {
        token: token[format],
        value: token.value,
    };
}

export function searchByName(name: string, includePrivate = false) {
    // First, check exact matche
    let exactMatch: TokenData | undefined =
        tokensByName[name] || tokensByScss[name] || tokensByLess[name] || tokensByTypescript[name];

    // Then, searcg using Lunr
    let fuzzyMatch = index
        .search(name)
        .map(result => tokensByName[result.ref])
        .filter(res => res !== exactMatch)
        .slice(0, 10);

    if (!includePrivate) {
        if (exactMatch?.private) {
            exactMatch = undefined;
        }

        fuzzyMatch = fuzzyMatch.filter(token => !token.private);
    }

    return {
        results: fuzzyMatch,
        exactMatch,
    };
}

export function searchByValue(value: string | number, includePrivate = false) {
    let results = tokensByValue[value] ?? [];

    const isNumeric = !isNaN(Number(value));
    // Also get tokens by value with units
    if (isNumeric) {
        const pxResults = tokensByValue[`${value}px`] ?? [];
        const emResults = tokensByValue[`${value}em`] ?? [];
        results = [...results, ...pxResults, ...emResults];
    }

    if (!includePrivate) {
        results = results.filter(token => !token.private);
    }

    return {
        results,
    };
}
