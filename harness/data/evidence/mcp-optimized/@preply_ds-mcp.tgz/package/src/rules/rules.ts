/* eslint-disable security/detect-non-literal-regexp */
/* eslint-disable security/detect-non-literal-fs-filename */
import { packageRoot } from '#/utils/fs';
import path from 'node:path';
import fs from 'node:fs';
import { md } from '#/utils/md';
import { glob } from 'glob';
import { logger } from '#/utils/logger';

const RULES_START_COMMENT = md.comment('design-system-rules');
const RULES_END_COMMENT = md.comment('/design-system-rules');
const RULES_REGEX = new RegExp(
    `${RULES_START_COMMENT}.+${RULES_END_COMMENT}`.replaceAll('/', '\\/'),
    'gs',
);

const root = packageRoot();
const rulesPath = path.resolve(root, 'src/rules/rules.md');
const rulesMd = fs.readFileSync(rulesPath, 'utf8');

/**
 * Returns content of the rules.md file wrapped in the start and end comments:
 *
 * ```md
 * <!-- design-system-rules -->
 * ...
 * <!-- /design-system-rules -->
 * ```
 */
export const getRules = () => md.joinBlocks([RULES_START_COMMENT, rulesMd, RULES_END_COMMENT]);

/**
 * Updates the rules to the latest version.
 *
 * It looks for the rules in known locations and replaces content,
 * placed between `<!-- design-system-rules -->` and `<!-- /design-system-rules -->` comments,
 * with the content of the rules.md.
 */
export const updateRules = () => {
    const rulesPaths = glob.sync(
        [
            // AGENTS.md
            '**/AGENTS.md',
            // Claude code
            '**/CLAUDE.md',
            // Github copilot,
            '.github/copilot-instructions.md',
            '**/*.instructions.md',
            // Cursor
            '**/.cursor/rules/**/*.mdc',
            '.cursorrules',
            // Cline
            '**/.clinerules/**/*.md',
            '.clinerules',
            // Windsurf
            '**/.windsurf/rules/**/*.md',
            '.windsurfrules',
            // Zed
            '.rules',
            // Aider
            'CONVENTIONS.md',
            // Gemini
            'GEMINI.md',
            // Qodo
            'best_practices.md',
            // Amazon Q Developer
            '.amazonq/rules/*.md',
            // JetBrains Junie
            '.junie/guidelines.md',
            // Roo Code
            '.roo/rules/*.md',
        ],
        { ignore: ['node_modules'] },
    );

    for (const rulesPath of rulesPaths) {
        const content = fs.readFileSync(rulesPath, 'utf8');

        if (RULES_REGEX.test(content)) {
            logger.info(`Updating ${rulesPath}`);
            fs.writeFileSync(rulesPath, content.replace(RULES_REGEX, getRules()));
        } else {
            logger.info(`Skipping ${rulesPath}`);
        }
    }
};
