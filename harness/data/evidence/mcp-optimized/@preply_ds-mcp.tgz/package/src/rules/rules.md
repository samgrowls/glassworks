# Use Preply Design System

When doing any changes, involving design system components, such as adding new components, modifying existing components, or changing styles or attributes, ALWAYS use `ds-mcp` tools to get documentation for the component and/or design tokens before making any changes.

## Components

When developing front-end, ALWAYS use components from Preply design system, usually found in `@preply/ds-web-lib` package.

**CRITICAL RULE: NEVER modify DS components styles via className, styled-components or any other way.**

This is strictly forbidden and will lead to broken layout. Examples of forbidden patterns:

- `const StyledText = styled(Text)\`...\``
- `<Text className="my-custom-style">`
- Any styled-component wrapper around DS components

Instead, use DS component props to achieve styling:

- Use `variant` prop for typography variants (e.g., `variant="default-semibold"`)
- Use `accent` prop for text colors (e.g., `accent="secondary"`)
- Wrap DS components in regular styled `div` containers if layout is needed
- Use `Text` or `TextInline` to wrap `Link` for typography customization

Prefer composing DS components together to achieve the desired layout.

# Layout

For simple flex layouts prefer using `LayoutFlex` and `LayoutFlexItem` components over custom styles.
Use custom styles only if you need to achieve a complex layout or if the layout is not possible to achieve with `LayoutFlex` and `LayoutFlexItem` components.

For simple grid layouts prefer using `LayoutGrid` and `LayoutGridItem` components over custom styles.
Use custom styles only if you need to achieve a complex layout or if the layout is not possible to achieve with `LayoutGrid` and `LayoutGridItem` components.

## Icons

Use `@preply/ds-media-icons` package to get icons.

## Typography

For typography, prefer using `Text` (for body text, uses Figtree font) and `Heading` (for headings, uses Platform font) components when possible.

Only use custom styles for typography if it's not possible to achieve the desired style with `Text` and `Heading` components.

## Authoring styles

Use design tokens from Preply design system, usually found in `@preply/ds-core` package.

ALWAYS use design tokens for:

- colors
- spacing
- font sizes
- border radii
- shadows
- font weights
- line heights
- letter spacings

Allowed exceptions are:

- static width and height values, like `320px` or `480px`. Although if there is a `sizing.*` design token for that, use it.
- values like `unset`, `initial`, `inherit`, etc.

Prefer semantic tokens (e.g. `color.background.primary`) over exp and primitive tokens (e.g. `exp.grey.0`).

NEVER use hardcoded values if there is a design token for that.
