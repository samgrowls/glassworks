/* eslint-disable import/no-named-as-default-member */
/* eslint-disable security/detect-non-literal-fs-filename */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import json5 from 'json5';
import fm, { FrontMatterResult } from 'front-matter';
import { z } from 'zod';
import envPaths from 'env-paths';

export const { config: MCP_CONFIG_PATH, data: MCP_DATA_PATH } = envPaths('preply-ds-mcp');

/**
 * When package is built, import.meta.url will point to the dist folder,
 * so paths which are relative to the module folder will be incorrect.
 *
 * This utility finds and returns the path to the root of the package to use for relative paths.
 */
export function packageRoot() {
    let current = path.dirname(fileURLToPath(import.meta.url));
    let found = false;
    while (!found) {
        if (fs.existsSync(path.join(current, 'package.json'))) {
            found = true;
        } else {
            current = path.dirname(current);
        }
    }
    return current;
}

export function writeFile(filename: string, output: string) {
    const dirname = path.dirname(filename);
    if (!fs.existsSync(dirname)) {
        fs.mkdirSync(dirname, { recursive: true });
    }

    fs.writeFileSync(filename, output);
}

/**
 * Reads JSON file and validates it with the provided Zod schema.
 */
export function readJson<T>(filename: string, schema: z.ZodSchema<T>): T {
    const content = fs.readFileSync(filename, 'utf8');
    const parsed = JSON.parse(content);
    return schema.parse(parsed);
}

/**
 * Reads JSON5 file and validates it with the provided Zod schema.
 */
export function readJson5<T>(filename: string, schema: z.ZodSchema<T>): T {
    const content = fs.readFileSync(filename, 'utf8');
    const parsed = json5.parse(content);
    return schema.parse(parsed);
}

/**
 * Reads Markdown file with front matter and validates it with the provided Zod schema.
 */
export function readMd<T>(filename: string, schema: z.ZodSchema<T>) {
    const content = fs.readFileSync(filename, 'utf8');
    const parsed = fm(content);
    const validatedAttributes = schema.parse(parsed.attributes);
    return {
        ...parsed,
        attributes: validatedAttributes,
    } as FrontMatterResult<T>;
}

export function listDirFiles(dirname: string) {
    return fs
        .readdirSync(dirname)
        .filter(filename => fs.statSync(path.join(dirname, filename)).isFile());
}
