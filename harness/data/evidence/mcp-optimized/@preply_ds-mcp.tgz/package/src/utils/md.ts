import * as tsmd from 'ts-markdown-builder';
import { stringify } from 'yaml';

function frontMatter(object: Record<string, unknown>): string {
    if (Object.keys(object).length === 0) return '';

    const yaml = stringify(object).trim();

    return [tsmd.horizontalRule, yaml, tsmd.horizontalRule].join('\n');
}

export const md = { ...tsmd, frontMatter, comment: (comment: string) => `<!-- ${comment} -->` };
