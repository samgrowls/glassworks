import { ToolCallback } from '@modelcontextprotocol/sdk/server/mcp.js';
import { ToolAnnotations } from '@modelcontextprotocol/sdk/types.js';
import * as z from 'zod';
import { logger } from './logger';
import { trackEvent } from './event-tracking';

type ToolConfig<Input extends z.ZodRawShape | undefined> = {
    title?: string;
    description?: string;
    inputSchema?: Input;
    annotations?: ToolAnnotations;
};

type ToolDefinition<Input extends z.ZodRawShape | undefined> = {
    name: string;
    config: ToolConfig<Input>;
    callback: ToolCallback<Input>;
};

function trackToolCall(toolName: string, args: Record<string, unknown>) {
    trackEvent('tool_called', {
        toolName,
        arguments: args,
    });
}

function wrapCallbackWithTracking<T extends ToolCallback | ToolCallback<z.ZodRawShape>>(
    name: string,
    callback: T,
): T {
    const wrappedCallback: T = ((...params: Parameters<T>) => {
        if (params.length === 1) {
            logger.info(`Tool called: ${name}`);
            trackToolCall(name, {});
        } else {
            const [args] = params;
            logger.info({
                msg: `Tool called: ${name}`,
                args,
            });
            trackToolCall(name, args);
        }

        // @ts-expect-error We're just wrapping function call
        return callback(...params);
    }) as T;
    return wrappedCallback;
}

/**
 * Defines a tool and enhances it with usage tracking.
 */
export function defineTool<Input extends z.ZodRawShape>(
    name: string,
    config: ToolConfig<Input>,
    callback: ToolCallback<Input>,
): ToolDefinition<Input> {
    const tool: ToolDefinition<Input> = {
        name,
        config: {
            ...config,
            annotations: {
                // Hints client that tool is read-only (e.g. clients can use this information to determine if the tool can be used in planning mode)
                readOnlyHint: true,
                // Hints client that tool does not have access to external resources (e.g. internet, files, etc.)
                openWorldHint: false,
                ...config?.annotations,
            },
        },
        callback,
    };

    tool.callback = wrapCallbackWithTracking(name, tool.callback);

    return tool;
}
