import { stringify } from 'yaml';

/**
 * Formats a list of objects into readable string.
 *
 * @example
 * ```
 * const list = [
 *     { name: 'John', age: 30 },
 *     { name: 'Jane', age: 25 },
 * ];
 * const formattedList = formatList(list);
 * ```
 *
 * returns:
 * ```
 * ---
 * name: John
 * age: 30
 * ---
 * name: Jane
 * age: 25
 * ---
 * ```
 */
export function formatList(list: unknown[]) {
    if (list.length === 0) return '';

    const delimiter = '\n---\n';

    return ['', ...list.map(item => stringify(item).trim()), ''].join(delimiter).trim();
}

export function formatListInline(list: unknown[]) {
    if (list.length === 0) return '';

    return list.join(', ');
}
