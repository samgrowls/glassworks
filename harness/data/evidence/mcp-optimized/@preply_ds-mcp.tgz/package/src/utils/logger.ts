/* eslint-disable security/detect-non-literal-fs-filename */
import pino from 'pino';
import path from 'path';
import { MCP_DATA_PATH } from './fs';
import fs from 'fs';
import pinoPretty from 'pino-pretty';
import { spawn } from 'child_process';

const logsPath = path.join(MCP_DATA_PATH, 'logs/');

export const logger = pino({
    transport:
        process.env.MCP_LOGGING === 'file'
            ? // Log to file
              {
                  target: 'pino-roll',
                  options: {
                      file: logsPath,
                      mkdir: true,
                      frequency: 'daily',
                      size: '10m',
                      symlink: true,
                      limit: {
                          count: 7,
                      },
                  },
              }
            : // Pretty console output (for scripts)
              {
                  target: 'pino-pretty',
                  options: {
                      colorize: true,
                      ignore: 'pid,hostname',
                  },
              },
});

/**
 * Read and tail the current log file with pretty formatting.
 * Used by the 'logs' CLI command to display logs in a human-readable format.
 */
export function readFileLogs() {
    const currentLogFile = path.join(logsPath, 'current.log');
    if (!fs.existsSync(currentLogFile)) {
        console.error(`Log file not found: ${currentLogFile}`);
        console.error('Start the MCP server first to generate logs.');
        process.exit(1);
    }
    console.log(`Reading debug logs from ${currentLogFile}\n`);

    // Use tail to follow the file and pipe through pino-pretty
    const tail = spawn('tail', ['-f', currentLogFile]);
    const pretty = pinoPretty({
        colorize: true,
        ignore: 'pid,hostname',
    });
    tail.stdout.pipe(pretty);

    tail.on('error', error => {
        console.error('Error reading debug logs:', error);
        process.exit(1);
    });
    pretty.on('error', error => {
        console.error('Error formatting logs:', error);
        process.exit(1);
    });

    // Handle cleanup on exit
    process.on('SIGINT', () => {
        tail.kill();
        process.exit(0);
    });
}
