/* eslint-disable security/detect-non-literal-fs-filename */
import { PostHog } from 'posthog-node';
import { MCP_DATA_PATH, writeFile } from './fs';
import fs from 'fs';
import path from 'path';
import { logger } from './logger';
import { userInfo } from 'os';
import pkg from '../../package.json' with { type: 'json' };

/**
 * Returns persistent client ID or null if it failed to generate.
 * Can be used to identify a client across sessions when user name is not available.
 */
function getUserId() {
    try {
        // Try to read client ID from file or generate a new one
        const clientIdPath = path.join(MCP_DATA_PATH, 'client-id.txt');
        try {
            return fs.readFileSync(clientIdPath, 'utf8');
        } catch {
            const clientId = crypto.randomUUID();
            writeFile(clientIdPath, clientId);
            return clientId;
        }
    } catch (error) {
        logger.error({
            msg: 'Failed to generate client ID',
            error,
        });
        return crypto.randomUUID();
    }
}

/**
 * Returns current user name or null if it's not available.
 */
function getUserName() {
    try {
        const userName = userInfo().username;
        return userName;
    } catch (error) {
        logger.error({
            msg: 'Failed to get user name',
            error,
        });
        return null;
    }
}

const client = new PostHog('phc_idhNqodmRjwHSolig26UgSRsgb6pIyYRIvIBzgNAkGZ', {
    host: 'https://eu.i.posthog.com',
});

export function identify() {
    try {
        const userId = getUserId();
        const userName = getUserName();
        const data = {
            distinctId: userId,
            properties: {
                userName,
            },
        };
        client.identify(data);
        logger.debug({ msg: 'User identified', userData: data });
    } catch (error) {
        logger.error({
            msg: 'Failed to identify user',
            error,
        });
    }
}

export function trackEvent(eventName: string, properties?: Record<string, unknown>) {
    try {
        const userId = getUserId();
        const data = {
            distinctId: userId,
            event: eventName,
            properties: {
                ...properties,
                mcpVersion: pkg.version,
            },
        };
        client.capture(data);
        logger.debug({ msg: 'Event tracked', eventData: data });
    } catch (error) {
        logger.error({
            msg: 'Failed to track event',
            error,
        });
    }
}
