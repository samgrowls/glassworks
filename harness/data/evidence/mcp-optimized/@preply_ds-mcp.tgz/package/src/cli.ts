import { program } from 'commander';
import pkg from '../package.json' with { type: 'json' };
import { startServer } from './server';
import { readFileLogs } from './utils/logger';
import { getRules, updateRules } from './rules/rules';

// prettier-ignore
program
    .name('ds-mcp')
    .description(pkg.description)
    .version(pkg.version, '-v, --version', 'Output the version number')
    .usage('<command>');

// prettier-ignore
program
    .command('start')
    .description('Start the MCP server')
    .option('--verbose', 'Enable verbose logging')
    .action(startServer);

// prettier-ignore
program
    .command('logs')
    .description('Output logs to the console')
    .action(readFileLogs);

const rules = program
    .command('rules')
    .description('Output the AI rules')
    .action(() => console.log(getRules()));

rules
    .command('update')
    .description('Updates the AI rules to the current version')
    .action(() => updateRules());

program.parse();
