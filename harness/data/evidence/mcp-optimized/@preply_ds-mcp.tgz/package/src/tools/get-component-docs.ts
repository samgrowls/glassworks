import * as z from 'zod';
import { defineTool } from '../utils/define-tool';
import { componentDocs } from '#/context/components';

export const getComponentDocs = defineTool(
    'get-component-docs',
    {
        title: 'Get Component Docs',
        description:
            'Returns the documentation for a specific component in the Preply design system.',
        inputSchema: {
            name: z.string().describe('The name of the component'),
        },
    },
    input => {
        const docs = componentDocs[input.name];

        if (!docs) {
            return {
                content: [
                    {
                        type: 'text',
                        text: `Component "${input.name}" not found`,
                    },
                ],
                isError: true,
            };
        }

        return {
            content: [
                {
                    type: 'text',
                    text: docs,
                },
            ],
        };
    },
);
