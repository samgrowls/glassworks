import { examples, formatToken, searchByName } from '#/context/tokens';
import { stringify } from 'yaml';
import { defineTool } from '../utils/define-tool';
import * as z from 'zod';
import dedent from 'dedent';
import { formatList } from '#/utils/format-list';

export const searchTokenByName = defineTool(
    'search_token_by_name',
    {
        title: 'Search Token by Name',
        description: 'Search for a design system style tokens by name',
        inputSchema: {
            name: z.string().describe(
                dedent`
                    The token name to search for. This can be in any format:
                    - raw token name (e.g. dropShadow.1.shorthand)
                    - scss (e.g. $dropShadow-1-shorthand)
                    - less (e.g. @dropShadow-1-shorthand)
                    - typescript (e.g. dropShadow[1].shorthand)

                    You also can use partial query (e.g. "dropShadow") if exact name is not known.
                `,
            ),
            format: z.enum(['scss', 'less', 'typescript']).describe(dedent`
                    The format of the token. Allowed values are:
                    - "scss" - SCSS variable (e.g. $drop-shadow-1-shorthand)
                    - "less" - Less variable (e.g. @drop-shadow-1-shorthand)
                    - "typescript" - Typescript variable for usage in styled-components (e.g. dropShadow[1].shorthand)

                    If preferred format is ambiguous, you MUST ask the user to specify desired format.
                `),
            includeExample: z
                .boolean()
                .default(true)
                .describe('Whether to include an usage example. Default: true'),
            // prettier-ignore
            includePrivate: z
                .boolean()
                .default(false)
                .describe(dedent`
                    Whether to include private tokens. Default: false

                    Private tokens starts from "dsInternalPrimitive" or "root" prefixes.
                    They're not intended for public use, however they're still available in the system.
                    Only use this option if you wasn't able to find public token or you're confident that private token is what you need.
                `),
        },
    },
    ({ name, format, includeExample, includePrivate }) => {
        const { results, exactMatch } = searchByName(name, includePrivate);

        if (!results.length && !exactMatch) {
            return {
                content: [
                    {
                        type: 'text',
                        text: `No results found for "${name}"`,
                    },
                ],
            };
        }

        const formattedResults = results.map(result => formatToken(result, format));

        const exampleMessages = includeExample
            ? ([
                  {
                      type: 'text',
                      text: `Here is an example of how to use design-system tokens in ${format}:`,
                  },
                  {
                      type: 'text',
                      text: examples[format],
                  },
              ] as const)
            : [];

        if (exactMatch) {
            const similarMessages =
                results.length > 0
                    ? ([
                          {
                              type: 'text',
                              text: 'Also, here you can find some tokens with similar names:',
                          },
                          { type: 'text', text: formatList(formattedResults) },
                      ] as const)
                    : [];

            return {
                content: [
                    {
                        type: 'text',
                        text: `Found exact match for "${name}":`,
                    },
                    {
                        type: 'text',
                        text: stringify(formatToken(exactMatch, format)).trim(),
                    },
                    ...exampleMessages,
                    ...similarMessages,
                ],
            };
        }

        return {
            content: [
                {
                    type: 'text',
                    text: `There is no exact match for "${name}", but here are some similar tokens:`,
                },
                {
                    type: 'text',
                    text: formatList(formattedResults),
                },
                ...exampleMessages,
            ],
        };
    },
);
