import * as z from 'zod';
import { defineTool } from '../utils/define-tool';
import { ensureTokyoUiPrefix, searchByName } from '#/context/icons';
import dedent from 'dedent';
import { formatListInline } from '#/utils/format-list';

function usageExample(name: string) {
    const fullIconName = ensureTokyoUiPrefix(name);

    return dedent`
        import ${fullIconName} from '@preply/ds-media-icons/dist/24/${fullIconName}.svg';
        import { Icon } from '@preply/ds-web-lib';

        <Icon svg={<${fullIconName} />} />
    `;
}

export const searchIcon = defineTool(
    'search_icon',
    {
        title: 'Search Icon by Name',
        description: 'Search icons available in @preply/ds-media-icons',
        inputSchema: {
            name: z.string().describe(dedent`
                The icon name to search for.
                It can be provided with or without the "TokyoUI" prefix (e.g. "Close" or "TokyoUIClose").
            `),
            includeExample: z
                .boolean()
                .default(true)
                .describe('Whether to include an usage example. Default: true'),
        },
    },
    ({ name, includeExample }) => {
        const { results, exactMatch } = searchByName(name);

        if (!results.length && !exactMatch) {
            return {
                content: [
                    {
                        type: 'text',
                        text: `No results found for "${name}"`,
                    },
                ],
            };
        }

        if (exactMatch) {
            const exampleMessages = includeExample
                ? ([
                      {
                          type: 'text',
                          text: 'To use the icon, import it from @preply/ds-media-icons/dist/24/ with the TokyoUI prefix and use the Icon component:',
                      },
                      { type: 'text', text: usageExample(exactMatch) },
                  ] as const)
                : [];

            const similarMessages =
                results.length > 0
                    ? ([
                          {
                              type: 'text',
                              text: 'Also, here you can find some icons with similar names:',
                          },
                          { type: 'text', text: formatListInline(results) },
                      ] as const)
                    : [];

            return {
                content: [
                    {
                        type: 'text',
                        text: `Found exact match. The full icon name is "${ensureTokyoUiPrefix(exactMatch)}".`,
                    },
                    ...exampleMessages,
                    ...similarMessages,
                ],
            };
        }

        const exampleMessages = includeExample
            ? ([
                  {
                      type: 'text',
                      text: 'To use the icon, import it from @preply/ds-media-icons/dist/24/ with the TokyoUI prefix and use the Icon component:',
                  },
                  { type: 'text', text: usageExample('Close') },
              ] as const)
            : [];

        return {
            content: [
                {
                    type: 'text',
                    text: `There is no exact match for "${name}" query, but here are some icons with similar names:`,
                },
                { type: 'text', text: formatListInline(results) },
                ...exampleMessages,
            ],
        };
    },
);
