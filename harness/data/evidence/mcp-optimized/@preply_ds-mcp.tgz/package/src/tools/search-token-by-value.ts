import { examples, formatToken, searchByValue } from '#/context/tokens';
import { defineTool } from '../utils/define-tool';
import * as z from 'zod';
import dedent from 'dedent';
import { formatList } from '#/utils/format-list';

export const searchTokenByValue = defineTool(
    'search_token_by_value',
    {
        title: 'Search Token by Value',
        description: 'Search for a design system style tokens by its value',
        inputSchema: {
            value: z.string().describe(
                dedent`
                    The token value to search for. This can be:
                    - numeric values (e.g. 500)
                    - colors (e.g. #000000 or rgba(0, 0, 0, 0.5))
                    - sizes (e.g. 16px or 2em)
                    - fonts (e.g. Inter or Arial)
                    - etc.
                `,
            ),
            format: z.enum(['scss', 'less', 'typescript']).describe(dedent`
                    The output format. Allowed values are:
                    - "scss" - SCSS variable (e.g. $drop-shadow-1-shorthand)
                    - "less" - Less variable (e.g. @drop-shadow-1-shorthand)
                    - "typescript" - Typescript variable for usage in styled-components (e.g. dropShadow[1].shorthand)
        
                    If preferred format is ambiguous, you MUST ask the user to specify desired format.
                `),
            includeExample: z
                .boolean()
                .default(true)
                .describe('Whether to include an usage example. Default: true'),
            // prettier-ignore
            includePrivate: z
                .boolean()
                .default(false)
                .describe(dedent`
                    Whether to include private tokens. Default: false

                    Private tokens starts from "dsInternalPrimitive" or "root" prefixes.
                    They're not intended for public use, however they're still available in the system.
                    Only use this option if you wasn't able to find public token or you're confident that private token is what you need.
                `),
        },
    },
    ({ value, format, includeExample, includePrivate }) => {
        const { results } = searchByValue(value, includePrivate);

        if (!results.length) {
            return {
                content: [
                    {
                        type: 'text',
                        text: `No results found for "${value}"`,
                    },
                ],
            };
        }

        const formattedResults = results.map(result => formatToken(result, format));

        const exampleMessages = includeExample
            ? ([
                  {
                      type: 'text',
                      text: `Here is an example of how to use design-system tokens in ${format}:`,
                  },
                  {
                      type: 'text',
                      text: examples[format],
                  },
              ] as const)
            : [];

        return {
            content: [
                {
                    type: 'text',
                    text: `Found ${results.length} tokens with value "${value}"`,
                },
                {
                    type: 'text',
                    text: formatList(formattedResults),
                },
                ...exampleMessages,
            ],
        };
    },
);
