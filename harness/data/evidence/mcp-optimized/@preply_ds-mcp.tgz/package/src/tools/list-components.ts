import { defineTool } from '../utils/define-tool';
import { componentsList } from '#/context/components';
import { formatList } from '#/utils/format-list';
import dedent from 'dedent';
import { getComponentDocs } from './get-component-docs';

const formattedComponentsList = formatList(componentsList);

export const listComponents = defineTool(
    'list-components',
    {
        title: 'List Components',
        description: dedent`
            Returns a list of all available components in the Preply design system,
            available in @preply/ds-web-lib and @preply/ds-web-root packages.
        `,
    },
    () => {
        return {
            content: [
                {
                    type: 'text',
                    text: dedent`
                        Each item has the following fields:
                        - name - The name of the component (e.g. Button)
                        - import - The import path of the component (e.g. "import { Button } from '@preply/ds-web-lib';")
                        - description - The description of the component
                        - deprecated - Whether the component is deprecated (false if missing)
                        
                        You can request the documentation for a specific component by using the "${getComponentDocs.name}" tool.
                    `,
                },
                {
                    type: 'text',
                    text: formattedComponentsList,
                },
            ],
        };
    },
);
