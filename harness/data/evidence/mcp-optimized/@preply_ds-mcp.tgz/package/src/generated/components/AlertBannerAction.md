---
name: AlertBannerAction
import: import { AlertBannerAction } from '@preply/ds-web-lib';
description: The AlertBannerAction is a container that sets defaults when Button
  or IconButton are passed.
---

# AlertBannerAction

```
import { AlertBannerAction } from '@preply/ds-web-lib';
```

The AlertBannerAction is a container that sets defaults when Button or IconButton are passed.

@example

```
<AlertBannerAction className={myCustomStyle}>
  <Button {...} />
</AlertBannerAction>

If you want the default action but need to pass your own props to it, you
can use the `DefaultAlertBannerAction` component.
<AlertBannerAction>
   <Button
     leadingSvgIcon={MyCustomIcon}
   >
      My custom text
   </Button
</AlertBannerAction>
```

@see

Button *
IconButton

## Props

### `id`

- Type: `string | undefined`

### `dataset`

- Type: `Dataset | undefined`

### `dsInternalSimulation`

- Type: `"focus" | "hover" | "active" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `onClick`

- Type: `MouseEventHandler | undefined`

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `variant`

- Type: `ButtonVariant | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "quaternary" | "ghost" | "critical" | "onColor" | "classroom" | "primaryB2b" | "primaryTutor" | "inverted" | "newFeature" | "ai"`

### `size`

- Type: `Responsive<ButtonSize> | undefined`
- Detailed type: `undefined | "large" | "medium" | "small" | ResponsiveProp<ButtonSize>`

### `fullWidth`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `wrap`

- Type: `boolean | undefined`

### `href`

- Type: `string | undefined`

### `download`

- Type: `boolean | undefined`

### `opensInNewTab`

- Type: `boolean | undefined`

### `nofollow`

- Type: `boolean | undefined`

### `submitsForm`

- Type: `boolean | undefined`

### `assistiveText`

- Type: `string | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler | undefined`

### `onMouseDown`

- Type: `MouseEventHandler | undefined`

### `onMouseUp`

- Type: `MouseEventHandler | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler | undefined`

### `onMouseMove`

- Type: `MouseEventHandler | undefined`

### `onPointerDown`

- Type: `MouseEventHandler | undefined`

### `onPointerEnter`

- Type: `MouseEventHandler | undefined`

### `disabled`

- Type: `boolean | undefined`

### `busy`

- Type: `boolean | undefined`

Replaces the content with a loading indicator.

### `as`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

Custom element to render the button.

Allows rendering the button using a different React element or component.
This is particularly useful for integrating with router libraries like `react-router` or `next/router`.

@example

```
// Render as a react router link component
import { Link } from 'react-router-dom';

<ButtonBase as={<Link to="/home" />} />
```

### `url`

- Type: `string | undefined`

@deprecated

Use `href` instead

### `a11yLabel`

- Type: `string | undefined`

@deprecated

Use `assistiveText` instead

### `leadingSvgIcon`

- Type: `SvgComponentOrElement | undefined`
- Detailed type: `undefined | ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`

The leading SVG icon.

@example

```
import TokyoUITag from '@preply/ds-media-icons/dist/24/TokyoUITag.svg';

<Button leadingSvgIcon={TokyoUITag}>Button</Button>
or
<Button leadingSvgIcon={<TokyoUITag />}>Button</Button>
```

### `trailingSvgIcon`

- Type: `SvgComponentOrElement | undefined`
- Detailed type: `undefined | ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`

The trailing SVG icon.

@example

```
import TokyoUITag from '@preply/ds-media-icons/dist/24/TokyoUITag.svg';

<Button trailingSvgIcon={TokyoUITag}>Button</Button>
or
<Button trailingSvgIcon={<TokyoUITag />}>Button</Button>
```

### `className`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}