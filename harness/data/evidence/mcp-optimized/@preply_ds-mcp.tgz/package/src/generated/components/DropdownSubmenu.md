---
name: DropdownSubmenu
import: import { DropdownSubmenu } from '@preply/ds-web-lib';
description: Dropdown sub-menu
---

# DropdownSubmenu

```
import { DropdownSubmenu } from '@preply/ds-web-lib';
```

Dropdown sub-menu

@example

```
<DropdownSubmenu
  label="Submenu"
>
  <DropdownMenuItem label="Item 1" />
  <DropdownMenuItem label="Item 2" />
  <DropdownMenuItem label="Item 3" />
</DropdownSubmenu>
```

## Props

### `dataset`

- Type: `Dataset | undefined`

### `disabled`

- Type: `boolean | undefined`

Whether the menu item is disabled.

### `description`

- Type: `ReactNode`

Menu description

### `leadingElement`

- Type: `ReactNode`

Menu leading element. Can be an icon, flag or avatar.

@example

```
<DropdownMenuItem leadingElement={<Icon size="24" name="home" />} />
<DropdownMenuItem leadingElement={<CountryFlag size="medium" code="US" />} />
<DropdownMenuItem leadingElement={<Avatar size="24" />} />
```

### `label`

- Type: `ReactNode`
- Required

Menu label

### `side`

- Type: `Side | undefined`
- Detailed type: `undefined | "top" | "bottom" | "left" | "right" | "inline-end" | "inline-start"`
- Default value: `'bottom'`

Which side of the anchor element to align the popup against.
May automatically change to avoid collisions.

### `align`

- Type: `Align | undefined`
- Detailed type: `undefined | "center" | "start" | "end"`
- Default value: `'center'`

How to align the popup relative to the specified side.

### `defaultOpen`

- Type: `boolean | undefined`

Whether the submenu is open by default if not controlled.

### `open`

- Type: `boolean | undefined`

Whether the submenu is open.

### `onOpenChange`

- Type: `((open: boolean, eventDetails: ChangeEventDetails) => void) | undefined`

Callback function that is called when the submenu is opened or closed.
See https://base-ui.com/react/handbook/customization#base-ui-events

### `children`

- Type: `ReactNode | ReactNode[]`
- Detailed type: `undefined | null | string | number | false | true | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | ReactNode[]`
- Required

Submenu content.

### `triggerDataset`

- Type: `Dataset | undefined`

Dataset passed to the trigger opening the submenu.

### `keepMounted`

- Type: `boolean | undefined`

Keeps the submenu content mounted even when the submenu is closed.

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`