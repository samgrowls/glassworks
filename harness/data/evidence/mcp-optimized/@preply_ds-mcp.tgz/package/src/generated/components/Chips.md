---
name: Chips
import: import { Chips } from '@preply/ds-web-lib/components/deprecated';
description: |-
  A Chips container.

  Add `Chips.Item` children to render a list of Chips.
deprecated: true
---

# Chips

```
import { Chips } from '@preply/ds-web-lib/components/deprecated';
```

A Chips container.

Add `Chips.Item` children to render a list of Chips.

@deprecated

Use `SingleSelectChips`, `MultiSelectChips`, or `DismissibleChips` instead.

@see

{@link https://ds.preply.org/latest/?path=/docs/components-chips-singleselectchips--docs SingleSelectChips}
{@link https://ds.preply.org/latest/?path=/docs/components-chips-multiselectchips--docs MultiSelectChips}
{@link https://ds.preply.org/latest/?path=/docs/components-chips-dismissiblechips--docs DismissibleChips}

## Props

### `variant`

- Type: `"choice" | "filter" | undefined`
- Default value: `choice`

The Chip list variant;
- For simple checkbox-like behaviour, use `choice`.
- For more complex filtering controls, use `filter`.

### `aria-label`

- Type: `string`
- Required

Allows assistive technologies to correctly identify and announce
the Chip list.

@example

```
<Chips aria-label="tutor filter">
  // When the Chip below is in focus, screen readers may announce it as:
  // "tutor filter list, option 1, Availability, press to toggle"
  <Chips.Item label="Availability" />
</Chips>
```

### `children`

- Type: `ReactNode`
- Required

These should be `Chips.Item`s.

### `dataset`

- Type: `Dataset | undefined`