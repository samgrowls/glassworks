---
name: SSRProvider
import: import { SSRProvider } from '@preply/ds-web-root';
description: ""
---

# SSRProvider

```
import { SSRProvider } from '@preply/ds-web-root';
```

## Props

### `hostname`

- Type: `HostnameContextState`
- Detailed type: `undefined | string`
- Required

### `stylesheet`

- Type: `ServerStyleSheetInterface`
- Required