---
name: MultiSelectChips
import: import { MultiSelectChips } from '@preply/ds-web-lib';
description: >-
  A chips component that allows selection of multiple options from a group.

  Users can select multiple chips, and clicking a selected chip will deselect
  it.
---

# MultiSelectChips

```
import { MultiSelectChips } from '@preply/ds-web-lib';
```

A chips component that allows selection of multiple options from a group.
Users can select multiple chips, and clicking a selected chip will deselect it.

@remarks

**Keyboard interactions:**
- **Tab** to enter/exit the component (uses [roving tabindex pattern](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/#kbd_roving_tabindex))
- **Arrow keys** to navigate between chips within the group
- **Space/Enter** to toggle selection of the focused chip

@example

````
```tsx
<MultiSelectChips aria-label="Select skills" defaultValue={['vocabulary', 'speaking']}>
  <MultiSelectChipsItem value="vocabulary">Vocabulary</MultiSelectChipsItem>
  <MultiSelectChipsItem value="speaking">Speaking</MultiSelectChipsItem>
  <MultiSelectChipsItem value="listening">Listening</MultiSelectChipsItem>
</MultiSelectChips>
```
````

## Props

### `aria-label`

- Type: `string`
- Required

Accessible label for the chips group. Required for screen reader users

### `dataset`

- Type: `Dataset | undefined`

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `defaultValue`

- Type: `T[] | undefined`

Default value for uncontrolled usage. Will be ignored if `value` is provided

### `aria-controls`

- Type: `string | undefined`

If the chips control other elements on the page, use `aria-controls` with the target element's ID.

### `value`

- Type: `T[] | undefined`

Current value of the chips. When provided, the component operates in controlled mode

### `onValueChange`

- Type: `((value: T[]) => void) | undefined`

Callback fired when the value changes. Receives the new value as an argument

### `orientation`

- Type: `Orientation | undefined`
- Detailed type: `undefined | "horizontal" | "vertical"`
- Default value: `'horizontal'`

Layout orientation of the chips group.

### `items`

- Type: `(Omit<ChipsItemProps, "dsInternalSimulation" | "children" | "value"> & { value: NonNullable<T>; label: ReactNode; })[] | undefined`
- Detailed type: `undefined | (Omit<ChipsItemProps, "dsInternalSimulation" | "children" | "value"> & { value: NonNullable<T>; label: ReactNode; })[]`

### `ref`

- Type: `((instance: HTMLUListElement | null) => void) | RefObject<HTMLUListElement> | null | undefined`
- Detailed type: `undefined | null | (instance: HTMLUListElement | null) => void | RefObject<HTMLUListElement>`