---
name: Checkbox
import: import { Checkbox } from '@preply/ds-web-lib';
description: "To make this accessible, you must label it using a `<label>` or `aria-label`:"
---

# Checkbox

```
import { Checkbox } from '@preply/ds-web-lib';
```

To make this accessible, you must label it using a `<label>` or `aria-label`:

@example

```
Using `<label>` parent
<label>
Setting:
<Checkbox />
</label>
Using `<label>` sibling
<label id="setting-label">Setting:</label>
<Checkbox aria-labelledby="setting-label" />
Using `aria-label`
<Checkbox aria-label="Setting" />

It is uncontrolled by default, and can be manually controlled via the `checked` prop.
```

## Props

### `id`

- Type: `string | undefined`

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `name`

- Type: `string | undefined`

### `disabled`

- Type: `boolean | undefined`

### `defaultChecked`

- Type: `boolean | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onChange`

- Type: `ChangeEventHandler<HTMLInputElement> | undefined`

### `checked`

- Type: `boolean | undefined`

### `required`

- Type: `boolean | undefined`

### `hasError`

- Type: `boolean | undefined`

Shows the component's error state, and sets `aria-invalid="true"` on the input element.

### `indeterminate`

- Type: `boolean | undefined`

Makes the component look indeterminate. Please note that the indeterminate state is parallel
to che checked/unchecked state, meaning that a checkbox can be checked and indeterminate at
the same time. it's up to you to handle the logic of when to set this prop.

If you're implementing a tri-state checkbox group, pleas refer to the
{@link https://www.w3.org/WAI/ARIA/apg/patterns/checkbox/ARIA Checkbox Pattern}.

### `onCheckedChange`

- Type: `((checked: boolean) => void) | undefined`

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Checkbox dataset={{ 'qa-id': 'accept-conditions' }} /> // will add data-qa-id="accept-conditions" to the HTML element
```

### `dsInternalSimulation`

- Type: `"focus" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `ref`

- Type: `LegacyRef<HTMLInputElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLInputElement | null) => void | RefObject<HTMLInputElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`