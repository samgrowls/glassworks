---
name: Loader
import: import { Loader } from '@preply/ds-web-lib';
description: ""
---

# Loader

```
import { Loader } from '@preply/ds-web-lib';
```

## Props

### `size`

- Type: `Responsive<SpinnerSize> | undefined`
- Detailed type: `undefined | "large" | "default" | ResponsiveProp<SpinnerSize>`

### `inverted`

- Type: `boolean | undefined`
- Default value: `false`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`