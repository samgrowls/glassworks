---
name: BubbleCounter
import: import { BubbleCounter } from '@preply/ds-web-lib';
description: ""
---

# BubbleCounter

```
import { BubbleCounter } from '@preply/ds-web-lib';
```

## Props

### `count`

- Type: `number | undefined`

The counter's current value;

- If `undefined`, the counter is not rendered.
- If above `limit`, the `limit` value is rendered instead, with a `+`
  suffix.

### `showEmpty`

- Type: `boolean | undefined`
- Default value: `false`

If `true`, the counter will render even if `count` is `undefined`.

### `limit`

- Type: `number | undefined`
- Default value: `99`

### `size`

- Type: `"large" | "medium" | "small" | undefined`
- Default value: `large`

### `variant`

- Type: `"light" | "dark" | undefined`
- Default value: `dark`

### `children`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

When provided, the `BubbleCounter` will position itself as an indicator
overlay above the target child element.

This is intended to work on just one child, but will not throw errors if
you pass multiple children in order to avoid breaking UX unnecessarily.

### `dataset`

- Type: `Dataset | undefined`