---
name: LayoutFlex
import: import { LayoutFlex } from '@preply/ds-web-lib';
description: A component for rendering flex layout
---

# LayoutFlex

```
import { LayoutFlex } from '@preply/ds-web-lib';
```

A component for rendering flex layout

@example

```
<LayoutFlex direction="column" gap="12">
    <div />
    <div />
</LayoutFlex>
LayoutFlex can be nested to create more complex layouts

<LayoutFlex direction="column" gap="12">
    <LayoutFlex gap="24">
        <div />
        <div />
    </LayoutFlex>
    <div />
</LayoutFlex>
```

## Props

### `gap`

- Type: `"24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | ResponsiveProp<LayoutGap> | ResponsiveProp<Spacing> | undefined`

The `gap` property is used to set the spacing between flex items.

Numeric values correspond to the `px` unit.

T-shirt size values like `xs`, `sm`, `md`, `lg`, `xl` are deprecated.

### `padding`

- Type: `Responsive<"24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | [LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding] | [...] | [...] | [...] | [...]> | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | [LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding, LayoutPadding] | [Spacing, Spacing] | [Spacing, Spacing, Spacing] | [Spacing, Spacing, Spacing, Spacing] | ResponsiveProp<"24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | [LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding] | [...] | [...] | [...] | [...]>`

### `nowrap`

- Type: `boolean | undefined`

### `column`

- Type: `boolean | undefined`

@deprecated

Use `direction` instead.

### `reverse`

- Type: `boolean | undefined`

@deprecated

Use `direction` instead.

### `direction`

- Type: `Responsive<LayoutFlexDirection> | undefined`
- Detailed type: `undefined | "row" | "column" | "row-reverse" | "column-reverse" | ResponsiveProp<LayoutFlexDirection>`

### `justifyContent`

- Type: `Responsive<LayoutJustifyContent> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "space-between" | "space-around" | "space-evenly" | ResponsiveProp<LayoutJustifyContent>`

### `alignItems`

- Type: `Responsive<LayoutAlignItems> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "stretch" | "baseline" | ResponsiveProp<LayoutAlignItems>`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `hide`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `relative`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `inline`

- Type: `boolean | undefined`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLElement | null) => void | RefObject<HTMLElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`