---
name: IconButton
import: import { IconButton } from '@preply/ds-web-lib';
description: ""
---

# IconButton

```
import { IconButton } from '@preply/ds-web-lib';
```

## Props

### `id`

- Type: `string | undefined`

### `dataset`

- Type: `Dataset | undefined`

### `dsInternalSimulation`

- Type: `"focus" | "hover" | "active" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `onClick`

- Type: `MouseEventHandler | undefined`

### `variant`

- Type: `ButtonVariant | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "quaternary" | "ghost" | "critical" | "onColor" | "classroom" | "primaryB2b" | "primaryTutor" | "inverted" | "newFeature" | "ai"`
- Default value: `primary`

### `size`

- Type: `Responsive<ButtonSize> | undefined`
- Detailed type: `undefined | "large" | "medium" | "small" | ResponsiveProp<ButtonSize>`
- Default value: `small`

### `href`

- Type: `string | undefined`

### `download`

- Type: `boolean | undefined`

### `opensInNewTab`

- Type: `boolean | undefined`

### `nofollow`

- Type: `boolean | undefined`

### `submitsForm`

- Type: `boolean | undefined`

### `assistiveText`

- Type: `string`

### `onKeyDown`

- Type: `KeyboardEventHandler | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler | undefined`

### `onMouseDown`

- Type: `MouseEventHandler | undefined`

### `onMouseUp`

- Type: `MouseEventHandler | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler | undefined`

### `onMouseMove`

- Type: `MouseEventHandler | undefined`

### `onPointerDown`

- Type: `MouseEventHandler | undefined`

### `onPointerEnter`

- Type: `MouseEventHandler | undefined`

### `disabled`

- Type: `boolean | undefined`

### `busy`

- Type: `boolean | undefined`

Replaces the content with a loading indicator.

### `as`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

Custom element to render the button.

Allows rendering the button using a different React element or component.
This is particularly useful for integrating with router libraries like `react-router` or `next/router`.

@example

```
// Render as a react router link component
import { Link } from 'react-router-dom';

<ButtonBase as={<Link to="/home" />} />
```

### `url`

- Type: `string | undefined`

@deprecated

Use `href` instead

### `a11yLabel`

- Type: `string | undefined`

@deprecated

Use `assistiveText` instead

### `svg`

- Type: `SvgComponentOrElement`
- Detailed type: `ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`
- Required

### `ref`

- Type: `LegacyRef<HTMLAnchorElement | HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLAnchorElement | HTMLButtonElement | null) => void | RefObject<HTMLAnchorElement | HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `selected`

- Type: `boolean | undefined`