---
name: FormControl
import: import { FormControl } from '@preply/ds-web-lib';
description: >-
  FormControl component provides a consistent layout and accessibility

  for the form fields. You can use it to create custom fields not supported

  by the DS yet.


  Note that FormControl will implicitly provide some props to the child
  component:


  - `id` forwarded from FormControl props or will be generated automatically for
  accessibility purposes;

  - `aria-invalid` and `aria-errormessage` when `error` is provided;

  - `aria-describedby` when `description` is provided;

  - `required` when FormControl's `required` is true;
---

# FormControl

```
import { FormControl } from '@preply/ds-web-lib';
```

FormControl component provides a consistent layout and accessibility
for the form fields. You can use it to create custom fields not supported
by the DS yet.

Note that FormControl will implicitly provide some props to the child component:

- `id` forwarded from FormControl props or will be generated automatically for accessibility purposes;
- `aria-invalid` and `aria-errormessage` when `error` is provided;
- `aria-describedby` when `description` is provided;
- `required` when FormControl's `required` is true;

@example

```
const MyCustomInput = styled.input`
    // ensures that the input label is visible when scrolled to
    scroll-margin-top: var(--ds-input-scroll-margin-top);
    &[aria-invalid='true'] {
        border-color: red;
    }
`

<FormControl label="Email">
    <MyCustomInput />
</FormControl>
```

## Props

### `id`

- Type: `string | undefined`

The id to be passed to the input element.
If not provided, will be generated for accessibility purposes.

### `label`

- Type: `ReactNode`
- Required

The field label. This is needed for accessibility purposes, but can be
hidden using the `hideLabel` prop.

### `hideLabel`

- Type: `boolean | undefined`

Use this to hide the `label` visually, but keep it in the accessibility
tree.

### `description`

- Type: `ReactNode`

Additional descriptive text that appears below the input field
to provide more context or instructions to the user.

### `error`

- Type: `ReactNode`

Error message to display when the field has an invalid value.

### `hasError`

- Type: `boolean | undefined`

Whether the field has an error.

@deprecated

Use `error` prop to explicitly describe the error to users

### `required`

- Type: `boolean | undefined`

Indicates if the field is required. When false, adds a "Optional"
indicator next to the label.

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `preplyDsComponent`

- Type: `string | undefined`
- Default value: `webComponentNames.FormControl`

@deprecated

The attribute is meant for internal usage only

@ignore

### `useLegacyRequiredLabel`

- Type: `boolean | undefined`
- Default value: `false`

When true, adds a "Required" indicator next to the label for the required fields.
When false, adds a "Optional" indicator next to the label for the optional fields instead.

@deprecated

This is a temporary solution for gradual migration to the "Optional" label.