---
name: ObserveIntersection
import: import { ObserveIntersection } from '@preply/ds-web-lib';
description: |-
  An [IntersectionObserver](https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver) wrapper.

  Triggers a callback when the wrapped component intersects with the viewport.

  This can be useful in several use cases. Examples:

  - Track an experiment, once a certain component scrolls into view.
  - Trigger an animation, or a feature (e.g.: onboarding instructions).
---

# ObserveIntersection

```
import { ObserveIntersection } from '@preply/ds-web-lib';
```

An [IntersectionObserver](https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver) wrapper.

Triggers a callback when the wrapped component intersects with the viewport.

This can be useful in several use cases. Examples:

- Track an experiment, once a certain component scrolls into view.
- Trigger an animation, or a feature (e.g.: onboarding instructions).

## Props

### `onIntersect`

- Type: `() => void`
- Required

### `once`

- Type: `boolean | undefined`

### `threshold`

- Type: `number | undefined`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `dataset`

- Type: `Dataset | undefined`