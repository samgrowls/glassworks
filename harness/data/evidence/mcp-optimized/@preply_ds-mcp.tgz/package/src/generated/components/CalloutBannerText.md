---
name: CalloutBannerText
import: import { CalloutBannerText } from '@preply/ds-web-lib';
description: |-
  A `Text` component alias for the callout banner that is context-aware,
  adjusting its own `variant` based on the parent `CalloutBanner`'s `size`.
---

# CalloutBannerText

```
import { CalloutBannerText } from '@preply/ds-web-lib';
```

A `Text` component alias for the callout banner that is context-aware,
adjusting its own `variant` based on the parent `CalloutBanner`'s `size`.

@example

```
<CalloutBannerText>
  Callout banner message goes here.
</CalloutBannerText>
// Set `Text` props
<CalloutBannerText tag="span">
  Callout banner message goes here.
</CalloutBannerText>
// Override `Text` `variant` prop
<CalloutBannerText variant="default-semibold">
  Callout banner message goes here.
</CalloutBannerText>
// Override styles via `className` prop
<CalloutBannerText className={myCustomStyles.text}>
  Callout banner message goes here.
</CalloutBannerText>
```

## Props

### `variant`

- Type: `Responsive<TextVariant> | undefined`
- Detailed type: `undefined | "caption-regular" | "caption-semibold" | "small-regular" | "small-regular-italic" | "small-semibold" | "small-semibold-italic" | "default-regular" | "default-regular-italic" | "default-semibold" | "default-semibold-italic" | "large-regular" | "large-regular-italic" | "large-semibold" | "large-semibold-italic" | ResponsiveProp<TextVariant>`

### `accent`

- Type: `TextAccent | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "inverted" | "warning" | "positive" | "accentDark" | "placeholder" | "info"`

### `strong`

- Type: `boolean | undefined`

### `centered`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `tag`

- Type: `TextTag | undefined`
- Detailed type: `undefined | "p" | "div" | "span"`

### `dataset`

- Type: `Dataset | undefined`

@deprecated

Pass data attributes as regular props instead

### `className`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLParagraphElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLParagraphElement | null) => void | RefObject<HTMLParagraphElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`