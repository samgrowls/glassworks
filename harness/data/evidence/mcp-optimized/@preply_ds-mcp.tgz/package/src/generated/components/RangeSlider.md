---
name: RangeSlider
import: import { RangeSlider } from '@preply/ds-web-lib';
description: A slider input that allows users to select a range between two values.
---

# RangeSlider

```
import { RangeSlider } from '@preply/ds-web-lib';
```

A slider input that allows users to select a range between two values.

@example

```
Uncontrolled
<RangeSlider defaultValue={[25, 75]} />
Controlled
const [value, setValue] = useState([25, 75])
<RangeSlider value={value} onValueChange={setValue} />
With minimum steps between thumbs
<RangeSlider defaultValue={[20, 80]} minStepsBetweenThumbs={10} />
```

## Props

### `id`

- Type: `string | undefined`

The unique identifier for the range slider element.

### `aria-label`

- Type: `string | undefined`

Accessible label for the range slider.

### `aria-labelledby`

- Type: `string | undefined`

ID of the element that labels the range slider.

### `aria-describedby`

- Type: `string | undefined`

ID of the element that describes the range slider.

### `aria-invalid`

- Type: `boolean | undefined`

Indicates whether the range slider value is invalid.

### `aria-errormessage`

- Type: `string | undefined`

ID of the element that describes the error, if any.

### `value`

- Type: `RangeSliderValue | undefined`

The controlled value of the range slider.
Must be used in conjunction with `onValueChange`.

### `defaultValue`

- Type: `RangeSliderValue | undefined`
- Default value: `[0, 100]`

The value of the range slider when initially rendered.
Use when you do not need to control the state of the range slider.

### `onValueChange`

- Type: `((value: RangeSliderValue) => void) | undefined`

Event handler called when the value changes.

### `name`

- Type: `string | undefined`

The name of the range slider. Submitted with its owning form as part of a name/value pair.

### `min`

- Type: `number | undefined`
- Default value: `0`

The minimum value for the range slider.

### `max`

- Type: `number | undefined`
- Default value: `100`

The maximum value for the range slider.

### `step`

- Type: `number | undefined`
- Default value: `1`

The slider stepping interval.

### `minStepsBetweenThumbs`

- Type: `number | undefined`
- Default value: `0`

The minimum permitted steps between thumbs.

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`