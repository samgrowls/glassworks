---
name: Heading
import: import { Heading } from '@preply/ds-web-lib';
description: ""
---

# Heading

```
import { Heading } from '@preply/ds-web-lib';
```

## Props

### `strong`

- Type: `boolean | undefined`

@deprecated

The appropriate `font-weight` is automatically set

### `accent`

- Type: `TextAccent | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "inverted" | "warning" | "positive" | "accentDark" | "placeholder" | "info"`

### `centered`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `dataset`

- Type: `Dataset | undefined`

### `id`

- Type: `string | undefined`

### `variant`

- Type: `Responsive<HeadingVariant>`
- Detailed type: `"large" | "medium" | "small" | "massive" | "huge" | "extraLarge" | ResponsiveProp<HeadingVariant>`
- Required

### `tag`

- Type: `HeadingTag`
- Detailed type: `"p" | "div" | "span" | "h1" | "h2" | "h3" | "h4" | "h5"`
- Required

### `className`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLHeadingElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLHeadingElement | null) => void | RefObject<HTMLHeadingElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`