---
name: Avatar
import: import { Avatar } from '@preply/ds-web-lib';
description: ""
---

# Avatar

```
import { Avatar } from '@preply/ds-web-lib';
```

## Props

### `size`

- Type: `Responsive<AvatarSize> | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "64" | "96" | "160" | ResponsiveProp<AvatarSize>`
- Default value: `32`

### `round`

- Type: `boolean | undefined`

@deprecated

this prop is deprecated and has no effect

### `src`

- Type: `string | undefined`

The avatar image URL.
If not provided, the default placeholder image is used instead.

### `alt`

- Type: `string | undefined`
- Default value: `""`

A description of the image.
This is recommended for accessibility purposes, specifically for users
of screen readers.

@example

```
<Avatar src={...} alt="Foobar's profile" />
```

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Avatar dataset={{ 'qa-id': 'user-avatar' }} /> // will add data-qa-id="user-avatar" to the HTML element
```

### `crossOrigin`

- Type: `CrossOrigin`
- Detailed type: `undefined | "" | "anonymous" | "use-credentials"`

CORS policy for the image.