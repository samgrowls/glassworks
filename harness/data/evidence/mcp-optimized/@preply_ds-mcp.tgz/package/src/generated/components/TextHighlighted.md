---
name: TextHighlighted
import: import { TextHighlighted } from '@preply/ds-web-lib';
description: ""
---

# TextHighlighted

```
import { TextHighlighted } from '@preply/ds-web-lib';
```

## Props

### `highlight`

- Type: `TextHighlight | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "warning" | "positive" | "accent" | "info" | "blue" | "green"`
- Default value: `green`

### `tag`

- Type: `TextInlineTag | undefined`
- Detailed type: `undefined | "strong" | "span" | "em"`
- Default value: `span`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`