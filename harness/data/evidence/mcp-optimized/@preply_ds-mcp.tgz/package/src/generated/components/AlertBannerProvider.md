---
name: AlertBannerProvider
import: import { AlertBannerProvider } from '@preply/ds-web-lib';
description: >-
  A region where all the `AlertBanner`s will be rendered into, and announced
  accordingly. It should

  be the first element of the page.


  From an affordance perspective:

  1. Sighted users can see the page-wide banner with their eyes. The visual
  prominence ensures the

  alerts are noticed.

  2. Screen readers announce the banners when they are added, and the text
  content of the banner

  help the users to understand the level of importance.


  For blind users readers, it's important that AlertBannerProvider wraps the
  whole app so its DOM

  element is put at the top of the page, because:

  1. Screen readers announce the banner contents, but don't allow users to
  navigate to them and

  interact with them.

  2. So, if this element is put on the top of the page, screen readers wil read
  the label ("Alerts,

  warnings, and updates") as the first element, so the users are aware since the
  beginning that

  there is a dedicated region for alerts.

  3. When an alert appears, it's announced with something like "Alert: we can't
  renew your

  subscription", and they can connect the initially announced region with the
  newly appeared alert.

  4. They can then navigate to the alerts region, and interact with the alert
  actions.
---

# AlertBannerProvider

```
import { AlertBannerProvider } from '@preply/ds-web-lib';
```

A region where all the `AlertBanner`s will be rendered into, and announced accordingly. It should
be the first element of the page.

From an affordance perspective:
1. Sighted users can see the page-wide banner with their eyes. The visual prominence ensures the
alerts are noticed.
2. Screen readers announce the banners when they are added, and the text content of the banner
help the users to understand the level of importance.

For blind users readers, it's important that AlertBannerProvider wraps the whole app so its DOM
element is put at the top of the page, because:
1. Screen readers announce the banner contents, but don't allow users to navigate to them and
interact with them.
2. So, if this element is put on the top of the page, screen readers wil read the label ("Alerts,
warnings, and updates") as the first element, so the users are aware since the beginning that
there is a dedicated region for alerts.
3. When an alert appears, it's announced with something like "Alert: we can't renew your
subscription", and they can connect the initially announced region with the newly appeared alert.
4. They can then navigate to the alerts region, and interact with the alert actions.

@example

```
<App>
 <AlertBannerProvider>
    ...rest of the app
 </AlertBannerProvider>
</App>
```

## Props

### `defaultChecked`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | number | readonly string[] | undefined`

### `suppressContentEditableWarning`

- Type: `boolean | undefined`

### `suppressHydrationWarning`

- Type: `boolean | undefined`

### `accessKey`

- Type: `string | undefined`

### `autoCapitalize`

- Type: `"off" | "none" | "on" | "sentences" | "words" | "characters" | (string & {}) | undefined`

### `autoFocus`

- Type: `boolean | undefined`

### `className`

- Type: `string | undefined`

### `contentEditable`

- Type: `Booleanish | "inherit" | "plaintext-only" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "inherit" | "plaintext-only"`

### `contextMenu`

- Type: `string | undefined`

### `dir`

- Type: `string | undefined`

### `draggable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `enterKeyHint`

- Type: `"enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined`

### `hidden`

- Type: `boolean | undefined`

### `id`

- Type: `string | undefined`

### `lang`

- Type: `string | undefined`

### `nonce`

- Type: `string | undefined`

### `slot`

- Type: `string | undefined`

### `spellCheck`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `style`

- Type: `CSSProperties | undefined`

### `tabIndex`

- Type: `number | undefined`

### `title`

- Type: `string | undefined`

### `translate`

- Type: `"yes" | "no" | undefined`

### `radioGroup`

- Type: `string | undefined`

### `role`

- Type: `AriaRole | undefined`
- Detailed type: `undefined | "none" | string & {} | "search" | "alert" | "alertdialog" | "application" | "article" | "banner" | "button" | "cell" | "checkbox" | "columnheader" | "combobox" | "complementary" | "contentinfo" | "definition" | "dialog" | "directory" | "document" | "feed" | "figure" | "form" | "grid" | "gridcell" | "group" | "heading" | "img" | "link" | "list" | "listbox" | "listitem" | "log" | "main" | "marquee" | "math" | "menu" | "menubar" | "menuitem" | "menuitemcheckbox" | "menuitemradio" | "navigation" | "note" | "option" | "presentation" | "progressbar" | "radio" | "radiogroup" | "region" | "row" | "rowgroup" | "rowheader" | "scrollbar" | "searchbox" | "separator" | "slider" | "spinbutton" | "status" | "switch" | "tab" | "table" | "tablist" | "tabpanel" | "term" | "textbox" | "timer" | "toolbar" | "tooltip" | "tree" | "treegrid" | "treeitem"`

### `about`

- Type: `string | undefined`

### `content`

- Type: `string | undefined`

### `datatype`

- Type: `string | undefined`

### `inlist`

- Type: `any`

### `prefix`

- Type: `string | undefined`

### `property`

- Type: `string | undefined`

### `rel`

- Type: `string | undefined`

### `resource`

- Type: `string | undefined`

### `rev`

- Type: `string | undefined`

### `typeof`

- Type: `string | undefined`

### `vocab`

- Type: `string | undefined`

### `autoCorrect`

- Type: `string | undefined`

### `autoSave`

- Type: `string | undefined`

### `color`

- Type: `string | undefined`

### `itemProp`

- Type: `string | undefined`

### `itemScope`

- Type: `boolean | undefined`

### `itemType`

- Type: `string | undefined`

### `itemID`

- Type: `string | undefined`

### `itemRef`

- Type: `string | undefined`

### `results`

- Type: `number | undefined`

### `security`

- Type: `string | undefined`

### `unselectable`

- Type: `"off" | "on" | undefined`

### `inputMode`

- Type: `"url" | "none" | "search" | "text" | "tel" | "email" | "numeric" | "decimal" | undefined`

Hints at the type of data that might be entered by the user while editing the element or its contents

@see

{@link https://html.spec.whatwg.org/multipage/interaction.html#input-modalities:-the-inputmode-attribute}

### `is`

- Type: `string | undefined`

Specify that a standard HTML element should behave like a defined custom built-in element

@see

{@link https://html.spec.whatwg.org/multipage/custom-elements.html#attr-is}

### `aria-activedescendant`

- Type: `string | undefined`

Identifies the currently active element when DOM focus is on a composite widget, textbox, group, or application.

### `aria-atomic`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether assistive technologies will present all, or only parts of, the changed region based on the change notifications defined by the aria-relevant attribute.

### `aria-autocomplete`

- Type: `"none" | "list" | "inline" | "both" | undefined`

Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be
presented if they are made.

### `aria-braillelabel`

- Type: `string | undefined`

Defines a string value that labels the current element, which is intended to be converted into Braille.

@see

aria-label.

### `aria-brailleroledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized abbreviated description for the role of an element, which is intended to be converted into Braille.

@see

aria-roledescription.

### `aria-busy`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `aria-checked`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "checked" state of checkboxes, radio buttons, and other widgets.

@see

aria-pressed
aria-selected.

### `aria-colcount`

- Type: `number | undefined`

Defines the total number of columns in a table, grid, or treegrid.

@see

aria-colindex.

### `aria-colindex`

- Type: `number | undefined`

Defines an element's column index or position with respect to the total number of columns within a table, grid, or treegrid.

@see

aria-colcount
aria-colspan.

### `aria-colindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-colindex.

@see

aria-rowindextext.

### `aria-colspan`

- Type: `number | undefined`

Defines the number of columns spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-colindex
aria-rowspan.

### `aria-controls`

- Type: `string | undefined`

Identifies the element (or elements) whose contents or presence are controlled by the current element.

@see

aria-owns.

### `aria-current`

- Type: `boolean | "true" | "false" | "page" | "step" | "location" | "date" | "time" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "page" | "step" | "location" | "date" | "time"`

Indicates the element that represents the current item within a container or set of related elements.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `aria-description`

- Type: `string | undefined`

Defines a string value that describes or annotates the current element.

@see

related aria-describedby.

### `aria-details`

- Type: `string | undefined`

Identifies the element that provides a detailed, extended description for the object.

@see

aria-describedby.

### `aria-disabled`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is perceivable but disabled, so it is not editable or otherwise operable.

@see

aria-hidden
aria-readonly.

### `aria-dropeffect`

- Type: `"none" | "link" | "copy" | "execute" | "move" | "popup" | undefined`

Indicates what functions can be performed when a dragged object is released on the drop target.

@deprecated

in ARIA 1.1

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-expanded`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed.

### `aria-flowto`

- Type: `string | undefined`

Identifies the next element (or elements) in an alternate reading order of content which, at the user's discretion,
allows assistive technology to override the general default of reading in document source order.

### `aria-grabbed`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates an element's "grabbed" state in a drag-and-drop operation.

@deprecated

in ARIA 1.1

### `aria-haspopup`

- Type: `boolean | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree"`

Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an element.

### `aria-hidden`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element is exposed to an accessibility API.

@see

aria-disabled.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `aria-keyshortcuts`

- Type: `string | undefined`

Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element.

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-level`

- Type: `number | undefined`

Defines the hierarchical level of an element within a structure.

### `aria-live`

- Type: `"off" | "assertive" | "polite" | undefined`

Indicates that an element will be updated, and describes the types of updates the user agents, assistive technologies, and user can expect from the live region.

### `aria-modal`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether an element is modal when displayed.

### `aria-multiline`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether a text box accepts multiple lines of input or only a single line.

### `aria-multiselectable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the user may select more than one item from the current selectable descendants.

### `aria-orientation`

- Type: `"horizontal" | "vertical" | undefined`

Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous.

### `aria-owns`

- Type: `string | undefined`

Identifies an element (or elements) in order to define a visual, functional, or contextual parent/child relationship
between DOM elements where the DOM hierarchy cannot be used to represent the relationship.

@see

aria-controls.

### `aria-placeholder`

- Type: `string | undefined`

Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value.
A hint could be a sample value or a brief description of the expected format.

### `aria-posinset`

- Type: `number | undefined`

Defines an element's number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-setsize.

### `aria-pressed`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "pressed" state of toggle buttons.

@see

aria-checked
aria-selected.

### `aria-readonly`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is not editable, but is otherwise operable.

@see

aria-disabled.

### `aria-relevant`

- Type: `"text" | "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text additions" | "text removals" | undefined`

Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified.

@see

aria-atomic.

### `aria-required`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that user input is required on the element before a form may be submitted.

### `aria-roledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized description for the role of an element.

### `aria-rowcount`

- Type: `number | undefined`

Defines the total number of rows in a table, grid, or treegrid.

@see

aria-rowindex.

### `aria-rowindex`

- Type: `number | undefined`

Defines an element's row index or position with respect to the total number of rows within a table, grid, or treegrid.

@see

aria-rowcount
aria-rowspan.

### `aria-rowindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-rowindex.

@see

aria-colindextext.

### `aria-rowspan`

- Type: `number | undefined`

Defines the number of rows spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-rowindex
aria-colspan.

### `aria-selected`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates the current "selected" state of various widgets.

@see

aria-checked
aria-pressed.

### `aria-setsize`

- Type: `number | undefined`

Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-posinset.

### `aria-sort`

- Type: `"none" | "ascending" | "descending" | "other" | undefined`

Indicates if items in a table or grid are sorted in ascending or descending order.

### `aria-valuemax`

- Type: `number | undefined`

Defines the maximum allowed value for a range widget.

### `aria-valuemin`

- Type: `number | undefined`

Defines the minimum allowed value for a range widget.

### `aria-valuenow`

- Type: `number | undefined`

Defines the current value for a range widget.

@see

aria-valuetext.

### `aria-valuetext`

- Type: `string | undefined`

Defines the human readable text alternative of aria-valuenow for a range widget.

### `dangerouslySetInnerHTML`

- Type: `{ __html: string | TrustedHTML; } | undefined`
- Detailed type: `undefined | { __html: string | TrustedHTML; }`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onCopyCapture`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onCutCapture`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onPasteCapture`

- Type: `ClipboardEventHandler<HTMLDivElement> | undefined`

### `onCompositionEnd`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onCompositionEndCapture`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onCompositionStart`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onCompositionStartCapture`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onCompositionUpdate`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onCompositionUpdateCapture`

- Type: `CompositionEventHandler<HTMLDivElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLDivElement> | undefined`

### `onFocusCapture`

- Type: `FocusEventHandler<HTMLDivElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLDivElement> | undefined`

### `onBlurCapture`

- Type: `FocusEventHandler<HTMLDivElement> | undefined`

### `onChange`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onChangeCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onBeforeInput`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onBeforeInputCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onInput`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onInputCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onReset`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onResetCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onSubmit`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onSubmitCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onInvalid`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onInvalidCapture`

- Type: `FormEventHandler<HTMLDivElement> | undefined`

### `onLoad`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onError`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onErrorCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

### `onKeyDownCapture`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

### `onKeyPress`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

@deprecated

Use `onKeyUp` or `onKeyDown` instead

### `onKeyPressCapture`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

@deprecated

Use `onKeyUpCapture` or `onKeyDownCapture` instead

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

### `onKeyUpCapture`

- Type: `KeyboardEventHandler<HTMLDivElement> | undefined`

### `onAbort`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onAbortCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onCanPlay`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onCanPlayCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onCanPlayThrough`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onCanPlayThroughCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onDurationChange`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onDurationChangeCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEmptied`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEmptiedCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEncrypted`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEncryptedCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEnded`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onEndedCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadedData`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadedDataCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadedMetadata`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadedMetadataCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadStart`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onLoadStartCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPause`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPauseCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPlay`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPlayCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPlaying`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onPlayingCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onProgress`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onProgressCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onRateChange`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onRateChangeCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onResize`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onResizeCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSeeked`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSeekedCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSeeking`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSeekingCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onStalled`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onStalledCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSuspend`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSuspendCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onTimeUpdate`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onTimeUpdateCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onVolumeChange`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onVolumeChangeCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onWaiting`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onWaitingCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onAuxClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onAuxClickCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onClickCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onContextMenu`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onContextMenuCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onDoubleClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onDoubleClickCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onDrag`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragEnd`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragEndCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragEnter`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragEnterCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragExit`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragExitCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragLeave`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragLeaveCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragOver`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragOverCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragStart`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDragStartCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDrop`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onDropCapture`

- Type: `DragEventHandler<HTMLDivElement> | undefined`

### `onMouseDown`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseDownCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseLeave`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseMove`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseMoveCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseOut`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseOutCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseOver`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseOverCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseUp`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onMouseUpCapture`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `onSelect`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onSelectCapture`

- Type: `ReactEventHandler<HTMLDivElement> | undefined`

### `onTouchCancel`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchCancelCapture`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchEnd`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchEndCapture`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchMove`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchMoveCapture`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchStart`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onTouchStartCapture`

- Type: `TouchEventHandler<HTMLDivElement> | undefined`

### `onPointerDown`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerDownCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerMove`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerMoveCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerUp`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerUpCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerCancel`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerCancelCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerEnter`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerLeave`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerOver`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerOverCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerOut`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onPointerOutCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onGotPointerCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onGotPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onLostPointerCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onLostPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLDivElement> | undefined`

### `onScroll`

- Type: `UIEventHandler<HTMLDivElement> | undefined`

### `onScrollCapture`

- Type: `UIEventHandler<HTMLDivElement> | undefined`

### `onWheel`

- Type: `WheelEventHandler<HTMLDivElement> | undefined`

### `onWheelCapture`

- Type: `WheelEventHandler<HTMLDivElement> | undefined`

### `onAnimationStart`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onAnimationStartCapture`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onAnimationEnd`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onAnimationEndCapture`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onAnimationIteration`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onAnimationIterationCapture`

- Type: `AnimationEventHandler<HTMLDivElement> | undefined`

### `onTransitionEnd`

- Type: `TransitionEventHandler<HTMLDivElement> | undefined`

### `onTransitionEndCapture`

- Type: `TransitionEventHandler<HTMLDivElement> | undefined`