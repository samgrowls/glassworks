---
name: Badge
import: import { Badge } from '@preply/ds-web-lib';
description: ""
---

# Badge

```
import { Badge } from '@preply/ds-web-lib';
```

## Props

### `size`

- Type: `BadgeSize | DeprecatedBadgeSize | undefined`
- Detailed type: `undefined | "large" | "medium" | "small" | "xs" | "s" | "m"`
- Default value: `medium`

The size of the badge.

### `leadingSvgIcon`

- Type: `SvgComponentOrElement | undefined`
- Detailed type: `undefined | ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`

The leading SVG icon.

@example

```
import TokyoUITag from '@preply/ds-media-icons/dist/24/TokyoUITag.svg';

<Badge leadingSvgIcon={TokyoUITag}>Badge</Badge>
or
<Badge leadingSvgIcon={<TokyoUITag />}>Badge</Badge>
```

### `dataset`

- Type: `Dataset | undefined`

### `hideLabel`

- Type: `boolean | undefined`

@deprecated

Look at <IconTile> if you need an icon-only badge.

Hides badge label visually, but keeps it in the accessibility tree.
Use this prop to implement icons-only badges.

@example

```
<Badge leadingSvgIcon={<TokyoUITag />} hideLabel>Badge</Badge>
```

### `assistiveText`

- Type: `string | undefined`

@deprecated

badge children should have all necessary information

### `type`

- Type: `"critical" | "ai" | "warning" | "positive" | "info" | "neutral" | undefined`
- Default value: `neutral`

The type of the badge.

### `accent`

- Type: `BadgeAccent | undefined`
- Detailed type: `undefined | "tertiary" | "critical" | "warning" | "positive" | "accent" | "info"`

@deprecated

Use `type` instead.

### `inverted`

- Type: `boolean | undefined`

@deprecated

inverted badge is deprecated & will be removed in the future releases