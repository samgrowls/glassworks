---
name: ProgressSteps
import: import { ProgressSteps } from '@preply/ds-web-lib';
description: >-
  A component that visually displays progress through a series of discrete
  steps.


  For a continuous progress indicator, use the `ProgressBar` component instead.
---

# ProgressSteps

```
import { ProgressSteps } from '@preply/ds-web-lib';
```

A component that visually displays progress through a series of discrete steps.

For a continuous progress indicator, use the `ProgressBar` component instead.

## Props

### `totalSteps`

- Type: `number`
- Required

The total number of step indicators to show in the progress steps.

### `currentStep`

- Type: `number`
- Required

The current step in the progress;
Starts at 1 for the first step, ends at `totalSteps`.

### `aria-label`

- Type: `string`
- Required

A description of the progress bar for screen readers.

@example

```
'Onboarding', 'Checkout', 'Survey', etc.
```

### `dataset`

- Type: `Dataset | undefined`