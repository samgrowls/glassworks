---
name: Link
import: import { Link } from '@preply/ds-web-lib';
description: |-
  This is an inline element and will inherit font-size, line-height and
  font-weight from the parent context. If you need to customise any of these
  styles, all you have to do is wrap the <Link> in a Text or TextInline
  component.
---

# Link

```
import { Link } from '@preply/ds-web-lib';
```

This is an inline element and will inherit font-size, line-height and
font-weight from the parent context. If you need to customise any of these
styles, all you have to do is wrap the <Link> in a Text or TextInline
component.

## Props

### `onClick`

- Type: `MouseEventHandler<HTMLAnchorElement> | undefined`

### `href`

- Type: `string | undefined`

### `download`

- Type: `any`

### `variant`

- Type: `LinkVariant | undefined`
- Detailed type: `undefined | "accentDark" | "neutral" | "accentDarkInverted" | "neutralInverted" | "unsetColors"`

### `opensInNewTab`

- Type: `boolean | undefined`

If `true`, forces internal link to open in a new tab.

### `nofollow`

- Type: `boolean | undefined`

### `assistiveText`

- Type: `string | undefined`

Provide an `aria-label` to the link.
This is useful if the link wraps non-textual elements, eg. an `img`.

### `as`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

### `url`

- Type: `string | undefined`

@deprecated

Use `href` instead

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Avatar dataset={{ 'qa-id': 'user-avatar' }} /> // will add data-qa-id="user-avatar" to the HTML element
```

### `inline`

- Type: `boolean | undefined`

If `true`, allows the link to wrap within text.

### `noUnderline`

- Type: `boolean | undefined`

### `dsInternalSimulation`

- Type: `"hover" | "active" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `ref`

- Type: `LegacyRef<HTMLAnchorElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLAnchorElement | null) => void | RefObject<HTMLAnchorElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`