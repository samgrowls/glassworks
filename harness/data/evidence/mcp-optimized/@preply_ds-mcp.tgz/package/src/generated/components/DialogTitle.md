---
name: DialogTitle
import: import { DialogTitle } from '@preply/ds-web-lib';
description: ""
---

# DialogTitle

```
import { DialogTitle } from '@preply/ds-web-lib';
```

## Props

### `defaultChecked`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | number | readonly string[] | undefined`

### `suppressContentEditableWarning`

- Type: `boolean | undefined`

### `suppressHydrationWarning`

- Type: `boolean | undefined`

### `accessKey`

- Type: `string | undefined`

### `autoCapitalize`

- Type: `"off" | "none" | "on" | "sentences" | "words" | "characters" | (string & {}) | undefined`

### `autoFocus`

- Type: `boolean | undefined`

### `className`

- Type: `string | undefined`

### `contentEditable`

- Type: `Booleanish | "inherit" | "plaintext-only" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "inherit" | "plaintext-only"`

### `contextMenu`

- Type: `string | undefined`

### `dir`

- Type: `string | undefined`

### `draggable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `enterKeyHint`

- Type: `"enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined`

### `hidden`

- Type: `boolean | undefined`

### `id`

- Type: `string | undefined`

### `lang`

- Type: `string | undefined`

### `nonce`

- Type: `string | undefined`

### `slot`

- Type: `string | undefined`

### `spellCheck`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `style`

- Type: `CSSProperties | undefined`

### `tabIndex`

- Type: `number | undefined`

### `title`

- Type: `string | undefined`

### `translate`

- Type: `"yes" | "no" | undefined`

### `radioGroup`

- Type: `string | undefined`

### `role`

- Type: `AriaRole | undefined`
- Detailed type: `undefined | "none" | string & {} | "search" | "alert" | "alertdialog" | "application" | "article" | "banner" | "button" | "cell" | "checkbox" | "columnheader" | "combobox" | "complementary" | "contentinfo" | "definition" | "dialog" | "directory" | "document" | "feed" | "figure" | "form" | "grid" | "gridcell" | "group" | "heading" | "img" | "link" | "list" | "listbox" | "listitem" | "log" | "main" | "marquee" | "math" | "menu" | "menubar" | "menuitem" | "menuitemcheckbox" | "menuitemradio" | "navigation" | "note" | "option" | "presentation" | "progressbar" | "radio" | "radiogroup" | "region" | "row" | "rowgroup" | "rowheader" | "scrollbar" | "searchbox" | "separator" | "slider" | "spinbutton" | "status" | "switch" | "tab" | "table" | "tablist" | "tabpanel" | "term" | "textbox" | "timer" | "toolbar" | "tooltip" | "tree" | "treegrid" | "treeitem"`

### `about`

- Type: `string | undefined`

### `content`

- Type: `string | undefined`

### `datatype`

- Type: `string | undefined`

### `inlist`

- Type: `any`

### `prefix`

- Type: `string | undefined`

### `property`

- Type: `string | undefined`

### `rel`

- Type: `string | undefined`

### `resource`

- Type: `string | undefined`

### `rev`

- Type: `string | undefined`

### `typeof`

- Type: `string | undefined`

### `vocab`

- Type: `string | undefined`

### `autoCorrect`

- Type: `string | undefined`

### `autoSave`

- Type: `string | undefined`

### `color`

- Type: `string | undefined`

### `itemProp`

- Type: `string | undefined`

### `itemScope`

- Type: `boolean | undefined`

### `itemType`

- Type: `string | undefined`

### `itemID`

- Type: `string | undefined`

### `itemRef`

- Type: `string | undefined`

### `results`

- Type: `number | undefined`

### `security`

- Type: `string | undefined`

### `unselectable`

- Type: `"off" | "on" | undefined`

### `inputMode`

- Type: `"url" | "none" | "search" | "text" | "tel" | "email" | "numeric" | "decimal" | undefined`

Hints at the type of data that might be entered by the user while editing the element or its contents

@see

{@link https://html.spec.whatwg.org/multipage/interaction.html#input-modalities:-the-inputmode-attribute}

### `is`

- Type: `string | undefined`

Specify that a standard HTML element should behave like a defined custom built-in element

@see

{@link https://html.spec.whatwg.org/multipage/custom-elements.html#attr-is}

### `aria-activedescendant`

- Type: `string | undefined`

Identifies the currently active element when DOM focus is on a composite widget, textbox, group, or application.

### `aria-atomic`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether assistive technologies will present all, or only parts of, the changed region based on the change notifications defined by the aria-relevant attribute.

### `aria-autocomplete`

- Type: `"none" | "list" | "inline" | "both" | undefined`

Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be
presented if they are made.

### `aria-braillelabel`

- Type: `string | undefined`

Defines a string value that labels the current element, which is intended to be converted into Braille.

@see

aria-label.

### `aria-brailleroledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized abbreviated description for the role of an element, which is intended to be converted into Braille.

@see

aria-roledescription.

### `aria-busy`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `aria-checked`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "checked" state of checkboxes, radio buttons, and other widgets.

@see

aria-pressed
aria-selected.

### `aria-colcount`

- Type: `number | undefined`

Defines the total number of columns in a table, grid, or treegrid.

@see

aria-colindex.

### `aria-colindex`

- Type: `number | undefined`

Defines an element's column index or position with respect to the total number of columns within a table, grid, or treegrid.

@see

aria-colcount
aria-colspan.

### `aria-colindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-colindex.

@see

aria-rowindextext.

### `aria-colspan`

- Type: `number | undefined`

Defines the number of columns spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-colindex
aria-rowspan.

### `aria-controls`

- Type: `string | undefined`

Identifies the element (or elements) whose contents or presence are controlled by the current element.

@see

aria-owns.

### `aria-current`

- Type: `boolean | "true" | "false" | "page" | "step" | "location" | "date" | "time" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "page" | "step" | "location" | "date" | "time"`

Indicates the element that represents the current item within a container or set of related elements.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `aria-description`

- Type: `string | undefined`

Defines a string value that describes or annotates the current element.

@see

related aria-describedby.

### `aria-details`

- Type: `string | undefined`

Identifies the element that provides a detailed, extended description for the object.

@see

aria-describedby.

### `aria-disabled`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is perceivable but disabled, so it is not editable or otherwise operable.

@see

aria-hidden
aria-readonly.

### `aria-dropeffect`

- Type: `"none" | "link" | "copy" | "execute" | "move" | "popup" | undefined`

Indicates what functions can be performed when a dragged object is released on the drop target.

@deprecated

in ARIA 1.1

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-expanded`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed.

### `aria-flowto`

- Type: `string | undefined`

Identifies the next element (or elements) in an alternate reading order of content which, at the user's discretion,
allows assistive technology to override the general default of reading in document source order.

### `aria-grabbed`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates an element's "grabbed" state in a drag-and-drop operation.

@deprecated

in ARIA 1.1

### `aria-haspopup`

- Type: `boolean | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree"`

Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an element.

### `aria-hidden`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element is exposed to an accessibility API.

@see

aria-disabled.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `aria-keyshortcuts`

- Type: `string | undefined`

Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element.

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-level`

- Type: `number | undefined`

Defines the hierarchical level of an element within a structure.

### `aria-live`

- Type: `"off" | "assertive" | "polite" | undefined`

Indicates that an element will be updated, and describes the types of updates the user agents, assistive technologies, and user can expect from the live region.

### `aria-modal`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether an element is modal when displayed.

### `aria-multiline`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether a text box accepts multiple lines of input or only a single line.

### `aria-multiselectable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the user may select more than one item from the current selectable descendants.

### `aria-orientation`

- Type: `"horizontal" | "vertical" | undefined`

Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous.

### `aria-owns`

- Type: `string | undefined`

Identifies an element (or elements) in order to define a visual, functional, or contextual parent/child relationship
between DOM elements where the DOM hierarchy cannot be used to represent the relationship.

@see

aria-controls.

### `aria-placeholder`

- Type: `string | undefined`

Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value.
A hint could be a sample value or a brief description of the expected format.

### `aria-posinset`

- Type: `number | undefined`

Defines an element's number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-setsize.

### `aria-pressed`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "pressed" state of toggle buttons.

@see

aria-checked
aria-selected.

### `aria-readonly`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is not editable, but is otherwise operable.

@see

aria-disabled.

### `aria-relevant`

- Type: `"text" | "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text additions" | "text removals" | undefined`

Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified.

@see

aria-atomic.

### `aria-required`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that user input is required on the element before a form may be submitted.

### `aria-roledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized description for the role of an element.

### `aria-rowcount`

- Type: `number | undefined`

Defines the total number of rows in a table, grid, or treegrid.

@see

aria-rowindex.

### `aria-rowindex`

- Type: `number | undefined`

Defines an element's row index or position with respect to the total number of rows within a table, grid, or treegrid.

@see

aria-rowcount
aria-rowspan.

### `aria-rowindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-rowindex.

@see

aria-colindextext.

### `aria-rowspan`

- Type: `number | undefined`

Defines the number of rows spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-rowindex
aria-colspan.

### `aria-selected`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates the current "selected" state of various widgets.

@see

aria-checked
aria-pressed.

### `aria-setsize`

- Type: `number | undefined`

Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-posinset.

### `aria-sort`

- Type: `"none" | "ascending" | "descending" | "other" | undefined`

Indicates if items in a table or grid are sorted in ascending or descending order.

### `aria-valuemax`

- Type: `number | undefined`

Defines the maximum allowed value for a range widget.

### `aria-valuemin`

- Type: `number | undefined`

Defines the minimum allowed value for a range widget.

### `aria-valuenow`

- Type: `number | undefined`

Defines the current value for a range widget.

@see

aria-valuetext.

### `aria-valuetext`

- Type: `string | undefined`

Defines the human readable text alternative of aria-valuenow for a range widget.

### `dangerouslySetInnerHTML`

- Type: `{ __html: string | TrustedHTML; } | undefined`
- Detailed type: `undefined | { __html: string | TrustedHTML; }`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onCopyCapture`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onCutCapture`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onPasteCapture`

- Type: `ClipboardEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionEnd`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionEndCapture`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionStart`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionStartCapture`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionUpdate`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onCompositionUpdateCapture`

- Type: `CompositionEventHandler<HTMLHeadingElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLHeadingElement> | undefined`

### `onFocusCapture`

- Type: `FocusEventHandler<HTMLHeadingElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLHeadingElement> | undefined`

### `onBlurCapture`

- Type: `FocusEventHandler<HTMLHeadingElement> | undefined`

### `onChange`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onChangeCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onBeforeInput`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onBeforeInputCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onInput`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onInputCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onReset`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onResetCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onSubmit`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onSubmitCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onInvalid`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onInvalidCapture`

- Type: `FormEventHandler<HTMLHeadingElement> | undefined`

### `onLoad`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onError`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onErrorCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

### `onKeyDownCapture`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

### `onKeyPress`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

@deprecated

Use `onKeyUp` or `onKeyDown` instead

### `onKeyPressCapture`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

@deprecated

Use `onKeyUpCapture` or `onKeyDownCapture` instead

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

### `onKeyUpCapture`

- Type: `KeyboardEventHandler<HTMLHeadingElement> | undefined`

### `onAbort`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onAbortCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onCanPlay`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onCanPlayCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onCanPlayThrough`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onCanPlayThroughCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onDurationChange`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onDurationChangeCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEmptied`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEmptiedCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEncrypted`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEncryptedCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEnded`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onEndedCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadedData`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadedDataCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadedMetadata`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadedMetadataCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadStart`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onLoadStartCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPause`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPauseCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPlay`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPlayCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPlaying`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onPlayingCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onProgress`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onProgressCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onRateChange`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onRateChangeCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onResize`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onResizeCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSeeked`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSeekedCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSeeking`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSeekingCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onStalled`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onStalledCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSuspend`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSuspendCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onTimeUpdate`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onTimeUpdateCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onVolumeChange`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onVolumeChangeCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onWaiting`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onWaitingCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onAuxClick`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onAuxClickCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onClickCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onContextMenu`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onContextMenuCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onDoubleClick`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onDoubleClickCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onDrag`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragEnd`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragEndCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragEnter`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragEnterCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragExit`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragExitCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragLeave`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragLeaveCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragOver`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragOverCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragStart`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDragStartCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDrop`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onDropCapture`

- Type: `DragEventHandler<HTMLHeadingElement> | undefined`

### `onMouseDown`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseDownCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseLeave`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseMove`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseMoveCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseOut`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseOutCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseOver`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseOverCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseUp`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onMouseUpCapture`

- Type: `MouseEventHandler<HTMLHeadingElement> | undefined`

### `onSelect`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onSelectCapture`

- Type: `ReactEventHandler<HTMLHeadingElement> | undefined`

### `onTouchCancel`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchCancelCapture`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchEnd`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchEndCapture`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchMove`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchMoveCapture`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchStart`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onTouchStartCapture`

- Type: `TouchEventHandler<HTMLHeadingElement> | undefined`

### `onPointerDown`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerDownCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerMove`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerMoveCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerUp`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerUpCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerCancel`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerCancelCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerEnter`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerLeave`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerOver`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerOverCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerOut`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onPointerOutCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onGotPointerCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onGotPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onLostPointerCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onLostPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLHeadingElement> | undefined`

### `onScroll`

- Type: `UIEventHandler<HTMLHeadingElement> | undefined`

### `onScrollCapture`

- Type: `UIEventHandler<HTMLHeadingElement> | undefined`

### `onWheel`

- Type: `WheelEventHandler<HTMLHeadingElement> | undefined`

### `onWheelCapture`

- Type: `WheelEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationStart`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationStartCapture`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationEnd`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationEndCapture`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationIteration`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onAnimationIterationCapture`

- Type: `AnimationEventHandler<HTMLHeadingElement> | undefined`

### `onTransitionEnd`

- Type: `TransitionEventHandler<HTMLHeadingElement> | undefined`

### `onTransitionEndCapture`

- Type: `TransitionEventHandler<HTMLHeadingElement> | undefined`

### `dataset`

- Type: `Dataset | undefined`

@deprecated

Pass data attributes as regular props instead

@example

```
<DialogTitle data-testid="dialog-title">Dialog Title</DialogTitle>
```

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`