---
name: SelectFieldOption
import: import { SelectFieldOption } from '@preply/ds-web-lib';
description: ""
---

# SelectFieldOption

```
import { SelectFieldOption } from '@preply/ds-web-lib';
```

## Props

### `value`

- Type: `string`
- Required

### `disabled`

- Type: `boolean | undefined`

### `leadingIcon`

- Type: `ReactNode`

### `dataset`

- Type: `Dataset | undefined`