---
name: AccordionContent
import: import { AccordionContent } from '@preply/ds-web-lib';
description: The content of a single `Accordion` item, to be used in conjunction
  with AccordionHeader wrapped inside AccordionContent.
---

# AccordionContent

```
import { AccordionContent } from '@preply/ds-web-lib';
```

The content of a single `Accordion` item, to be used in conjunction with AccordionHeader wrapped inside AccordionContent.

## Props

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<AccordionItem dataset={{ 'qa-id': 'best-tutor-platform' }} /> // will add data-qa-id="best-tutor-platform" to the HTML element.
```

### `ref`

- Type: `LegacyRef<HTMLDetailsElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDetailsElement | null) => void | RefObject<HTMLDetailsElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`