---
name: Tooltip
import: import { Tooltip } from '@preply/ds-web-lib';
description: |-
  Tooltip component.

  The direct child of the component should be html element, DS component,
  or a component that forwards ref and spreads props to the underlying DOM node.
---

# Tooltip

```
import { Tooltip } from '@preply/ds-web-lib';
```

Tooltip component.

The direct child of the component should be html element, DS component,
or a component that forwards ref and spreads props to the underlying DOM node.

@example

```
<Tooltip content="Tooltip content">
  <Button>Hover me</Button>
</Tooltip>
```

## Props

### `content`

- Type: `ReactNode`
- Required

### `trigger`

- Type: `Trigger | undefined`
- Detailed type: `undefined | "hover" | "hover-and-touch"`
- Default value: `hover`

Controls how the tooltip can be triggered.

- 'hover' (default): Tooltip appears on hover
- 'hover-and-touch': Tooltip appears on hover and touch interactions

In both cases tooltip also appears on focus.

### `disabled`

- Type: `boolean | undefined`
- Default value: `false`

Disables tooltip completely.

### `side`

- Type: `"top" | "bottom" | "left" | "right" | undefined`
- Default value: `top`

Preferred side of the tooltip to appear from. Use if default side might block important content.

### `dataset`

- Type: `Dataset | undefined`

### `dsInternalSimulation`

- Type: `"open" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `ref`

- Type: `LegacyRef<HTMLElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLElement | null) => void | RefObject<HTMLElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`