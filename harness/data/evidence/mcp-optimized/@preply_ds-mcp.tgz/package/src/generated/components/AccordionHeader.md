---
name: AccordionHeader
import: import { AccordionHeader } from '@preply/ds-web-lib';
description: The header of a single `Accordion` item, to be used in conjunction
  with AccordionItem and wrapped inside AccordionContent.
---

# AccordionHeader

```
import { AccordionHeader } from '@preply/ds-web-lib';
```

The header of a single `Accordion` item, to be used in conjunction with AccordionItem and wrapped inside AccordionContent.

## Props

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `ref`

- Type: `LegacyRef<HTMLDetailsElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDetailsElement | null) => void | RefObject<HTMLDetailsElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`