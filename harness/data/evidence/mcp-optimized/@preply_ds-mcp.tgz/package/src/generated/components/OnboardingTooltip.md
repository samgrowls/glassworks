---
name: OnboardingTooltip
import: import { OnboardingTooltip } from '@preply/ds-web-lib';
description: >-
  Informational pop-up that highlights specific UI element, e.g. to introduce
  new feature.


  The direct child of the component should be html element, DS component,

  or a component that forwards ref to the underlying DOM node.
---

# OnboardingTooltip

```
import { OnboardingTooltip } from '@preply/ds-web-lib';
```

Informational pop-up that highlights specific UI element, e.g. to introduce new feature.

The direct child of the component should be html element, DS component,
or a component that forwards ref to the underlying DOM node.

@example

```
const [wasTooltipSeen, loading] = useIsFeatureActive('new-feature');
const setTooltipSeen = useToggleFeature('new-feature');

<OnboardingTooltip
    title="New Feature Available!"
    text="We've added an exciting new feature to enhance your experience."
    disabled={loading || wasTooltipSeen}
    onClose={() => setTooltipSeen(true)}
>
    <Button>New feature</Button>
</OnboardingTooltip>
```

## Props

### `title`

- Type: `ReactNode`
- Required

### `text`

- Type: `ReactNode`
- Required

### `disabled`

- Type: `boolean | undefined`

Disables tooltip completely

### `onClose`

- Type: `(() => void) | undefined`

Called when the tooltip is closed

### `actionLabel`

- Type: `ReactNode`
- Default value: `(
            <FormattedMessage
                id="preply-ds.onboardingTooltip.actionLabel"
                defaultMessage="Got it"
                description="Default onboarding tooltip action label. Used to acknowledge and close the tooltip."
            />
        )`

Label of the action button

### `actionOnClick`

- Type: `(() => void) | undefined`

By default, the action button closes the tooltip.

Provide `actionOnClick` to also perform other action.

### `actionHref`

- Type: `string | undefined`

By default, the action button closes the tooltip.

Provide `actionHref` to also navigate to other page when the button is clicked.

### `side`

- Type: `"top" | "bottom" | "left" | "right" | undefined`

Preferred side of the tooltip to appear from. Use if default side might block important content.

### `autoScroll`

- Type: `boolean | undefined`
- Default value: `true`

If true, the tooltip will automatically scroll into view when it is opened.

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`