---
name: Icon
import: import { Icon } from '@preply/ds-web-lib';
description: ""
---

# Icon

```
import { Icon } from '@preply/ds-web-lib';
```

## Props

### `svg`

- Type: `SvgComponentOrElement`
- Detailed type: `ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`
- Required

The SVG icon to render.

@example

```
import TokyoUINotesWithPad from '@preply/ds-media-icons/dist/24/TokyoUINotesWithPad.svg';

<Icon svg={TokyoUINotesWithPad} />
<caption>Using as react server component</caption>
import TokyoUINotesWithPad from '@preply/ds-media-icons/dist/24/TokyoUINotesWithPad.svg';

<Icon svg={<TokyoUINotesWithPad />} />
```

### `size`

- Type: `IconSize | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "16"`
- Default value: `24`

### `accent`

- Type: `TextAccent | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "inverted" | "warning" | "positive" | "accentDark" | "placeholder" | "info"`

### `expColor`

- Type: `ExpColorName | undefined`
- Detailed type: `undefined | "grey-0" | "grey-50" | "grey-100" | "grey-200" | "grey-300" | "grey-400" | "grey-500" | "grey-600" | "grey-700" | "grey-800" | "grey-900" | "pink-50" | "pink-100" | "pink-200" | "pink-300" | "pink-400" | "pink-500" | "pink-600" | "pink-700" | "pink-800" | "yellow-50" | "yellow-100" | "yellow-200" | "yellow-300" | "yellow-400" | "yellow-500" | "yellow-600" | "yellow-700" | "yellow-800" | "blue-50" | "blue-100" | "blue-200" | "blue-300" | "blue-400" | "blue-500" | "blue-600" | "blue-700" | "blue-800" | "teal-50" | "teal-100" | "teal-200" | "teal-300" | "teal-400" | "teal-500" | "teal-600" | "teal-700" | "teal-800" | "red-50" | "red-100" | "red-200" | "red-300" | "red-400" | "red-500" | "red-600" | "red-700" | "red-800"`

If passed along with `accent`, `accent` takes precedence.

### `label`

- Type: `string | undefined`

If using the icon without any adjacent descriptive text, use this prop to
provide an `aria-label` for assistive technologies.

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`