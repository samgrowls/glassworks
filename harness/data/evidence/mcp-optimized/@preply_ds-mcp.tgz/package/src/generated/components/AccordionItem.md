---
name: AccordionItem
import: import { AccordionItem } from '@preply/ds-web-lib';
description: A single `Accordion` item, the wrapper of AccordionHeader and AccordionContent.
---

# AccordionItem

```
import { AccordionItem } from '@preply/ds-web-lib';
```

A single `Accordion` item, the wrapper of AccordionHeader and AccordionContent.

## Props

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `open`

- Type: `boolean | undefined`

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `onOpenChange`

- Type: `((open: boolean) => void) | undefined`

Called whenever the users open/close the Accordion item (mapped to the internal HTML Details's
`toggle` event).

### `name`

- Type: `string | undefined`

Allows to create exclusive Accordions. Just pass the same `name` to all the AccordionItem
instances to make the whole Accordion exclusive.

@example

```
<Accordion>
    <AccordionItem name="choose-subscription-duration">
        <AccordionHeader>
            Two-week subscription
        </AccordionHeader>
        <AccordionContent>We will charge you every two weeks.</AccordionContent>
    </AccordionItem>
    <AccordionItem name="choose-subscription-duration">
        <AccordionHeader>
            Four-week subscription
        </AccordionHeader>
        <AccordionContent>We will charge you every four weeks.</AccordionContent>
    </AccordionItem>
</Accordion>
```

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<AccordionItem dataset={{ 'qa-id': 'best-tutor-platform' }} /> // will add data-qa-id="best-tutor-platform" to the HTML element.
```

### `dsInternalSimulation`

- Type: `"focus" | "noAnimation" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `ref`

- Type: `LegacyRef<HTMLDetailsElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDetailsElement | null) => void | RefObject<HTMLDetailsElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`