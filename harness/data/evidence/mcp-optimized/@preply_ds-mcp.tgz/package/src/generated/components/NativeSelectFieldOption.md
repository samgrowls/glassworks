---
name: NativeSelectFieldOption
import: import { NativeSelectFieldOption } from
  '@preply/ds-web-lib/components/deprecated';
description: ""
---

# NativeSelectFieldOption

```
import { NativeSelectFieldOption } from '@preply/ds-web-lib/components/deprecated';
```

## Props

### `value`

- Type: `string`
- Required

### `disabled`

- Type: `boolean | undefined`