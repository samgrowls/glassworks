---
name: DropdownMenuCheckboxItem
import: import { DropdownMenuCheckboxItem } from '@preply/ds-web-lib';
description: Dropdown menu checkbox item
---

# DropdownMenuCheckboxItem

```
import { DropdownMenuCheckboxItem } from '@preply/ds-web-lib';
```

Dropdown menu checkbox item

@example

```
<DropdownMenuCheckboxItem label="Item 1" checked />
```

## Props

### `dataset`

- Type: `Dataset | undefined`

### `disabled`

- Type: `boolean | undefined`

Whether the menu item is disabled.

### `description`

- Type: `ReactNode`

Menu description

### `leadingElement`

- Type: `ReactNode`

Menu leading element. Can be an icon, flag or avatar.

@example

```
<DropdownMenuItem leadingElement={<Icon size="24" name="home" />} />
<DropdownMenuItem leadingElement={<CountryFlag size="medium" code="US" />} />
<DropdownMenuItem leadingElement={<Avatar size="24" />} />
```

### `label`

- Type: `ReactNode`
- Required

Menu label

### `defaultChecked`

- Type: `boolean | undefined`

### `checked`

- Type: `boolean | undefined`

### `onCheckedChange`

- Type: `((checked: boolean) => void) | undefined`

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`