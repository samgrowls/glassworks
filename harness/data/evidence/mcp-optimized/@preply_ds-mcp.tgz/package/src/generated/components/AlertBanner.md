---
name: AlertBanner
import: import { AlertBanner } from '@preply/ds-web-lib';
description: >-
  The Alert Banner communicates important and time-sensitive messages that
  require user attention.


  From an accessibility perspective, the description is prefixed to announce the
  importance of the

  banner.
---

# AlertBanner

```
import { AlertBanner } from '@preply/ds-web-lib';
```

The Alert Banner communicates important and time-sensitive messages that require user attention.

From an accessibility perspective, the description is prefixed to announce the importance of the
banner.

@example

```
<AlertBanner
  variant="alert"
  description="Failed to renew the subscription."
  actionLabel="Try again"
  actionOnClick={retryPayment}
/>
```

## Props

### `variant`

- Type: `AlertBannerVariant`
- Detailed type: `"critical" | "warning" | "positive"`
- Required

Impact the visualized icon, the background color, and how the banner is announced by screen
readers.

Semantic icons are also exported for the following variants:
- `warning` -> `<AlertBannerWarningIcon />`
- `critical` -> `<AlertBannerCriticalIcon />`
- `positive` -> `<AlertBannerPositiveIcon />`

### `description`

- Type: `ReactNode`
- Required

The banner's message content.

### `action`

- Type: `ReactNode`
- Required

The banner' action.

To build a DS compliant banner, use:
- `CalloutBannerIcon` to add an icon to the banner
- `CalloutBannerText` to add a text to the banner
- `CalloutBannerDismissButton` to add a dismiss button to the banner

Alternatively, to diverge from the DS, you're able to:
- Add your own custom content to break away from the inner content
  styling and structure.
- Use the `CalloutBannerRoot` primitive to customize the banner
  container (e.g. colour).

### `dataset`

- Type: `Dataset | undefined`