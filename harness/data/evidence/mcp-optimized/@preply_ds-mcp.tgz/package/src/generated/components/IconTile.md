---
name: IconTile
import: import { IconTile } from '@preply/ds-web-lib';
description: ""
---

# IconTile

```
import { IconTile } from '@preply/ds-web-lib';
```

## Props

### `dataset`

- Type: `Dataset | undefined`

### `svg`

- Type: `ReactSVGComponentType`
- Detailed type: `ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>>`
- Required

### `label`

- Type: `string | undefined`

If using the icon without any adjacent descriptive text, use this prop to
provide an `aria-label` for assistive technologies.

### `size`

- Type: `Size | undefined`
- Detailed type: `undefined | "large" | "medium" | "small" | "base"`
- Default value: `base`

### `tone`

- Type: `Tone | undefined`
- Detailed type: `undefined | "critical" | "ai" | "warning" | "positive" | "info" | "neutral"`
- Default value: `neutral`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`