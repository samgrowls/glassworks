---
name: showToast
import: import { showToast } from '@preply/ds-web-lib';
description: |-
  `showToast` creates and appends a toast notification instance to your
  application's `ToastProvider`.
---

# showToast

```
import { showToast } from '@preply/ds-web-lib';
```

`showToast` creates and appends a toast notification instance to your
application's `ToastProvider`.