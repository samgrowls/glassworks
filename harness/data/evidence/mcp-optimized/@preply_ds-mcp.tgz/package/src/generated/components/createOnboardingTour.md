---
name: createOnboardingTour
import: import { createOnboardingTour } from '@preply/ds-web-lib';
description: >-
  Creates a new onboarding tour.


  This factory pattern allows multiple independent tours to be nested within
  each other

  without context conflicts, as each tour maintains its own separate context and
  state.
---

# createOnboardingTour

```
import { createOnboardingTour } from '@preply/ds-web-lib';
```

Creates a new onboarding tour.

This factory pattern allows multiple independent tours to be nested within each other
without context conflicts, as each tour maintains its own separate context and state.

@example

```
const Tour = createOnboardingTour();

export const YourComponent = () => {
    return (
        <Tour.Provider totalSteps={3}>
            <Tour.Step step={0} title="Step 1" text="This is the first step of the onboarding tour.">
                <Text>Step 1</Text>
            </Tour.Step>
            <Tour.Step step={1} title="Step 2" text="This is the second step of the onboarding tour.">
                <Text>Step 2</Text>
            </Tour.Step>
            <Tour.Step step={2} title="Step 3" text="This is the final step of the onboarding tour.">
                <Text>Step 3</Text>
            </Tour.Step>
        </Tour.Provider>
    );
};
```