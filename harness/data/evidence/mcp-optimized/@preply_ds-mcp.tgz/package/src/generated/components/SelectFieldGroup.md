---
name: SelectFieldGroup
import: import { SelectFieldGroup } from '@preply/ds-web-lib';
description: ""
---

# SelectFieldGroup

```
import { SelectFieldGroup } from '@preply/ds-web-lib';
```

## Props

### `label`

- Type: `ReactNode`
- Required