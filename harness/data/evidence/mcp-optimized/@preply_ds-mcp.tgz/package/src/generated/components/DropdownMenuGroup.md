---
name: DropdownMenuGroup
import: import { DropdownMenuGroup } from '@preply/ds-web-lib';
description: Dropdown menu group
---

# DropdownMenuGroup

```
import { DropdownMenuGroup } from '@preply/ds-web-lib';
```

Dropdown menu group

@example

```
<DropdownMenuGroup label="Group">
  <DropdownMenuItem label="Item 1" />
  <DropdownMenuItem label="Item 2" />
  <DropdownMenuItem label="Item 3" />
</DropdownMenuGroup>
```

## Props

### `label`

- Type: `ReactNode`
- Required

Group label

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`