---
name: DialogSteps
import: import { DialogSteps } from '@preply/ds-web-lib';
description: ""
---

# DialogSteps

```
import { DialogSteps } from '@preply/ds-web-lib';
```

## Props

### `aria-label`

- Type: `string`
- Required

A description of the step flow and its content for screen readers.

@example

```
'Onboarding Steps', 'Checkout Steps', 'Survey Steps', etc.
```

### `initialStep`

- Type: `number | undefined`
- Default value: `1`

The initial step to start at (from `1` to `children.length`).

### `onStepChange`

- Type: `((currentStep: number, nextStep: number) => number | Promise<number | undefined> | undefined) | undefined`
- Detailed type: `undefined | (currentStep: number, nextStep: number) => number | Promise<number | undefined> | undefined`

Optional callback to control navigation between steps.

This is triggered either by using the `Steps.Previous` and `Steps.Next`
components, or by calling `goToPreviousStep`, `goToNextStep`, or
`goToStep` from the `StepsContext`.

Can be used to:
- Skip/redirect steps conditionally
- Perform async process (e.g. validation) on step changes, marking the
  element as busy/loading

@param

currentStep The current step (1-based)
nextStep The next, incoming step

@returns

Promise that resolves to:
- `undefined`: proceed with default navigation
- `number`: override the destination step

@example

```
Add async validation
const handleStepChange = async (current, next) => {
await validateStep(current);
return next;
};
Skip a step
const handleStepChange = async (current, next) => {
if (next === 2) return 3; // Skip step 2
return next;
};
```

### `dataset`

- Type: `Dataset | undefined`