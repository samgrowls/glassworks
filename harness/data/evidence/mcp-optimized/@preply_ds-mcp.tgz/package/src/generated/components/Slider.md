---
name: Slider
import: import { Slider } from '@preply/ds-web-lib';
description: A slider input that allows users to select a single value from a range.
---

# Slider

```
import { Slider } from '@preply/ds-web-lib';
```

A slider input that allows users to select a single value from a range.

@example

```
Uncontrolled
<Slider />
<Slider defaultValue={50} />
Controlled
const [value, setValue] = useState(50)
<Slider value={value} onValueChange={setValue} />
```

## Props

### `id`

- Type: `string | undefined`

The unique identifier for the range slider element.

### `aria-label`

- Type: `string | undefined`

Accessible label for the range slider.

### `aria-labelledby`

- Type: `string | undefined`

ID of the element that labels the range slider.

### `aria-describedby`

- Type: `string | undefined`

ID of the element that describes the range slider.

### `aria-invalid`

- Type: `boolean | undefined`

Indicates whether the range slider value is invalid.

### `aria-errormessage`

- Type: `string | undefined`

ID of the element that describes the error, if any.

### `value`

- Type: `number | undefined`

The controlled value of the slider.
Must be used in conjunction with `onValueChange`.

### `defaultValue`

- Type: `number | undefined`
- Default value: `0`

The value of the slider when initially rendered.
Use when you do not need to control the state of the slider.

### `onValueChange`

- Type: `((value: number) => void) | undefined`

Event handler called when the value changes.

### `name`

- Type: `string | undefined`

The name of the slider. Submitted with its owning form as part of a name/value pair.

### `min`

- Type: `number | undefined`
- Default value: `0`

The minimum value for the slider.

### `max`

- Type: `number | undefined`
- Default value: `100`

The maximum value for the slider.

### `step`

- Type: `number | undefined`
- Default value: `1`

The slider stepping interval.

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`