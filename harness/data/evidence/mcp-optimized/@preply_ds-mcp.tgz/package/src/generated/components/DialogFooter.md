---
name: DialogFooter
import: import { DialogFooter } from '@preply/ds-web-lib';
description: ""
---

# DialogFooter

```
import { DialogFooter } from '@preply/ds-web-lib';
```

## Props

### `defaultChecked`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | number | readonly string[] | undefined`

### `suppressContentEditableWarning`

- Type: `boolean | undefined`

### `suppressHydrationWarning`

- Type: `boolean | undefined`

### `accessKey`

- Type: `string | undefined`

### `autoCapitalize`

- Type: `"off" | "none" | "on" | "sentences" | "words" | "characters" | (string & {}) | undefined`

### `autoFocus`

- Type: `boolean | undefined`

### `className`

- Type: `string | undefined`

### `contentEditable`

- Type: `Booleanish | "inherit" | "plaintext-only" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "inherit" | "plaintext-only"`

### `contextMenu`

- Type: `string | undefined`

### `dir`

- Type: `string | undefined`

### `draggable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `enterKeyHint`

- Type: `"enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined`

### `hidden`

- Type: `boolean | undefined`

### `id`

- Type: `string | undefined`

### `lang`

- Type: `string | undefined`

### `nonce`

- Type: `string | undefined`

### `slot`

- Type: `string | undefined`

### `spellCheck`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `style`

- Type: `CSSProperties | undefined`

### `tabIndex`

- Type: `number | undefined`

### `title`

- Type: `string | undefined`

### `translate`

- Type: `"yes" | "no" | undefined`

### `radioGroup`

- Type: `string | undefined`

### `role`

- Type: `AriaRole | undefined`
- Detailed type: `undefined | "none" | string & {} | "search" | "alert" | "alertdialog" | "application" | "article" | "banner" | "button" | "cell" | "checkbox" | "columnheader" | "combobox" | "complementary" | "contentinfo" | "definition" | "dialog" | "directory" | "document" | "feed" | "figure" | "form" | "grid" | "gridcell" | "group" | "heading" | "img" | "link" | "list" | "listbox" | "listitem" | "log" | "main" | "marquee" | "math" | "menu" | "menubar" | "menuitem" | "menuitemcheckbox" | "menuitemradio" | "navigation" | "note" | "option" | "presentation" | "progressbar" | "radio" | "radiogroup" | "region" | "row" | "rowgroup" | "rowheader" | "scrollbar" | "searchbox" | "separator" | "slider" | "spinbutton" | "status" | "switch" | "tab" | "table" | "tablist" | "tabpanel" | "term" | "textbox" | "timer" | "toolbar" | "tooltip" | "tree" | "treegrid" | "treeitem"`

### `about`

- Type: `string | undefined`

### `content`

- Type: `string | undefined`

### `datatype`

- Type: `string | undefined`

### `inlist`

- Type: `any`

### `prefix`

- Type: `string | undefined`

### `property`

- Type: `string | undefined`

### `rel`

- Type: `string | undefined`

### `resource`

- Type: `string | undefined`

### `rev`

- Type: `string | undefined`

### `typeof`

- Type: `string | undefined`

### `vocab`

- Type: `string | undefined`

### `autoCorrect`

- Type: `string | undefined`

### `autoSave`

- Type: `string | undefined`

### `color`

- Type: `string | undefined`

### `itemProp`

- Type: `string | undefined`

### `itemScope`

- Type: `boolean | undefined`

### `itemType`

- Type: `string | undefined`

### `itemID`

- Type: `string | undefined`

### `itemRef`

- Type: `string | undefined`

### `results`

- Type: `number | undefined`

### `security`

- Type: `string | undefined`

### `unselectable`

- Type: `"off" | "on" | undefined`

### `inputMode`

- Type: `"url" | "none" | "search" | "text" | "tel" | "email" | "numeric" | "decimal" | undefined`

Hints at the type of data that might be entered by the user while editing the element or its contents

@see

{@link https://html.spec.whatwg.org/multipage/interaction.html#input-modalities:-the-inputmode-attribute}

### `is`

- Type: `string | undefined`

Specify that a standard HTML element should behave like a defined custom built-in element

@see

{@link https://html.spec.whatwg.org/multipage/custom-elements.html#attr-is}

### `aria-activedescendant`

- Type: `string | undefined`

Identifies the currently active element when DOM focus is on a composite widget, textbox, group, or application.

### `aria-atomic`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether assistive technologies will present all, or only parts of, the changed region based on the change notifications defined by the aria-relevant attribute.

### `aria-autocomplete`

- Type: `"none" | "list" | "inline" | "both" | undefined`

Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be
presented if they are made.

### `aria-braillelabel`

- Type: `string | undefined`

Defines a string value that labels the current element, which is intended to be converted into Braille.

@see

aria-label.

### `aria-brailleroledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized abbreviated description for the role of an element, which is intended to be converted into Braille.

@see

aria-roledescription.

### `aria-busy`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `aria-checked`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "checked" state of checkboxes, radio buttons, and other widgets.

@see

aria-pressed
aria-selected.

### `aria-colcount`

- Type: `number | undefined`

Defines the total number of columns in a table, grid, or treegrid.

@see

aria-colindex.

### `aria-colindex`

- Type: `number | undefined`

Defines an element's column index or position with respect to the total number of columns within a table, grid, or treegrid.

@see

aria-colcount
aria-colspan.

### `aria-colindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-colindex.

@see

aria-rowindextext.

### `aria-colspan`

- Type: `number | undefined`

Defines the number of columns spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-colindex
aria-rowspan.

### `aria-controls`

- Type: `string | undefined`

Identifies the element (or elements) whose contents or presence are controlled by the current element.

@see

aria-owns.

### `aria-current`

- Type: `boolean | "true" | "false" | "page" | "step" | "location" | "date" | "time" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "page" | "step" | "location" | "date" | "time"`

Indicates the element that represents the current item within a container or set of related elements.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `aria-description`

- Type: `string | undefined`

Defines a string value that describes or annotates the current element.

@see

related aria-describedby.

### `aria-details`

- Type: `string | undefined`

Identifies the element that provides a detailed, extended description for the object.

@see

aria-describedby.

### `aria-disabled`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is perceivable but disabled, so it is not editable or otherwise operable.

@see

aria-hidden
aria-readonly.

### `aria-dropeffect`

- Type: `"none" | "link" | "copy" | "execute" | "move" | "popup" | undefined`

Indicates what functions can be performed when a dragged object is released on the drop target.

@deprecated

in ARIA 1.1

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-expanded`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed.

### `aria-flowto`

- Type: `string | undefined`

Identifies the next element (or elements) in an alternate reading order of content which, at the user's discretion,
allows assistive technology to override the general default of reading in document source order.

### `aria-grabbed`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates an element's "grabbed" state in a drag-and-drop operation.

@deprecated

in ARIA 1.1

### `aria-haspopup`

- Type: `boolean | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree"`

Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an element.

### `aria-hidden`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element is exposed to an accessibility API.

@see

aria-disabled.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `aria-keyshortcuts`

- Type: `string | undefined`

Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element.

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-level`

- Type: `number | undefined`

Defines the hierarchical level of an element within a structure.

### `aria-live`

- Type: `"off" | "assertive" | "polite" | undefined`

Indicates that an element will be updated, and describes the types of updates the user agents, assistive technologies, and user can expect from the live region.

### `aria-modal`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether an element is modal when displayed.

### `aria-multiline`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether a text box accepts multiple lines of input or only a single line.

### `aria-multiselectable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the user may select more than one item from the current selectable descendants.

### `aria-orientation`

- Type: `"horizontal" | "vertical" | undefined`

Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous.

### `aria-owns`

- Type: `string | undefined`

Identifies an element (or elements) in order to define a visual, functional, or contextual parent/child relationship
between DOM elements where the DOM hierarchy cannot be used to represent the relationship.

@see

aria-controls.

### `aria-placeholder`

- Type: `string | undefined`

Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value.
A hint could be a sample value or a brief description of the expected format.

### `aria-posinset`

- Type: `number | undefined`

Defines an element's number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-setsize.

### `aria-pressed`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "pressed" state of toggle buttons.

@see

aria-checked
aria-selected.

### `aria-readonly`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is not editable, but is otherwise operable.

@see

aria-disabled.

### `aria-relevant`

- Type: `"text" | "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text additions" | "text removals" | undefined`

Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified.

@see

aria-atomic.

### `aria-required`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that user input is required on the element before a form may be submitted.

### `aria-roledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized description for the role of an element.

### `aria-rowcount`

- Type: `number | undefined`

Defines the total number of rows in a table, grid, or treegrid.

@see

aria-rowindex.

### `aria-rowindex`

- Type: `number | undefined`

Defines an element's row index or position with respect to the total number of rows within a table, grid, or treegrid.

@see

aria-rowcount
aria-rowspan.

### `aria-rowindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-rowindex.

@see

aria-colindextext.

### `aria-rowspan`

- Type: `number | undefined`

Defines the number of rows spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-rowindex
aria-colspan.

### `aria-selected`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates the current "selected" state of various widgets.

@see

aria-checked
aria-pressed.

### `aria-setsize`

- Type: `number | undefined`

Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-posinset.

### `aria-sort`

- Type: `"none" | "ascending" | "descending" | "other" | undefined`

Indicates if items in a table or grid are sorted in ascending or descending order.

### `aria-valuemax`

- Type: `number | undefined`

Defines the maximum allowed value for a range widget.

### `aria-valuemin`

- Type: `number | undefined`

Defines the minimum allowed value for a range widget.

### `aria-valuenow`

- Type: `number | undefined`

Defines the current value for a range widget.

@see

aria-valuetext.

### `aria-valuetext`

- Type: `string | undefined`

Defines the human readable text alternative of aria-valuenow for a range widget.

### `dangerouslySetInnerHTML`

- Type: `{ __html: string | TrustedHTML; } | undefined`
- Detailed type: `undefined | { __html: string | TrustedHTML; }`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onCopyCapture`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onCutCapture`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onPasteCapture`

- Type: `ClipboardEventHandler<HTMLElement> | undefined`

### `onCompositionEnd`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onCompositionEndCapture`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onCompositionStart`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onCompositionStartCapture`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onCompositionUpdate`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onCompositionUpdateCapture`

- Type: `CompositionEventHandler<HTMLElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLElement> | undefined`

### `onFocusCapture`

- Type: `FocusEventHandler<HTMLElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLElement> | undefined`

### `onBlurCapture`

- Type: `FocusEventHandler<HTMLElement> | undefined`

### `onChange`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onChangeCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onBeforeInput`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onBeforeInputCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onInput`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onInputCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onReset`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onResetCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onSubmit`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onSubmitCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onInvalid`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onInvalidCapture`

- Type: `FormEventHandler<HTMLElement> | undefined`

### `onLoad`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onError`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onErrorCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

### `onKeyDownCapture`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

### `onKeyPress`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

@deprecated

Use `onKeyUp` or `onKeyDown` instead

### `onKeyPressCapture`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

@deprecated

Use `onKeyUpCapture` or `onKeyDownCapture` instead

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

### `onKeyUpCapture`

- Type: `KeyboardEventHandler<HTMLElement> | undefined`

### `onAbort`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onAbortCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onCanPlay`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onCanPlayCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onCanPlayThrough`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onCanPlayThroughCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onDurationChange`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onDurationChangeCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEmptied`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEmptiedCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEncrypted`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEncryptedCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEnded`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onEndedCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadedData`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadedDataCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadedMetadata`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadedMetadataCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadStart`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onLoadStartCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPause`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPauseCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPlay`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPlayCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPlaying`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onPlayingCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onProgress`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onProgressCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onRateChange`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onRateChangeCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onResize`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onResizeCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSeeked`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSeekedCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSeeking`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSeekingCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onStalled`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onStalledCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSuspend`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSuspendCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onTimeUpdate`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onTimeUpdateCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onVolumeChange`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onVolumeChangeCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onWaiting`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onWaitingCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onAuxClick`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onAuxClickCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onClickCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onContextMenu`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onContextMenuCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onDoubleClick`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onDoubleClickCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onDrag`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragEnd`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragEndCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragEnter`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragEnterCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragExit`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragExitCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragLeave`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragLeaveCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragOver`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragOverCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragStart`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDragStartCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDrop`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onDropCapture`

- Type: `DragEventHandler<HTMLElement> | undefined`

### `onMouseDown`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseDownCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseLeave`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseMove`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseMoveCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseOut`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseOutCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseOver`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseOverCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseUp`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onMouseUpCapture`

- Type: `MouseEventHandler<HTMLElement> | undefined`

### `onSelect`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onSelectCapture`

- Type: `ReactEventHandler<HTMLElement> | undefined`

### `onTouchCancel`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchCancelCapture`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchEnd`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchEndCapture`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchMove`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchMoveCapture`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchStart`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onTouchStartCapture`

- Type: `TouchEventHandler<HTMLElement> | undefined`

### `onPointerDown`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerDownCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerMove`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerMoveCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerUp`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerUpCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerCancel`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerCancelCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerEnter`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerLeave`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerOver`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerOverCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerOut`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onPointerOutCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onGotPointerCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onGotPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onLostPointerCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onLostPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLElement> | undefined`

### `onScroll`

- Type: `UIEventHandler<HTMLElement> | undefined`

### `onScrollCapture`

- Type: `UIEventHandler<HTMLElement> | undefined`

### `onWheel`

- Type: `WheelEventHandler<HTMLElement> | undefined`

### `onWheelCapture`

- Type: `WheelEventHandler<HTMLElement> | undefined`

### `onAnimationStart`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onAnimationStartCapture`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onAnimationEnd`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onAnimationEndCapture`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onAnimationIteration`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onAnimationIterationCapture`

- Type: `AnimationEventHandler<HTMLElement> | undefined`

### `onTransitionEnd`

- Type: `TransitionEventHandler<HTMLElement> | undefined`

### `onTransitionEndCapture`

- Type: `TransitionEventHandler<HTMLElement> | undefined`

### `dataset`

- Type: `Dataset | undefined`

@deprecated

Pass data attributes as regular props instead

@example

```
<DialogFooter data-testid="dialog-footer">...</DialogFooter>
```