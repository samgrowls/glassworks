---
name: Switch
import: import { Switch } from '@preply/ds-web-lib';
description: ""
---

# Switch

```
import { Switch } from '@preply/ds-web-lib';
```

## Props

### `checked`

- Type: `boolean | undefined`

The state of the switch.
Use this for a controlled switch.

@example

```
const [checked, setChecked] = useState(initialChecked);
<Switch
  checked={checked}
  onCheckedChange={setChecked}
/>
```

### `defaultChecked`

- Type: `boolean | undefined`

The default state of the switch.
Use for an uncontrolled switch.

@example

```
<Switch
  defaultChecked={mySetting}
  onCheckedChange={updateMySetting}
/>
```

### `onCheckedChange`

- Type: `((checked: boolean) => void) | undefined`

Callback for when the switch state changes.

### `id`

- Type: `string | undefined`

The unique identifier for the switch element.

### `disabled`

- Type: `boolean | undefined`

Disables interactions with the switch.

### `aria-label`

- Type: `string | undefined`

Accessible label for the switch.

### `aria-labelledby`

- Type: `string | undefined`

ID of the element that labels the switch.

### `aria-describedby`

- Type: `string | undefined`

ID of the element that describes the switch.

### `aria-invalid`

- Type: `boolean | undefined`

Indicates whether the switch value is invalid.

### `aria-errormessage`

- Type: `string | undefined`

ID of the element that describes the error, if any.

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`