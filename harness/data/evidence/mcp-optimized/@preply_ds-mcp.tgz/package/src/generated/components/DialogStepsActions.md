---
name: DialogStepsActions
import: import { DialogStepsActions } from '@preply/ds-web-lib';
description: Wrapper around the Steps actions for usage in Dialog.
---

# DialogStepsActions

```
import { DialogStepsActions } from '@preply/ds-web-lib';
```

Wrapper around the Steps actions for usage in Dialog.

@example

```
<DialogSteps>
  <DialogStepsActions
    primaryButton={<Button size="medium" variant="primary" onClick={handleSave}>Save</Button>}
  />
</DialogSteps>
```

## Props

### `primaryButton`

- Type: `ReactNode`
- Required

Primary action button.

This button will be displayed on the last step.

@example

```
<DialogStepsActions
 primaryButton={<Button size="medium" variant="primary" onClick={() => {}}>Finish</Button>}
/>
```

### `nextButton`

- Type: `ReactNode`
- Default value: `<DialogStepsNext />`

Next step button.

This button will be used on all steps except the last one. When not provided, a default button will be used.

@example

```
<DialogStepsActions
 nextButton={<DialogStepsNext onClick={() => {}}>Next</DialogStepsNext>}
/>
```

### `previousButton`

- Type: `ReactNode`
- Default value: `<DialogStepsPrevious />`

Previous step button.

This button will be used on all steps except the first one. When not provided, a default button will be used.

@example

```
<DialogStepsActions
 previousButton={<DialogStepsPrevious onClick={() => {}}>Previous</DialogStepsPrevious>}
/>
```