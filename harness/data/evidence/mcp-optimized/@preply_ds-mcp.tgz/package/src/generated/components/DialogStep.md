---
name: DialogStep
import: import { DialogStep } from '@preply/ds-web-lib';
description: ""
---

# DialogStep

```
import { DialogStep } from '@preply/ds-web-lib';
```

## Props

### `title`

- Type: `ReactNode`
- Required

Main heading for the step.

### `description`

- Type: `ReactNode`

Optional description text displayed below the title.

### `hideHeader`

- Type: `boolean | undefined`

If true, hides the step title and description.

### `children`

- Type: `ReactNode`

Step content.