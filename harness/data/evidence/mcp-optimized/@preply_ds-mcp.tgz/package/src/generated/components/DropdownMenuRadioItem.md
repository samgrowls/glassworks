---
name: DropdownMenuRadioItem
import: import { DropdownMenuRadioItem } from '@preply/ds-web-lib';
description: Dropdown menu radio item
---

# DropdownMenuRadioItem

```
import { DropdownMenuRadioItem } from '@preply/ds-web-lib';
```

Dropdown menu radio item

@example

```
<DropdownMenuRadioItem label="Item 1" value="1" />
```

## Props

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `disabled`

- Type: `boolean | undefined`

Whether the menu item is disabled.

### `description`

- Type: `ReactNode`

Menu description

### `value`

- Type: `string`
- Required

### `leadingElement`

- Type: `ReactNode`

Menu leading element. Can be an icon, flag or avatar.

@example

```
<DropdownMenuItem leadingElement={<Icon size="24" name="home" />} />
<DropdownMenuItem leadingElement={<CountryFlag size="medium" code="US" />} />
<DropdownMenuItem leadingElement={<Avatar size="24" />} />
```

### `label`

- Type: `ReactNode`
- Required

Menu label

### `ref`

- Type: `((instance: HTMLDivElement | null) => void) | RefObject<HTMLDivElement> | null | undefined`
- Detailed type: `undefined | null | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`