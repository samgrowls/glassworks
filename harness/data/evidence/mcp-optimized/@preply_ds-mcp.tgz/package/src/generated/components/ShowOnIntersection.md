---
name: ShowOnIntersection
import: import { ShowOnIntersection } from '@preply/ds-web-lib';
description: |-
  Only renders the wrapped components once it intersects with the viewport.

  Note that elements will not be detached from the DOM if the component is
  scrolled out of view again.

  You can use `React.lazy` to lazy-load the wrapped components.

  Additionally, an `onIntersect` callback can be provided. As with
  `ObserveIntersection`, this callback will be called every time the component
  intersects with the viewport, or only the first time if `once` is set to
  `true`.
---

# ShowOnIntersection

```
import { ShowOnIntersection } from '@preply/ds-web-lib';
```

Only renders the wrapped components once it intersects with the viewport.

Note that elements will not be detached from the DOM if the component is
scrolled out of view again.

You can use `React.lazy` to lazy-load the wrapped components.

Additionally, an `onIntersect` callback can be provided. As with
`ObserveIntersection`, this callback will be called every time the component
intersects with the viewport, or only the first time if `once` is set to
`true`.

## Props

### `onIntersect`

- Type: `(() => void) | undefined`

### `once`

- Type: `boolean | undefined`

### `threshold`

- Type: `number | undefined`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `dataset`

- Type: `Dataset | undefined`