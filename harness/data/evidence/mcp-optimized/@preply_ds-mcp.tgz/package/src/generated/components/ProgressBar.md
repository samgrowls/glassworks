---
name: ProgressBar
import: import { ProgressBar } from '@preply/ds-web-lib';
description: >-
  A component that visually displays continuous progress.


  For a series of discrete progress steps, use the `ProgressSteps` component
  instead.
---

# ProgressBar

```
import { ProgressBar } from '@preply/ds-web-lib';
```

A component that visually displays continuous progress.

For a series of discrete progress steps, use the `ProgressSteps` component instead.

## Props

### `min`

- Type: `number | undefined`
- Default value: `0`

The minimum value of the progress bar.

### `max`

- Type: `number | undefined`
- Default value: `100`

The maximum value of the progress bar.

### `value`

- Type: `number`
- Required

The current value of the progress bar.

### `aria-label`

- Type: `string`
- Required

A description of the progress bar for screen readers.

@example

```
'Onboarding', 'Checkout', 'Survey', etc.
```

### `dataset`

- Type: `Dataset | undefined`