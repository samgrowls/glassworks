---
name: DialogActions
import: import { DialogActions } from '@preply/ds-web-lib';
description: ""
deprecated: true
---

# DialogActions

```
import { DialogActions } from '@preply/ds-web-lib';
```

@deprecated

use `DialogFooter` and `DialogButtonStack` instead

@example

```
<DialogFooter>
  <DialogButtonStack>
    <Button variant="secondary">Cancel</Button>
    <Button variant="primary">Save</Button>
  </DialogButtonStack>
</DialogFooter>
```

## Props

### `primaryButton`

- Type: `ReactNode`
- Required

Primary action button.

@example

```
<DialogActions
 primaryButton={<Button size="medium" variant="primary" onClick={() => {}}>Let's go</Button>}
/>
```

### `secondaryButton`

- Type: `ReactNode`

Secondary action button.

@example

```
<DialogActions
 secondaryButton={<Button size="medium" variant="tertiary" onClick={() => {}}>Cancel</Button>}
/>
```