---
name: NativeSelectField
import: import { NativeSelectField } from '@preply/ds-web-lib/components/deprecated';
description: ""
---

# NativeSelectField

```
import { NativeSelectField } from '@preply/ds-web-lib/components/deprecated';
```

## Props

### `dataset`

- Type: `Dataset | undefined`

### `label`

- Type: `ReactNode`
- Required

The field label. This is needed for accessibility purposes, but can be
hidden using the `hideLabel` prop.

### `id`

- Type: `string | undefined`

The id to be passed to the input element.
If not provided, will be generated for accessibility purposes.

### `hideLabel`

- Type: `boolean | undefined`

Use this to hide the `label` visually, but keep it in the accessibility
tree.

### `description`

- Type: `ReactNode`

Additional descriptive text that appears below the input field
to provide more context or instructions to the user.

### `error`

- Type: `ReactNode`

Error message to display when the field has an invalid value.

### `hasError`

- Type: `boolean | undefined`

Whether the field has an error.

@deprecated

Use `error` prop to explicitly describe the error to users

### `required`

- Type: `boolean | undefined`

Indicates if the field is required. When false, adds a "Optional"
indicator next to the label.

### `onClick`

- Type: `(MouseEventHandler<HTMLDivElement> & MouseEventHandler<HTMLSelectElement>) | undefined`

### `useLegacyRequiredLabel`

- Type: `boolean | undefined`

When true, adds a "Required" indicator next to the label for the required fields.
When false, adds a "Optional" indicator next to the label for the optional fields instead.

@deprecated

This is a temporary solution for gradual migration to the "Optional" label.

### `icon`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

### `name`

- Type: `string | undefined`

### `disabled`

- Type: `boolean | undefined`

### `onChange`

- Type: `ChangeEventHandler<HTMLSelectElement> | undefined`

### `onValueChange`

- Type: `((value: string) => void) | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLSelectElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLSelectElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLSelectElement> | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLSelectElement> | undefined`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLSelectElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLSelectElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLSelectElement> | undefined`

### `value`

- Type: `string | undefined`

### `defaultValue`

- Type: `string | undefined`

### `placeholder`

- Type: `string | undefined`

### `inputDataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSelectElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSelectElement | null) => void | RefObject<HTMLSelectElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`