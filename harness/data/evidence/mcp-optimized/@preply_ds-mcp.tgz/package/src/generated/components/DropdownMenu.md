---
name: DropdownMenu
import: import { DropdownMenu } from '@preply/ds-web-lib';
description: Dropdown menu that can be opened by clicking on the trigger element
---

# DropdownMenu

```
import { DropdownMenu } from '@preply/ds-web-lib';
```

Dropdown menu that can be opened by clicking on the trigger element

@example

```
<DropdownMenu
  trigger={<Button>Open menu</Button>}
>
  <DropdownMenuItem label="Item 1" />
  <DropdownMenuItem label="Item 2" />
  <DropdownMenuItem label="Item 3" />
</DropdownMenu>
```

## Props

### `defaultOpen`

- Type: `boolean | undefined`

Whether the menu is open by default if not controlled.

### `open`

- Type: `boolean | undefined`

Whether the menu is open.

### `onOpenChange`

- Type: `((open: boolean, eventDetails: ChangeEventDetails) => void) | undefined`

Callback function that is called when the menu is opened or closed.
See https://base-ui.com/react/handbook/customization#base-ui-events

### `dataset`

- Type: `Dataset | undefined`

### `keepMounted`

- Type: `boolean | undefined`

Keeps the menu content mounted even when the menu is closed.

### `trigger`

- Type: `ReactElement<any, string | JSXElementConstructor<any>>`
- Required

Trigger element.

### `children`

- Type: `ReactNode | ReactNode[]`
- Detailed type: `undefined | null | string | number | false | true | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | ReactNode[]`
- Required

Menu content.

### `side`

- Type: `Side | undefined`
- Detailed type: `undefined | "top" | "bottom" | "left" | "right" | "inline-end" | "inline-start"`
- Default value: `'bottom'`

Which side of the anchor element to align the popup against.
May automatically change to avoid collisions.

### `align`

- Type: `Align | undefined`
- Detailed type: `undefined | "center" | "start" | "end"`
- Default value: `'center'`

How to align the popup relative to the specified side.

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`