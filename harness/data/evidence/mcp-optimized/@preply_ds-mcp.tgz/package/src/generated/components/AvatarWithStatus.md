---
name: AvatarWithStatus
import: import { AvatarWithStatus } from '@preply/ds-web-lib';
description: ""
---

# AvatarWithStatus

```
import { AvatarWithStatus } from '@preply/ds-web-lib';
```

## Props

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Avatar dataset={{ 'qa-id': 'user-avatar' }} /> // will add data-qa-id="user-avatar" to the HTML element
```

### `src`

- Type: `string | undefined`

The avatar image URL.
If not provided, the default placeholder image is used instead.

### `alt`

- Type: `string | undefined`

A description of the image.
This is recommended for accessibility purposes, specifically for users
of screen readers.

@example

```
<Avatar src={...} alt="Foobar's profile" />
```

### `crossOrigin`

- Type: `CrossOrigin`
- Detailed type: `undefined | "" | "anonymous" | "use-credentials"`

CORS policy for the image.

### `online`

- Type: `boolean`
- Default value: `false`

Controls the status of the visual indicator.

### `size`

- Type: `Responsive<AvatarWithStatusSize> | undefined`
- Detailed type: `undefined | "64" | "96" | "160" | ResponsiveProp<AvatarWithStatusSize>`
- Default value: `64`