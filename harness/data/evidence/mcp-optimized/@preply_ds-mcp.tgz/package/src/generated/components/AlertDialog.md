---
name: AlertDialog
import: import { AlertDialog } from '@preply/ds-web-lib';
description: >-
  A modal alertdialog that interrupts the user with important content and
  expects a response.


  Unlike a `Dialog`, it cannot be dismissed by clicking outside or pressing
  escape.
---

# AlertDialog

```
import { AlertDialog } from '@preply/ds-web-lib';
```

A modal alertdialog that interrupts the user with important content and expects a response.

Unlike a `Dialog`, it cannot be dismissed by clicking outside or pressing escape.

@example

```
// Controlled:
<Button variant="critical" onClick={() => setIsOpen(true)}>
  Delete Account
</Button>
<AlertDialog
  open={isOpen}
  title="Delete Account"
  description="This action cannot be undone."
>
 <AlertDialog.Cancel variant="secondary" onClick={() => setIsOpen(false)}>
   Cancel
 </AlertDialog.Cancel>
 <AlertDialog.Action variant="critical" onClick={() => setIsOpen(false)}>
   Delete
 </AlertDialog.Action>
</AlertDialog>
// Uncontrolled:
<AlertDialog
  title="Delete Account"
  description="This action cannot be undone."
>
 <AlertDialog.Trigger>
   <Button variant="critical">Delete Account</Button>
 </AlertDialog.Trigger>
 <AlertDialog.Cancel variant="secondary">
   Cancel
 </AlertDialog.Cancel>
 <AlertDialog.Action variant="critical">
   Delete
 </AlertDialog.Action>
</AlertDialog>
```

## Props

### `title`

- Type: `ReactNode`
- Required

The alert's title, describing what the user needs to confirm

### `description`

- Type: `ReactNode`
- Required

Details about the action and its consequences

### `children`

- Type: `ReactNode`
- Required

The AlertDialog actions.

@see

`AlertDialog.Actions` for a common actions convenience wrapper.

### `open`

- Type: `boolean | undefined`

Controls the visibility of the alert.

Alternatively, you can use the `AlertDialog.Trigger` subcomponent for
an uncontrolled instance.

### `dataset`

- Type: `Dataset | undefined`