---
name: Box
import: import { Box } from '@preply/ds-web-lib';
description: |-
  A styleable container.

  Use this with `Layout*` components to create complex content containers.
---

# Box

```
import { Box } from '@preply/ds-web-lib';
```

A styleable container.

Use this with `Layout*` components to create complex content containers.

## Props

### `background`

- Type: `ColorBackground | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "disabled" | "accentDark" | "overlay" | "brand" | "brandB2b" | "accentLight" | "positiveLight" | "positiveDark" | "infoLight" | "infoDark" | "warningLight" | "warningDark" | "criticalLight" | "criticalDark" | "statusOnline" | "statusOffline" | "primaryInverted" | "secondaryInverted" | "tertiaryInverted"`
- Default value: `primary`

### `radius`

- Type: `Responsive<BoxRadius> | undefined`
- Detailed type: `undefined | "0" | "2" | "4" | "8" | "16" | "300" | ResponsiveProp<BoxRadius>`
- Default value: `16`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `padding`

- Type: `Responsive<ShortHand<BoxPadding>> | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | [BoxPadding, BoxPadding] | [BoxPadding, BoxPadding, BoxPadding] | [BoxPadding, BoxPadding, BoxPadding, BoxPadding] | ResponsiveProp<ShortHand<BoxPadding>>`
- Default value: `24`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLElement | null) => void | RefObject<HTMLElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`