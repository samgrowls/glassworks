---
name: DropdownMenuSelect
import: import { DropdownMenuSelect } from '@preply/ds-web-lib';
description: ""
---

# DropdownMenuSelect

```
import { DropdownMenuSelect } from '@preply/ds-web-lib';
```

## Props

### `open`

- Type: `boolean | undefined`

Whether the submenu is open.

### `onOpenChange`

- Type: `((open: boolean) => void) | undefined`

### `dataset`

- Type: `Dataset | undefined`

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `disabled`

- Type: `boolean | undefined`

Whether the menu item is disabled.

### `description`

- Type: `ReactNode`

Menu description

### `defaultValue`

- Type: `string | undefined`

### `value`

- Type: `string | undefined`

### `onValueChange`

- Type: `((value: T) => void) | undefined`

### `items`

- Type: `DropdownMenuSelectOptionProps<T>[] | undefined`

### `leadingElement`

- Type: `ReactNode`

Menu leading element. Can be an icon, flag or avatar.

@example

```
<DropdownMenuItem leadingElement={<Icon size="24" name="home" />} />
<DropdownMenuItem leadingElement={<CountryFlag size="medium" code="US" />} />
<DropdownMenuItem leadingElement={<Avatar size="24" />} />
```

### `defaultOpen`

- Type: `boolean | undefined`

Whether the submenu is open by default if not controlled.

### `side`

- Type: `Side | undefined`
- Detailed type: `undefined | "top" | "bottom" | "left" | "right" | "inline-end" | "inline-start"`
- Default value: `'bottom'`

Which side of the anchor element to align the popup against.
May automatically change to avoid collisions.

### `align`

- Type: `Align | undefined`
- Detailed type: `undefined | "center" | "start" | "end"`
- Default value: `'center'`

How to align the popup relative to the specified side.

### `label`

- Type: `ReactNode`
- Required

Menu label

### `triggerDataset`

- Type: `Dataset | undefined`

Dataset passed to the trigger opening the submenu.

### `ref`

- Type: `((instance: HTMLDivElement | null) => void) | RefObject<HTMLDivElement> | null | undefined`
- Detailed type: `undefined | null | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`