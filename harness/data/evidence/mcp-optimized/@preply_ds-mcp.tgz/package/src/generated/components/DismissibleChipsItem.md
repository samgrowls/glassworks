---
name: DismissibleChipsItem
import: import { DismissibleChipsItem } from '@preply/ds-web-lib';
description: Individual dismissible chip item for use within DismissibleChips.
---

# DismissibleChipsItem

```
import { DismissibleChipsItem } from '@preply/ds-web-lib';
```

Individual dismissible chip item for use within DismissibleChips.

@example

````
```tsx
<DismissibleChipsItem value="english">
  English
</DismissibleChipsItem>
```
````

## Props

### `dsInternalSimulation`

- Type: `"focus" | "hover" | "active" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `disabled`

- Type: `boolean | undefined`

### `icon`

- Type: `SvgComponentOrElement | undefined`
- Detailed type: `undefined | ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`

### `countryFlagCode`

- Type: `"id" | "ai" | "as" | "no" | "is" | "li" | "th" | "tr" | "td" | "af" | "ax" | "al" | "dz" | "ad" | "ao" | "aq" | "ag" | "ar" | "am" | "aw" | "sh-ac" | "asean" | "au" | "at" | "az" | "bs" | ... 244 more ... | undefined`
- Detailed type: `undefined | "id" | "ai" | "as" | "no" | "is" | "li" | "th" | "tr" | "td" | "af" | "ax" | "al" | "dz" | "ad" | "ao" | "aq" | "ag" | "ar" | "am" | "aw" | "sh-ac" | "asean" | "au" | "at" | "az" | "bs" | "bh" | "bd" | "bb" | "es-pv" | "by" | "be" | "bz" | "bj" | "bm" | "bt" | "bo" | "bq" | "ba" | "bw" | "bv" | "br" | "io" | "bn" | "bg" | "bf" | "bi" | "cv" | "kh" | "cm" | "ca" | "ic" | "es-ct" | "ky" | "cf" | "cefta" | "cl" | "cn" | "cx" | "cp" | "cc" | "co" | "km" | "ck" | "cr" | "hr" | "cu" | "cw" | "cy" | "cz" | "ci" | "cd" | "dk" | "dg" | "dj" | "dm" | "do" | "eac" | "ec" | "eg" | "sv" | "gb-eng" | "gq" | "er" | "ee" | "sz" | "et" | "eu" | "fk" | "fo" | "fm" | "fj" | "fi" | "fr" | "gf" | "pf" | "tf" | "ga" | "es-ga" | "gm" | "ge" | "de" | "gh" | "gi" | "gr" | "gl" | "gd" | "gp" | "gu" | "gt" | "gg" | "gn" | "gw" | "gy" | "ht" | "hm" | "va" | "hn" | "hk" | "hu" | "in" | "ir" | "iq" | "ie" | "im" | "il" | "it" | "jm" | "jp" | "je" | "jo" | "kz" | "ke" | "ki" | "xk" | "kw" | "kg" | "la" | "lv" | "arab" | "lb" | "ls" | "lr" | "ly" | "lt" | "lu" | "mo" | "mg" | "mw" | "my" | "mv" | "ml" | "mt" | "mh" | "mq" | "mr" | "mu" | "yt" | "mx" | "md" | "mc" | "mn" | "me" | "ms" | "ma" | "mz" | "mm" | "na" | "nr" | "np" | "nl" | "nc" | "nz" | "ni" | "ne" | "ng" | "nu" | "nf" | "kp" | "mk" | "gb-nir" | "mp" | "om" | "pc" | "pk" | "pw" | "pa" | "pg" | "py" | "pe" | "ph" | "pn" | "pl" | "pt" | "pr" | "qa" | "cg" | "ro" | "ru" | "rw" | "re" | "bl" | "sh-hl" | "sh" | "kn" | "lc" | "mf" | "pm" | "vc" | "ws" | "sm" | "st" | "sa" | "gb-sct" | "sn" | "rs" | "sc" | "sl" | "sg" | "sx" | "sk" | "si" | "sb" | "so" | "za" | "gs" | "kr" | "ss" | "es" | "lk" | "ps" | "sd" | "sr" | "sj" | "se" | "ch" | "sy" | "tw" | "tj" | "tz" | "tl" | "tg" | "tk" | "to" | "tt" | "sh-ta" | "tn" | "tm" | "tc" | "tv" | "ug" | "ua" | "ae" | "gb" | "un" | "um" | "us" | "uy" | "uz" | "vu" | "ve" | "vn" | "vg" | "vi" | "gb-wls" | "wf" | "eh" | "ye" | "zm" | "zw"`

### `value`

- Type: `string`
- Required

Unique identifier for this chip. Used for selection tracking

### `children`

- Type: `ReactNode`
- Required

Content to display inside the chip

### `counter`

- Type: `number | undefined`

Optional numeric counter to display alongside the chip label

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`