---
name: TextareaField
import: import { TextareaField } from '@preply/ds-web-lib';
description: ""
---

# TextareaField

```
import { TextareaField } from '@preply/ds-web-lib';
```

## Props

### `id`

- Type: `string | undefined`

The id to be passed to the input element.
If not provided, will be generated for accessibility purposes.

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `(MouseEventHandler<HTMLDivElement> & MouseEventHandler<HTMLTextAreaElement>) | undefined`

### `description`

- Type: `ReactNode`

Additional descriptive text that appears below the input field
to provide more context or instructions to the user.

### `hideLabel`

- Type: `boolean | undefined`

Use this to hide the `label` visually, but keep it in the accessibility
tree.

### `required`

- Type: `boolean | undefined`

Indicates if the field is required. When false, adds a "Optional"
indicator next to the label.

### `hasError`

- Type: `boolean | undefined`

Whether the field has an error.

@deprecated

Use `error` prop to explicitly describe the error to users

### `label`

- Type: `ReactNode`
- Required

The field label. This is needed for accessibility purposes, but can be
hidden using the `hideLabel` prop.

### `error`

- Type: `ReactNode`

Error message to display when the field has an invalid value.

### `useLegacyRequiredLabel`

- Type: `boolean | undefined`

When true, adds a "Required" indicator next to the label for the required fields.
When false, adds a "Optional" indicator next to the label for the optional fields instead.

@deprecated

This is a temporary solution for gradual migration to the "Optional" label.

### `name`

- Type: `string | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLTextAreaElement> | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLTextAreaElement> | undefined`

### `disabled`

- Type: `boolean | undefined`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLTextAreaElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLTextAreaElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLTextAreaElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLTextAreaElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLTextAreaElement> | undefined`

### `onChange`

- Type: `ChangeEventHandler<HTMLTextAreaElement> | undefined`

### `placeholder`

- Type: `string | undefined`

### `onValueChange`

- Type: `((value: string) => void) | undefined`

### `readOnly`

- Type: `boolean | undefined`

### `maxLength`

- Type: `number | undefined`

### `resize`

- Type: `"none" | "both" | "horizontal" | "vertical" | undefined`

### `rows`

- Type: `number | undefined`

### `defaultValue`

- Type: `string | undefined`

### `value`

- Type: `string | undefined`

### `autoComplete`

- Type: `"off" | "on" | undefined`

### `inputDataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLTextAreaElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLTextAreaElement | null) => void | RefObject<HTMLTextAreaElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`