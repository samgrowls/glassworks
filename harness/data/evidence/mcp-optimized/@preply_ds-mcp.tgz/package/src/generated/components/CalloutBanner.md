---
name: CalloutBanner
import: import { CalloutBanner } from '@preply/ds-web-lib';
description: >-
  The Callout banner is used to share informational, helpful, or promotional

  messages within a product interface.


  It appears inline within a page or section, not at the top of the screen.

  Its goal is to draw gentle attention without overpowering surrounding content.


  Do not use for urgent or blocking information—use the `<AlertBanner />`
  instead.
---

# CalloutBanner

```
import { CalloutBanner } from '@preply/ds-web-lib';
```

The Callout banner is used to share informational, helpful, or promotional
messages within a product interface.

It appears inline within a page or section, not at the top of the screen.
Its goal is to draw gentle attention without overpowering surrounding content.

Do not use for urgent or blocking information—use the `<AlertBanner />` instead.

@example

```
// Neutral banner
<CalloutBanner>
  This is a neutral banner.
</CalloutBanner>
// Info banner with leading icon
<CalloutBanner variant="info">
  <CalloutBannerIcon />
  This is an info banner.
</CalloutBanner>
// Dismissible banner with trailing dismiss button
{showBanner && (
  <CalloutBanner>
    <CalloutBannerText>
      This is a dismissible banner.
    </CalloutBannerText>
    <CalloutBannerDismissButton onClick={() => setShowBanner(false)} />
  </CalloutBanner>
)}
// Custom banner using `CalloutBannerRoot` primitive and `className` prop
{showBanner && (
  <CalloutBannerRoot className={myCustomStyles.banner}>
    <CalloutBannerIcon svg={myCustomIcon} className={myCustomStyles.icon} />
    <CalloutBannerText className={myCustomStyles.text}>
      This is a custom banner.
    </CalloutBannerText>
    <CalloutBannerDismissButton>
      <MyCustomButton onClick={() => setShowBanner(false)} />
    </CalloutBannerDismissButton>
  </CalloutBannerRoot>
)}
```

## Props

### `variant`

- Type: `"critical" | "ai" | "warning" | "positive" | "info" | "neutral" | undefined`
- Default value: `neutral`

The banner variant.
Semantic icons are also exported for the following variants:
- `info` -> `<CalloutBannerInfoIcon />`
- `warning` -> `<CalloutBannerWarningIcon />`
- `critical` -> `<CalloutBannerCriticalIcon />`
- `positive` -> `<CalloutBannerPositiveIcon />`

### `size`

- Type: `"small" | "regular" | undefined`
- Default value: `regular`

The banner text size.

### `children`

- Type: `ReactNode`
- Required

The banner message content.

To build a DS compliant banner, use:
- `CalloutBannerIcon` to add an icon to the banner
- `CalloutBannerText` to add a text to the banner
- `CalloutBannerDismissButton` to add a dismiss button to the banner

Alternatively, to diverge from the DS, you're able to:
- Add your own custom content to break away from the inner content
  styling and structure.
- Use the `CalloutBannerRoot` primitive to customize the banner
  container (e.g. colour).

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`