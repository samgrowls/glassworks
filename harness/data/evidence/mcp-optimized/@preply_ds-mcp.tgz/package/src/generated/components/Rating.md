---
name: Rating
import: import { Rating } from '@preply/ds-web-lib';
description: A component that visualizes the current rating.
---

# Rating

```
import { Rating } from '@preply/ds-web-lib';
```

A component that visualizes the current rating.

@example

```
<Rating value={2.5} />

If you are looking for a rating input field, look at RatingInput.
```

@see

RatingInput

## Props

### `value`

- Type: `number`
- Required

Can be half values.

### `size`

- Type: `Responsive<"large" | "medium" | "small"> | undefined`
- Detailed type: `undefined | "large" | "medium" | "small" | ResponsiveProp<"large" | "medium" | "small">`
- Default value: `large`

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Rating dataset={{ 'qa-id': 'accept-conditions' }} /> // will add data-qa-id="accept-conditions" to the HTML element
```