---
name: usePortalElement
import: import { usePortalElement } from '@preply/ds-web-root';
description: |-
  Provides reference to the element that can be used as a portal container.
  Use it to avoid issues with unstyled content in portals.
---

# usePortalElement

```
import { usePortalElement } from '@preply/ds-web-root';
```

Provides reference to the element that can be used as a portal container.
Use it to avoid issues with unstyled content in portals.

@example

```
import { Tooltip } from 'radix-ui';
import { usePortalElement } from '@preply/ds-web-root';

...

const portalElement = usePortalElement();
...
<Tooltip.Portal container={portalElement}>
  ...
</Tooltip.Portal>
```