---
name: Text
import: import { Text } from '@preply/ds-web-lib';
description: ""
---

# Text

```
import { Text } from '@preply/ds-web-lib';
```

## Props

### `variant`

- Type: `Responsive<TextVariant> | undefined`
- Detailed type: `undefined | "caption-regular" | "caption-semibold" | "small-regular" | "small-regular-italic" | "small-semibold" | "small-semibold-italic" | "default-regular" | "default-regular-italic" | "default-semibold" | "default-semibold-italic" | "large-regular" | "large-regular-italic" | "large-semibold" | "large-semibold-italic" | ResponsiveProp<TextVariant>`

### `accent`

- Type: `TextAccent | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "inverted" | "warning" | "positive" | "accentDark" | "placeholder" | "info"`

### `strong`

- Type: `boolean | undefined`

### `centered`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `tag`

- Type: `TextTag | undefined`
- Detailed type: `undefined | "p" | "div" | "span"`
- Default value: `p`

### `dataset`

- Type: `Dataset | undefined`

### `className`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLParagraphElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLParagraphElement | null) => void | RefObject<HTMLParagraphElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`