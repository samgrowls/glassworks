---
name: CountryFlag
import: import { CountryFlag } from '@preply/ds-web-lib';
description: Renders an `img` element with the country flag. Passes down all the
  other props to the `img` element.
---

# CountryFlag

```
import { CountryFlag } from '@preply/ds-web-lib';
```

Renders an `img` element with the country flag. Passes down all the other props to the `img` element.

@example

```
<CountryFlag code="ua" alt="Ukraine" />
Lazy loading the img
<CountryFlag code="ua" alt="Ukraine" loading="lazy" />
```

## Props

### `id`

- Type: `string | undefined`

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `onClick`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

### `onMouseDown`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseUp`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseMove`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onPointerDown`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerEnter`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `title`

- Type: `string | undefined`

### `defaultChecked`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | number | readonly string[] | undefined`

### `suppressContentEditableWarning`

- Type: `boolean | undefined`

### `suppressHydrationWarning`

- Type: `boolean | undefined`

### `accessKey`

- Type: `string | undefined`

### `autoCapitalize`

- Type: `"off" | "none" | "on" | "sentences" | "words" | "characters" | (string & {}) | undefined`

### `autoFocus`

- Type: `boolean | undefined`

### `contentEditable`

- Type: `Booleanish | "inherit" | "plaintext-only" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "inherit" | "plaintext-only"`

### `contextMenu`

- Type: `string | undefined`

### `dir`

- Type: `string | undefined`

### `draggable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `enterKeyHint`

- Type: `"enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined`

### `hidden`

- Type: `boolean | undefined`

### `lang`

- Type: `string | undefined`

### `nonce`

- Type: `string | undefined`

### `slot`

- Type: `string | undefined`

### `spellCheck`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `style`

- Type: `CSSProperties | undefined`

### `tabIndex`

- Type: `number | undefined`

### `translate`

- Type: `"yes" | "no" | undefined`

### `radioGroup`

- Type: `string | undefined`

### `role`

- Type: `AriaRole | undefined`
- Detailed type: `undefined | "none" | string & {} | "search" | "alert" | "alertdialog" | "application" | "article" | "banner" | "button" | "cell" | "checkbox" | "columnheader" | "combobox" | "complementary" | "contentinfo" | "definition" | "dialog" | "directory" | "document" | "feed" | "figure" | "form" | "grid" | "gridcell" | "group" | "heading" | "img" | "link" | "list" | "listbox" | "listitem" | "log" | "main" | "marquee" | "math" | "menu" | "menubar" | "menuitem" | "menuitemcheckbox" | "menuitemradio" | "navigation" | "note" | "option" | "presentation" | "progressbar" | "radio" | "radiogroup" | "region" | "row" | "rowgroup" | "rowheader" | "scrollbar" | "searchbox" | "separator" | "slider" | "spinbutton" | "status" | "switch" | "tab" | "table" | "tablist" | "tabpanel" | "term" | "textbox" | "timer" | "toolbar" | "tooltip" | "tree" | "treegrid" | "treeitem"`

### `about`

- Type: `string | undefined`

### `content`

- Type: `string | undefined`

### `datatype`

- Type: `string | undefined`

### `inlist`

- Type: `any`

### `prefix`

- Type: `string | undefined`

### `property`

- Type: `string | undefined`

### `rel`

- Type: `string | undefined`

### `resource`

- Type: `string | undefined`

### `rev`

- Type: `string | undefined`

### `typeof`

- Type: `string | undefined`

### `vocab`

- Type: `string | undefined`

### `autoCorrect`

- Type: `string | undefined`

### `autoSave`

- Type: `string | undefined`

### `color`

- Type: `string | undefined`

### `itemProp`

- Type: `string | undefined`

### `itemScope`

- Type: `boolean | undefined`

### `itemType`

- Type: `string | undefined`

### `itemID`

- Type: `string | undefined`

### `itemRef`

- Type: `string | undefined`

### `results`

- Type: `number | undefined`

### `security`

- Type: `string | undefined`

### `unselectable`

- Type: `"off" | "on" | undefined`

### `inputMode`

- Type: `"url" | "none" | "search" | "text" | "tel" | "email" | "numeric" | "decimal" | undefined`

Hints at the type of data that might be entered by the user while editing the element or its contents

@see

{@link https://html.spec.whatwg.org/multipage/interaction.html#input-modalities:-the-inputmode-attribute}

### `is`

- Type: `string | undefined`

Specify that a standard HTML element should behave like a defined custom built-in element

@see

{@link https://html.spec.whatwg.org/multipage/custom-elements.html#attr-is}

### `aria-activedescendant`

- Type: `string | undefined`

Identifies the currently active element when DOM focus is on a composite widget, textbox, group, or application.

### `aria-atomic`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether assistive technologies will present all, or only parts of, the changed region based on the change notifications defined by the aria-relevant attribute.

### `aria-autocomplete`

- Type: `"none" | "list" | "inline" | "both" | undefined`

Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be
presented if they are made.

### `aria-braillelabel`

- Type: `string | undefined`

Defines a string value that labels the current element, which is intended to be converted into Braille.

@see

aria-label.

### `aria-brailleroledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized abbreviated description for the role of an element, which is intended to be converted into Braille.

@see

aria-roledescription.

### `aria-busy`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `aria-checked`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "checked" state of checkboxes, radio buttons, and other widgets.

@see

aria-pressed
aria-selected.

### `aria-colcount`

- Type: `number | undefined`

Defines the total number of columns in a table, grid, or treegrid.

@see

aria-colindex.

### `aria-colindex`

- Type: `number | undefined`

Defines an element's column index or position with respect to the total number of columns within a table, grid, or treegrid.

@see

aria-colcount
aria-colspan.

### `aria-colindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-colindex.

@see

aria-rowindextext.

### `aria-colspan`

- Type: `number | undefined`

Defines the number of columns spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-colindex
aria-rowspan.

### `aria-controls`

- Type: `string | undefined`

Identifies the element (or elements) whose contents or presence are controlled by the current element.

@see

aria-owns.

### `aria-current`

- Type: `boolean | "true" | "false" | "page" | "step" | "location" | "date" | "time" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "page" | "step" | "location" | "date" | "time"`

Indicates the element that represents the current item within a container or set of related elements.

### `aria-description`

- Type: `string | undefined`

Defines a string value that describes or annotates the current element.

@see

related aria-describedby.

### `aria-details`

- Type: `string | undefined`

Identifies the element that provides a detailed, extended description for the object.

@see

aria-describedby.

### `aria-disabled`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is perceivable but disabled, so it is not editable or otherwise operable.

@see

aria-hidden
aria-readonly.

### `aria-dropeffect`

- Type: `"none" | "link" | "copy" | "execute" | "move" | "popup" | undefined`

Indicates what functions can be performed when a dragged object is released on the drop target.

@deprecated

in ARIA 1.1

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-expanded`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed.

### `aria-flowto`

- Type: `string | undefined`

Identifies the next element (or elements) in an alternate reading order of content which, at the user's discretion,
allows assistive technology to override the general default of reading in document source order.

### `aria-grabbed`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates an element's "grabbed" state in a drag-and-drop operation.

@deprecated

in ARIA 1.1

### `aria-haspopup`

- Type: `boolean | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree"`

Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an element.

### `aria-hidden`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element is exposed to an accessibility API.

@see

aria-disabled.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `aria-keyshortcuts`

- Type: `string | undefined`

Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element.

### `aria-level`

- Type: `number | undefined`

Defines the hierarchical level of an element within a structure.

### `aria-live`

- Type: `"off" | "assertive" | "polite" | undefined`

Indicates that an element will be updated, and describes the types of updates the user agents, assistive technologies, and user can expect from the live region.

### `aria-modal`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether an element is modal when displayed.

### `aria-multiline`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether a text box accepts multiple lines of input or only a single line.

### `aria-multiselectable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the user may select more than one item from the current selectable descendants.

### `aria-orientation`

- Type: `"horizontal" | "vertical" | undefined`

Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous.

### `aria-owns`

- Type: `string | undefined`

Identifies an element (or elements) in order to define a visual, functional, or contextual parent/child relationship
between DOM elements where the DOM hierarchy cannot be used to represent the relationship.

@see

aria-controls.

### `aria-placeholder`

- Type: `string | undefined`

Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value.
A hint could be a sample value or a brief description of the expected format.

### `aria-posinset`

- Type: `number | undefined`

Defines an element's number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-setsize.

### `aria-pressed`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "pressed" state of toggle buttons.

@see

aria-checked
aria-selected.

### `aria-readonly`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is not editable, but is otherwise operable.

@see

aria-disabled.

### `aria-relevant`

- Type: `"text" | "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text additions" | "text removals" | undefined`

Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified.

@see

aria-atomic.

### `aria-required`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that user input is required on the element before a form may be submitted.

### `aria-roledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized description for the role of an element.

### `aria-rowcount`

- Type: `number | undefined`

Defines the total number of rows in a table, grid, or treegrid.

@see

aria-rowindex.

### `aria-rowindex`

- Type: `number | undefined`

Defines an element's row index or position with respect to the total number of rows within a table, grid, or treegrid.

@see

aria-rowcount
aria-rowspan.

### `aria-rowindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-rowindex.

@see

aria-colindextext.

### `aria-rowspan`

- Type: `number | undefined`

Defines the number of rows spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-rowindex
aria-colspan.

### `aria-selected`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates the current "selected" state of various widgets.

@see

aria-checked
aria-pressed.

### `aria-setsize`

- Type: `number | undefined`

Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-posinset.

### `aria-sort`

- Type: `"none" | "ascending" | "descending" | "other" | undefined`

Indicates if items in a table or grid are sorted in ascending or descending order.

### `aria-valuemax`

- Type: `number | undefined`

Defines the maximum allowed value for a range widget.

### `aria-valuemin`

- Type: `number | undefined`

Defines the minimum allowed value for a range widget.

### `aria-valuenow`

- Type: `number | undefined`

Defines the current value for a range widget.

@see

aria-valuetext.

### `aria-valuetext`

- Type: `string | undefined`

Defines the human readable text alternative of aria-valuenow for a range widget.

### `dangerouslySetInnerHTML`

- Type: `{ __html: string | TrustedHTML; } | undefined`
- Detailed type: `undefined | { __html: string | TrustedHTML; }`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onCopyCapture`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onCutCapture`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onPasteCapture`

- Type: `ClipboardEventHandler<HTMLImageElement> | undefined`

### `onCompositionEnd`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onCompositionEndCapture`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onCompositionStart`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onCompositionStartCapture`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onCompositionUpdate`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onCompositionUpdateCapture`

- Type: `CompositionEventHandler<HTMLImageElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLImageElement> | undefined`

### `onFocusCapture`

- Type: `FocusEventHandler<HTMLImageElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLImageElement> | undefined`

### `onBlurCapture`

- Type: `FocusEventHandler<HTMLImageElement> | undefined`

### `onChange`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onChangeCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onBeforeInput`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onBeforeInputCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onInput`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onInputCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onReset`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onResetCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onSubmit`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onSubmitCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onInvalid`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onInvalidCapture`

- Type: `FormEventHandler<HTMLImageElement> | undefined`

### `onLoad`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onError`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onErrorCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onKeyDownCapture`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

### `onKeyPress`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

@deprecated

Use `onKeyUp` or `onKeyDown` instead

### `onKeyPressCapture`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

@deprecated

Use `onKeyUpCapture` or `onKeyDownCapture` instead

### `onKeyUpCapture`

- Type: `KeyboardEventHandler<HTMLImageElement> | undefined`

### `onAbort`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onAbortCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onCanPlay`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onCanPlayCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onCanPlayThrough`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onCanPlayThroughCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onDurationChange`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onDurationChangeCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEmptied`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEmptiedCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEncrypted`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEncryptedCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEnded`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onEndedCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadedData`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadedDataCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadedMetadata`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadedMetadataCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadStart`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onLoadStartCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPause`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPauseCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPlay`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPlayCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPlaying`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onPlayingCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onProgress`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onProgressCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onRateChange`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onRateChangeCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onResize`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onResizeCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSeeked`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSeekedCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSeeking`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSeekingCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onStalled`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onStalledCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSuspend`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSuspendCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onTimeUpdate`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onTimeUpdateCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onVolumeChange`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onVolumeChangeCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onWaiting`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onWaitingCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onAuxClick`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onAuxClickCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onClickCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onContextMenu`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onContextMenuCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onDoubleClick`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onDoubleClickCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onDrag`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragEnd`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragEndCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragEnter`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragEnterCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragExit`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragExitCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragLeave`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragLeaveCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragOver`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragOverCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragStart`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDragStartCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDrop`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onDropCapture`

- Type: `DragEventHandler<HTMLImageElement> | undefined`

### `onMouseDownCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseLeave`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseMoveCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseOut`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseOutCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseOver`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseOverCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onMouseUpCapture`

- Type: `MouseEventHandler<HTMLImageElement> | undefined`

### `onSelect`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onSelectCapture`

- Type: `ReactEventHandler<HTMLImageElement> | undefined`

### `onTouchCancel`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchCancelCapture`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchEnd`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchEndCapture`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchMove`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchMoveCapture`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchStart`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onTouchStartCapture`

- Type: `TouchEventHandler<HTMLImageElement> | undefined`

### `onPointerDownCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerMove`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerMoveCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerUp`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerUpCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerCancel`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerCancelCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerLeave`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerOver`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerOverCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerOut`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onPointerOutCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onGotPointerCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onGotPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onLostPointerCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onLostPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLImageElement> | undefined`

### `onScroll`

- Type: `UIEventHandler<HTMLImageElement> | undefined`

### `onScrollCapture`

- Type: `UIEventHandler<HTMLImageElement> | undefined`

### `onWheel`

- Type: `WheelEventHandler<HTMLImageElement> | undefined`

### `onWheelCapture`

- Type: `WheelEventHandler<HTMLImageElement> | undefined`

### `onAnimationStart`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onAnimationStartCapture`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onAnimationEnd`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onAnimationEndCapture`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onAnimationIteration`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onAnimationIterationCapture`

- Type: `AnimationEventHandler<HTMLImageElement> | undefined`

### `onTransitionEnd`

- Type: `TransitionEventHandler<HTMLImageElement> | undefined`

### `onTransitionEndCapture`

- Type: `TransitionEventHandler<HTMLImageElement> | undefined`

### `crossOrigin`

- Type: `CrossOrigin`
- Detailed type: `undefined | "" | "anonymous" | "use-credentials"`

### `decoding`

- Type: `"async" | "auto" | "sync" | undefined`

### `fetchPriority`

- Type: `"auto" | "high" | "low" | undefined`

### `loading`

- Type: `"eager" | "lazy" | undefined`

### `referrerPolicy`

- Type: `HTMLAttributeReferrerPolicy | undefined`
- Detailed type: `undefined | "" | "no-referrer" | "no-referrer-when-downgrade" | "origin" | "origin-when-cross-origin" | "same-origin" | "strict-origin" | "strict-origin-when-cross-origin" | "unsafe-url"`

### `sizes`

- Type: `string | undefined`

### `srcSet`

- Type: `string | undefined`

### `useMap`

- Type: `string | undefined`

### `code`

- Type: `"id" | "ai" | "as" | "no" | "is" | "li" | "th" | "tr" | "td" | "af" | "ax" | "al" | "dz" | "ad" | "ao" | "aq" | "ag" | "ar" | "am" | "aw" | "sh-ac" | "asean" | "au" | "at" | "az" | "bs" | ... 243 more ... | "zw"`
- Detailed type: `"id" | "ai" | "as" | "no" | "is" | "li" | "th" | "tr" | "td" | "af" | "ax" | "al" | "dz" | "ad" | "ao" | "aq" | "ag" | "ar" | "am" | "aw" | "sh-ac" | "asean" | "au" | "at" | "az" | "bs" | "bh" | "bd" | "bb" | "es-pv" | "by" | "be" | "bz" | "bj" | "bm" | "bt" | "bo" | "bq" | "ba" | "bw" | "bv" | "br" | "io" | "bn" | "bg" | "bf" | "bi" | "cv" | "kh" | "cm" | "ca" | "ic" | "es-ct" | "ky" | "cf" | "cefta" | "cl" | "cn" | "cx" | "cp" | "cc" | "co" | "km" | "ck" | "cr" | "hr" | "cu" | "cw" | "cy" | "cz" | "ci" | "cd" | "dk" | "dg" | "dj" | "dm" | "do" | "eac" | "ec" | "eg" | "sv" | "gb-eng" | "gq" | "er" | "ee" | "sz" | "et" | "eu" | "fk" | "fo" | "fm" | "fj" | "fi" | "fr" | "gf" | "pf" | "tf" | "ga" | "es-ga" | "gm" | "ge" | "de" | "gh" | "gi" | "gr" | "gl" | "gd" | "gp" | "gu" | "gt" | "gg" | "gn" | "gw" | "gy" | "ht" | "hm" | "va" | "hn" | "hk" | "hu" | "in" | "ir" | "iq" | "ie" | "im" | "il" | "it" | "jm" | "jp" | "je" | "jo" | "kz" | "ke" | "ki" | "xk" | "kw" | "kg" | "la" | "lv" | "arab" | "lb" | "ls" | "lr" | "ly" | "lt" | "lu" | "mo" | "mg" | "mw" | "my" | "mv" | "ml" | "mt" | "mh" | "mq" | "mr" | "mu" | "yt" | "mx" | "md" | "mc" | "mn" | "me" | "ms" | "ma" | "mz" | "mm" | "na" | "nr" | "np" | "nl" | "nc" | "nz" | "ni" | "ne" | "ng" | "nu" | "nf" | "kp" | "mk" | "gb-nir" | "mp" | "om" | "pc" | "pk" | "pw" | "pa" | "pg" | "py" | "pe" | "ph" | "pn" | "pl" | "pt" | "pr" | "qa" | "cg" | "ro" | "ru" | "rw" | "re" | "bl" | "sh-hl" | "sh" | "kn" | "lc" | "mf" | "pm" | "vc" | "ws" | "sm" | "st" | "sa" | "gb-sct" | "sn" | "rs" | "sc" | "sl" | "sg" | "sx" | "sk" | "si" | "sb" | "so" | "za" | "gs" | "kr" | "ss" | "es" | "lk" | "ps" | "sd" | "sr" | "sj" | "se" | "ch" | "sy" | "tw" | "tj" | "tz" | "tl" | "tg" | "tk" | "to" | "tt" | "sh-ta" | "tn" | "tm" | "tc" | "tv" | "ug" | "ua" | "ae" | "gb" | "un" | "um" | "us" | "uy" | "uz" | "vu" | "ve" | "vn" | "vg" | "vi" | "gb-wls" | "wf" | "eh" | "ye" | "zm" | "zw"`
- Required

### `alt`

- Type: `string`
- Required

An accessible alt description of the flag.
This will usually be the localized country or language name.

### `size`

- Type: `Size | undefined`
- Detailed type: `undefined | "large" | "medium" | "small"`
- Default value: `small`

### `simplified`

- Type: `boolean | undefined`
- Default value: `true`

For some countries (like ES and MX) the simplified flags are automatically used to speed up loading them.

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<CountryFlag dataset={{ 'qa-id': 'tutor-country-of-birth' }} code="ua" alt="Ukraine" /> // will add data-qa-id="accept-conditions" to the HTML element
```

### `ref`

- Type: `LegacyRef<HTMLImageElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLImageElement | null) => void | RefObject<HTMLImageElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`