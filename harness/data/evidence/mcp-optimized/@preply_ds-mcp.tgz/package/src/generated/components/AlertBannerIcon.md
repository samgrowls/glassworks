---
name: AlertBannerIcon
import: import { AlertBannerIcon } from '@preply/ds-web-lib';
description: |-
  An icon for the alert banner.

  This component will render the appropriate icon based on the parent
  `AlertBannerRoot` component's `variant` prop — these semantic icons are also
  exported for the following variants:
  - `positive` -> `<AlertBannerPositiveIcon />`
  - `warning` -> `<AlertBannerWarningIcon />`
  - `critical` -> `<AlertBannerCriticalIcon />`

  The icon can be overridden by passing a custom SVG icon via the `svg` prop.

  If you want to place any leading element inside of the `AlertBanner`,
  with the same spacing as the icon, you can pass it as a child element.

  Note: The root of this component is a `div` element. You can use the
  `className` prop to override the default styles for the **container**.
---

# AlertBannerIcon

```
import { AlertBannerIcon } from '@preply/ds-web-lib';
```

An icon for the alert banner.

This component will render the appropriate icon based on the parent
`AlertBannerRoot` component's `variant` prop — these semantic icons are also
exported for the following variants:
- `positive` -> `<AlertBannerPositiveIcon />`
- `warning` -> `<AlertBannerWarningIcon />`
- `critical` -> `<AlertBannerCriticalIcon />`

The icon can be overridden by passing a custom SVG icon via the `svg` prop.

If you want to place any leading element inside of the `AlertBanner`,
with the same spacing as the icon, you can pass it as a child element.

Note: The root of this component is a `div` element. You can use the
`className` prop to override the default styles for the **container**.

@example

```
// Context-aware icon
<AlertBannerIcon />
// Custom SVG icon
<AlertBannerIcon svg={myCustomIcon} />
// Icon container style override class name
<AlertBannerIcon className={myCustomStyles.icon} />
// Custom leading element
<AlertBannerIcon>
  <Avatar size="24" />
</AlertBannerIcon>
```

## Props

### `svg`

- Type: `SvgComponentOrElement | undefined`
- Detailed type: `undefined | ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>> | ReactElement<any, string | JSXElementConstructor<any>>`

### `className`

- Type: `string | undefined`
- Default value: `""`

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`