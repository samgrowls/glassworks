---
name: PreplyLogo
import: import { PreplyLogo } from '@preply/ds-web-lib';
description: ""
---

# PreplyLogo

```
import { PreplyLogo } from '@preply/ds-web-lib';
```

## Props

### `iconOnly`

- Type: `boolean | undefined`
- Default value: `false`

### `business`

- Type: `boolean | undefined`
- Default value: `false`

Displays the B2B version of the logo.

### `inverted`

- Type: `boolean | undefined`
- Default value: `false`

Inverts the background and foreground colors so the logo can be displayed
on dark brackgrounds.

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Avatar dataset={{ 'qa-id': 'user-avatar' }} /> // will add data-qa-id="user-avatar" to the HTML element
```

### `size`

- Type: `"xs" | "s" | "m" | "l" | undefined`
- Default value: `m`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`