---
name: CalloutBannerDismissButton
import: import { CalloutBannerDismissButton } from '@preply/ds-web-lib';
description: |-
  A dismiss button for the callout banner.

  Note: The root of this component is a `div` element. It renders the default
  dismiss button by default, but you can override it with the `children` prop.
  You can also use the `className` prop to override the default styles for the
  container.
---

# CalloutBannerDismissButton

```
import { CalloutBannerDismissButton } from '@preply/ds-web-lib';
```

A dismiss button for the callout banner.

Note: The root of this component is a `div` element. It renders the default
dismiss button by default, but you can override it with the `children` prop.
You can also use the `className` prop to override the default styles for the
container.

@example

```
// Default dismiss button
<CalloutBannerDismissButton onClick={() => setShowBanner(false)} />
// Custom dismiss button
<CalloutBannerDismissButton>
  <MyCustomButton onClick={() => setShowBanner(false)} />
</CalloutBannerDismissButton>
// Custom dismiss button with style override class name
<CalloutBannerDismissButton className={myCustomStyles.dismissButtonContainer}>
  <MyCustomButton onClick={() => setShowBanner(false)} />
</CalloutBannerDismissButton>
```

## Props

### `children`

- Type: `ReactNode`

If present, the component will render the children instead of the
default dismiss button.

### `className`

- Type: `string | undefined`
- Default value: `""`

A class name to apply to the dismiss button **container**.

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `onClick`

- Type: `(() => void) | undefined`

### `dataset`

- Type: `Dataset | undefined`