---
name: FieldButton
import: import { FieldButton } from '@preply/ds-web-lib';
description: ""
---

# FieldButton

```
import { FieldButton } from '@preply/ds-web-lib';
```

## Props

### `svg`

- Type: `ReactSVGComponentType`
- Detailed type: `ComponentClass<SVGAttributes<SVGElement>, any> | FunctionComponent<SVGAttributes<SVGElement>>`
- Required

### `assistiveText`

- Type: `string`
- Required

### `onClick`

- Type: `MouseEventHandler`
- Required

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`