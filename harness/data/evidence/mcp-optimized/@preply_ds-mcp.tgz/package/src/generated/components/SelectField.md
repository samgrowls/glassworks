---
name: SelectField
import: import { SelectField } from '@preply/ds-web-lib';
description: ""
---

# SelectField

```
import { SelectField } from '@preply/ds-web-lib';
```

## Props

### `id`

- Type: `string | undefined`

The id to be passed to the input element.
If not provided, will be generated for accessibility purposes.

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLDivElement> | undefined`

### `description`

- Type: `ReactNode`

Additional descriptive text that appears below the input field
to provide more context or instructions to the user.

### `hideLabel`

- Type: `boolean | undefined`

Use this to hide the `label` visually, but keep it in the accessibility
tree.

### `required`

- Type: `boolean | undefined`

Indicates if the field is required. When false, adds a "Optional"
indicator next to the label.
Whether the select is required

### `hasError`

- Type: `boolean | undefined`

Whether the field has an error.

@deprecated

Use `error` prop to explicitly describe the error to users

### `label`

- Type: `ReactNode`
- Required

The field label. This is needed for accessibility purposes, but can be
hidden using the `hideLabel` prop.

### `error`

- Type: `ReactNode`

Error message to display when the field has an invalid value.

### `useLegacyRequiredLabel`

- Type: `boolean | undefined`

When true, adds a "Required" indicator next to the label for the required fields.
When false, adds a "Optional" indicator next to the label for the optional fields instead.

@deprecated

This is a temporary solution for gradual migration to the "Optional" label.

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `name`

- Type: `string | undefined`

HTML name attribute

### `children`

- Type: `ReactNode`
- Required

Items to display in the select

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLButtonElement> | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLButtonElement> | undefined`

### `disabled`

- Type: `boolean | undefined`

Whether the select is disabled

### `defaultValue`

- Type: `string | undefined`

Default value when uncontrolled

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `onFocus`

- Type: `FocusEventHandler<HTMLButtonElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLButtonElement> | undefined`

### `value`

- Type: `string | undefined`

Controlled value of the select

### `placeholder`

- Type: `string | undefined`

Placeholder text when no value is selected

### `icon`

- Type: `ReactNode`

Icon to display on the left side

### `onValueChange`

- Type: `((value: string) => void) | undefined`

Callback when value changes

### `inputDataset`

- Type: `Dataset | undefined`

Dataset for the input element

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`