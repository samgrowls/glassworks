---
name: Dialog
import: import { Dialog } from '@preply/ds-web-lib';
description: |-
  A modal dialog component that can be used to show content in an overlay.

  Composed of:
  - Dialog: The main component
  - DialogActions: Footer actions with primary and secondary buttons
  - DialogSteps: Steps component for multi-step flows
  - DialogStep: Step component for each step
  - DialogStepsActions: Actions component for the steps
---

# Dialog

```
import { Dialog } from '@preply/ds-web-lib';
```

A modal dialog component that can be used to show content in an overlay.

Composed of:
- Dialog: The main component
- DialogActions: Footer actions with primary and secondary buttons
- DialogSteps: Steps component for multi-step flows
- DialogStep: Step component for each step
- DialogStepsActions: Actions component for the steps

@example

```
<Dialog
  open={isOpen}
  onClose={handleClose}
  title="Save Changes"
  description="Optional description"
>
  Content
  <DialogFooter>
    <DialogButtonStack>
      <Button onClick={handleCancel}>Cancel</Button>
      <Button onClick={handleSave}>Save</Button>
    </DialogButtonStack>
  </DialogFooter>
</Dialog>
```

## Props

### `open`

- Type: `boolean`
- Required

Controls the visibility of the dialog

### `children`

- Type: `ReactNode`
- Required

Content to be rendered inside the dialog

### `size`

- Type: `Responsive<"xs" | "md" | "sm" | "lg"> | undefined`
- Detailed type: `undefined | "xs" | "md" | "sm" | "lg" | ResponsiveProp<"xs" | "md" | "sm" | "lg">`
- Default value: `md`

Controls the width of the dialog on desktop

@deprecated

use default size for all dialogs

### `title`

- Type: `ReactNode`
- Required

### `description`

- Type: `ReactNode`

### `leadingElement`

- Type: `ReactNode`

### `hideHeader`

- Type: `boolean | undefined`
- Default value: `false`

When true
visually hides the header (title and description) while
keeping it accessible to screen readers

@deprecated

use `DialogRoot` component directly instead

### `onClose`

- Type: `(() => void) | undefined`

Callback fired when the user tries to close the dialog (via escape
key, overlay click, or close button).

### `mobileFullHeight`

- Type: `boolean | undefined`

Makes the Dialog take up the full screen height on mobile screens, i.e.
screens under the `medium-l` breakpoint.

### `dataset`

- Type: `Dataset | undefined`