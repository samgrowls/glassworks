---
name: Divider
import: import { Divider } from '@preply/ds-web-lib';
description: ""
---

# Divider

```
import { Divider } from '@preply/ds-web-lib';
```

## Props

### `size`

- Type: `"large" | "small" | undefined`
- Default value: `small`