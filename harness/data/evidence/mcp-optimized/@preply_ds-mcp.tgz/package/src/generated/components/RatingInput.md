---
name: RatingInput
import: import { RatingInput } from '@preply/ds-web-lib';
description: >-
  A component that allows rating through a series of discrete values.


  If you need to visualize the current rating without the users changing it,
  look at Rating.
---

# RatingInput

```
import { RatingInput } from '@preply/ds-web-lib';
```

A component that allows rating through a series of discrete values.

If you need to visualize the current rating without the users changing it, look at Rating.

@see

Rating

## Props

### `value`

- Type: `number | undefined`

Half values can be shown, but the users can only set full values by interacting.

Use FormControl to use the component inside a form.

@see

{@link https://github.com/preply/design-system/blob/main/packages/web-lib/src/components/FormControl/FormControl.stories.tsx FormControl.stories.tsx} for complete examples.

In case of integrations with forms **without FormControl**, you have to keep in mind that the
underlying input element is of type `range`, which means:
1. `readOnly` is ineffective
2. `required` is ineffective.
3. `pattern` is ineffective, validation on input of type range isn't supported. So you need a custom validation if you don't accept 0 as a value (which means the users hasn't rate).
https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input/range#additional_attributes
https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input/range#validation

### `id`

- Type: `string | undefined`

The id of the input element.

### `name`

- Type: `string | undefined`

The name of the input element.

### `hasError`

- Type: `boolean | undefined`

Shows the component's error state, and sets `aria-invalid="true"` on the input element.

The attribute should be set as the result of a submit process, and you should tell the
user there is an error (we suggest to use custom input fields inside FormControl).

@see

https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Attributes/aria-invalid#description

Please note: you don't need to use it if you use the component inside FormControl.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

FormControl passes aria-invalid to every errored field inside it, don't pass it manually.

@deprecated

If you are looking at how to show the error state without FormControl, use `hasError` instead.

@ignore

### `required`

- Type: `boolean | undefined`

Sets aria-required to true.

In case of integrations with forms, keep in mind that the underlying input element
is of type `range`, which means `required` is ineffective.

@see

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input/range#additional_attributes

This is automatically handled by FormControl.
{@link https://github.com/preply/design-system/blob/main/packages/web-lib/src/components/FormControl/FormControl.stories.tsx FormControl.stories.tsx} for complete examples.

### `defaultValue`

- Type: `number | undefined`
- Default value: `0`

### `onValueChange`

- Type: `((value: number) => void) | undefined`

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Rating dataset={{ 'qa-id': 'accept-conditions' }} /> // will add data-qa-id="accept-conditions" to the HTML element
```

### `dsInternalSimulation`

- Type: `"focus" | "hover" | undefined`

@deprecated

This is meant for internal DS usage only. Do not use it in your code.

@ignore

### `onBlur`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onChange`

- Type: `ChangeEventHandler<HTMLInputElement> | undefined`

### `aria-label`

- Type: `string | undefined`

### `aria-labelledby`

- Type: `string | undefined`

### `aria-describedby`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLInputElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLInputElement | null) => void | RefObject<HTMLInputElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`