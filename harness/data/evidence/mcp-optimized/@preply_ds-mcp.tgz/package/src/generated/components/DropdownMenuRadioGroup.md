---
name: DropdownMenuRadioGroup
import: import { DropdownMenuRadioGroup } from '@preply/ds-web-lib';
description: Dropdown menu radio group
---

# DropdownMenuRadioGroup

```
import { DropdownMenuRadioGroup } from '@preply/ds-web-lib';
```

Dropdown menu radio group

@example

```
<DropdownMenuRadioGroup defaultValue="1">
  <DropdownMenuRadioItem label="Item 1" value="1" />
  <DropdownMenuRadioItem label="Item 2" value="2" />
  <DropdownMenuRadioItem label="Item 3" value="3" />
</DropdownMenuRadioGroup>
```

## Props

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `disabled`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | undefined`

### `value`

- Type: `string | undefined`

### `onValueChange`

- Type: `((value: T) => void) | undefined`

### `items`

- Type: `DropdownMenuRadioItemProps<T>[] | undefined`

### `ref`

- Type: `((instance: HTMLDivElement | null) => void) | RefObject<HTMLDivElement> | null | undefined`
- Detailed type: `undefined | null | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`