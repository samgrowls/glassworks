---
name: LayoutGrid
import: import { LayoutGrid } from '@preply/ds-web-lib';
description: A CSS `grid` wrapper.
---

# LayoutGrid

```
import { LayoutGrid } from '@preply/ds-web-lib';
```

A CSS `grid` wrapper.

## Props

### `gap`

- Type: `Responsive<LayoutGap> | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | ResponsiveProp<LayoutGap>`

### `padding`

- Type: `Responsive<ShortHand<LayoutPadding>> | undefined`
- Detailed type: `undefined | "24" | "32" | "48" | "64" | "96" | "160" | "0" | "2" | "4" | "8" | "16" | "1" | "6" | "12" | "20" | [LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding] | [LayoutPadding, LayoutPadding, LayoutPadding, LayoutPadding] | ResponsiveProp<ShortHand<LayoutPadding>>`

### `columns`

- Type: `Responsive<number | string[]> | undefined`
- Detailed type: `undefined | number | string[] | ResponsiveProp<number | string[]>`

### `justifyContent`

- Type: `Responsive<LayoutJustifyContent> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "space-between" | "space-around" | "space-evenly" | ResponsiveProp<LayoutJustifyContent>`

### `alignItems`

- Type: `Responsive<LayoutAlignItems> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "stretch" | "baseline" | ResponsiveProp<LayoutAlignItems>`

### `justifyItems`

- Type: `Responsive<LayoutJustifyItems> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "stretch" | ResponsiveProp<LayoutJustifyItems>`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `hide`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `relative`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLElement | null) => void | RefObject<HTMLElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`