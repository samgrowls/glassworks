---
name: SingleSelectChips
import: import { SingleSelectChips } from '@preply/ds-web-lib';
description: >-
  A chips component that allows selection of a single option from a group.

  Users can select one chip at a time, and clicking a selected chip will
  deselect it.
---

# SingleSelectChips

```
import { SingleSelectChips } from '@preply/ds-web-lib';
```

A chips component that allows selection of a single option from a group.
Users can select one chip at a time, and clicking a selected chip will deselect it.

@remarks

**Keyboard interactions:**
- **Tab** to enter/exit the component (uses [roving tabindex pattern](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/#kbd_roving_tabindex))
- **Arrow keys** to navigate between chips within the group
- **Space/Enter** to select/deselect the focused chip

@example

````
```tsx
<SingleSelectChips aria-label="Choose a skill" defaultValue="vocabulary">
  <SingleSelectChipsItem value="vocabulary">Vocabulary</SingleSelectChipsItem>
  <SingleSelectChipsItem value="speaking">Speaking</SingleSelectChipsItem>
  <SingleSelectChipsItem value="listening">Listening</SingleSelectChipsItem>
</SingleSelectChips>
```
````

## Props

### `aria-label`

- Type: `string`
- Required

Accessible label for the chips group. Required for screen reader users

### `dataset`

- Type: `Dataset | undefined`

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`

### `defaultValue`

- Type: `string | null | undefined`

Default value for uncontrolled usage. Will be ignored if `value` is provided

### `aria-controls`

- Type: `string | undefined`

If the chips control other elements on the page, use `aria-controls` with the target element's ID.

### `value`

- Type: `string | null | undefined`

Current value of the chips. When provided, the component operates in controlled mode

### `onValueChange`

- Type: `((value: T | null) => void) | undefined`
- Detailed type: `undefined | (value: T | null) => void`

Callback fired when the value changes. Receives the new value as an argument

### `orientation`

- Type: `Orientation | undefined`
- Detailed type: `undefined | "horizontal" | "vertical"`
- Default value: `'horizontal'`

Layout orientation of the chips group.

### `items`

- Type: `(Omit<ChipsItemProps, "dsInternalSimulation" | "children" | "value"> & { value: T extends unknown[] ? NonNullable<T[number]> : NonNullable<T>; label: ReactNode; })[] | undefined`
- Detailed type: `undefined | (Omit<ChipsItemProps, "dsInternalSimulation" | "children" | "value"> & { value: T extends unknown[] ? NonNullable<T[number]> : NonNullable<T>; label: ReactNode; })[]`

### `ref`

- Type: `((instance: HTMLUListElement | null) => void) | RefObject<HTMLUListElement> | null | undefined`
- Detailed type: `undefined | null | (instance: HTMLUListElement | null) => void | RefObject<HTMLUListElement>`