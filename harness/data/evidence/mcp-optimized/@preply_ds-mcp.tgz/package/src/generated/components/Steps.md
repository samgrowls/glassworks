---
name: Steps
import: import { Steps } from '@preply/ds-web-lib';
description: >-
  This component allows users to navigate through a series of steps, providing

  a structured way to complete tasks or forms. It will also handle screen reader

  announcements and progress indicators.


  To create a step, wrap the content of each step in a `Steps.Step` component.

  Any non-`Steps.Step` children will be rendered outside of the steps flow,

  right after the currently active step.


  To navigate between steps, use the `Steps.Previous` and `Steps.Next`
  components.

  Alternatively, you can use the `StepsContext` directly to call

  `goToPreviousStep`, `goToNextStep`, or `goToStep`.
---

# Steps

```
import { Steps } from '@preply/ds-web-lib';
```

This component allows users to navigate through a series of steps, providing
a structured way to complete tasks or forms. It will also handle screen reader
announcements and progress indicators.

To create a step, wrap the content of each step in a `Steps.Step` component.
Any non-`Steps.Step` children will be rendered outside of the steps flow,
right after the currently active step.

To navigate between steps, use the `Steps.Previous` and `Steps.Next` components.
Alternatively, you can use the `StepsContext` directly to call
`goToPreviousStep`, `goToNextStep`, or `goToStep`.

@example

```
<Steps aria-label="Onboarding Steps" onStepChange={handleStepValidation}>
  <Steps.Step title="Subject" description="What do you want to learn?">
    <SubjectStep />
  </Steps.Step>
  <Steps.Step title="Availability" description="When would you like to have classes?">
    <AvailabilityStep />
  </Steps.Step>

  <LayoutFlex justifyContent="space-between">
    <Steps.Previous variant="tertiary">Back</Steps.Previous>
    <Steps.Next variant="primary">Continue</Steps.Next>
  </LayoutFlex>
</Steps>
```

## Props

### `aria-label`

- Type: `string`
- Required

A description of the step flow and its content for screen readers.

@example

```
'Onboarding Steps', 'Checkout Steps', 'Survey Steps', etc.
```

### `initialStep`

- Type: `number | undefined`
- Default value: `1`

The initial step to start at (from `1` to `children.length`).

### `onStepChange`

- Type: `((currentStep: number, nextStep: number) => number | Promise<number | undefined> | undefined) | undefined`
- Detailed type: `undefined | (currentStep: number, nextStep: number) => number | Promise<number | undefined> | undefined`

Optional callback to control navigation between steps.

This is triggered either by using the `Steps.Previous` and `Steps.Next`
components, or by calling `goToPreviousStep`, `goToNextStep`, or
`goToStep` from the `StepsContext`.

Can be used to:
- Skip/redirect steps conditionally
- Perform async process (e.g. validation) on step changes, marking the
  element as busy/loading

@param

currentStep The current step (1-based)
nextStep The next, incoming step

@returns

Promise that resolves to:
- `undefined`: proceed with default navigation
- `number`: override the destination step

@example

```
Add async validation
const handleStepChange = async (current, next) => {
await validateStep(current);
return next;
};
Skip a step
const handleStepChange = async (current, next) => {
if (next === 2) return 3; // Skip step 2
return next;
};
```

### `dataset`

- Type: `Dataset | undefined`