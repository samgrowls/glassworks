---
name: DialogCloseButton
import: import { DialogCloseButton } from '@preply/ds-web-lib';
description: |-
  The DialogCloseButton is a container which defaults to:
  1. Displaying an `IconButton` child with a `TokyoUIClose` icon, which can be
     overridden with the `children` prop.
  2. Being absolutely positioned at the top right corner of the dialog, which
     can be overridden with the `className` prop.
---

# DialogCloseButton

```
import { DialogCloseButton } from '@preply/ds-web-lib';
```

The DialogCloseButton is a container which defaults to:
1. Displaying an `IconButton` child with a `TokyoUIClose` icon, which can be
   overridden with the `children` prop.
2. Being absolutely positioned at the top right corner of the dialog, which
   can be overridden with the `className` prop.

@example

```
<DialogCloseButton className={myCustomPositioningStyle}>
  <MyCustomCloseButton />
</DialogCloseButton>

If you want the default button but need to pass your own props to it, you
can use the `DefaultCloseButton` wrapper component.
<DialogCloseButton>
    <DialogDefaultCloseButton
      variant="onColor"
      dataset={{ testid: 'close-button' }}
    />
</DialogCloseButton>
```

## Props

### `className`

- Type: `string | undefined`

### `ref`

- Type: `LegacyRef<HTMLButtonElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLButtonElement | null) => void | RefObject<HTMLButtonElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`