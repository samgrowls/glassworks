---
name: ToastProvider
import: import { ToastProvider } from '@preply/ds-web-lib';
description: |-
  Toasts can be triggered via the `showToast` function, and are rendered
  onto a root `Toaster` component, which is typically placed somewhere high
  up in an application tree.
---

# ToastProvider

```
import { ToastProvider } from '@preply/ds-web-lib';
```

Toasts can be triggered via the `showToast` function, and are rendered
onto a root `Toaster` component, which is typically placed somewhere high
up in an application tree.

@example

```
import { ToastProvider, showToast } from '@preply/ds-web-lib';
const MyApp = () => (
  <div id="root">
    <ToastProvider />
    <button onClick={() => showToast('Hello World!')}>
      Create Toast
    </button>
  </div>
);
```