---
name: DialogDescription
import: import { DialogDescription } from '@preply/ds-web-lib';
description: ""
---

# DialogDescription

```
import { DialogDescription } from '@preply/ds-web-lib';
```

## Props

### `defaultChecked`

- Type: `boolean | undefined`

### `defaultValue`

- Type: `string | number | readonly string[] | undefined`

### `suppressContentEditableWarning`

- Type: `boolean | undefined`

### `suppressHydrationWarning`

- Type: `boolean | undefined`

### `accessKey`

- Type: `string | undefined`

### `autoCapitalize`

- Type: `"off" | "none" | "on" | "sentences" | "words" | "characters" | (string & {}) | undefined`

### `autoFocus`

- Type: `boolean | undefined`

### `className`

- Type: `string | undefined`

### `contentEditable`

- Type: `Booleanish | "inherit" | "plaintext-only" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "inherit" | "plaintext-only"`

### `contextMenu`

- Type: `string | undefined`

### `dir`

- Type: `string | undefined`

### `draggable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `enterKeyHint`

- Type: `"enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined`

### `hidden`

- Type: `boolean | undefined`

### `id`

- Type: `string | undefined`

### `lang`

- Type: `string | undefined`

### `nonce`

- Type: `string | undefined`

### `slot`

- Type: `string | undefined`

### `spellCheck`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `style`

- Type: `CSSProperties | undefined`

### `tabIndex`

- Type: `number | undefined`

### `title`

- Type: `string | undefined`

### `translate`

- Type: `"yes" | "no" | undefined`

### `radioGroup`

- Type: `string | undefined`

### `role`

- Type: `AriaRole | undefined`
- Detailed type: `undefined | "none" | string & {} | "search" | "alert" | "alertdialog" | "application" | "article" | "banner" | "button" | "cell" | "checkbox" | "columnheader" | "combobox" | "complementary" | "contentinfo" | "definition" | "dialog" | "directory" | "document" | "feed" | "figure" | "form" | "grid" | "gridcell" | "group" | "heading" | "img" | "link" | "list" | "listbox" | "listitem" | "log" | "main" | "marquee" | "math" | "menu" | "menubar" | "menuitem" | "menuitemcheckbox" | "menuitemradio" | "navigation" | "note" | "option" | "presentation" | "progressbar" | "radio" | "radiogroup" | "region" | "row" | "rowgroup" | "rowheader" | "scrollbar" | "searchbox" | "separator" | "slider" | "spinbutton" | "status" | "switch" | "tab" | "table" | "tablist" | "tabpanel" | "term" | "textbox" | "timer" | "toolbar" | "tooltip" | "tree" | "treegrid" | "treeitem"`

### `about`

- Type: `string | undefined`

### `content`

- Type: `string | undefined`

### `datatype`

- Type: `string | undefined`

### `inlist`

- Type: `any`

### `prefix`

- Type: `string | undefined`

### `property`

- Type: `string | undefined`

### `rel`

- Type: `string | undefined`

### `resource`

- Type: `string | undefined`

### `rev`

- Type: `string | undefined`

### `typeof`

- Type: `string | undefined`

### `vocab`

- Type: `string | undefined`

### `autoCorrect`

- Type: `string | undefined`

### `autoSave`

- Type: `string | undefined`

### `color`

- Type: `string | undefined`

### `itemProp`

- Type: `string | undefined`

### `itemScope`

- Type: `boolean | undefined`

### `itemType`

- Type: `string | undefined`

### `itemID`

- Type: `string | undefined`

### `itemRef`

- Type: `string | undefined`

### `results`

- Type: `number | undefined`

### `security`

- Type: `string | undefined`

### `unselectable`

- Type: `"off" | "on" | undefined`

### `inputMode`

- Type: `"url" | "none" | "search" | "text" | "tel" | "email" | "numeric" | "decimal" | undefined`

Hints at the type of data that might be entered by the user while editing the element or its contents

@see

{@link https://html.spec.whatwg.org/multipage/interaction.html#input-modalities:-the-inputmode-attribute}

### `is`

- Type: `string | undefined`

Specify that a standard HTML element should behave like a defined custom built-in element

@see

{@link https://html.spec.whatwg.org/multipage/custom-elements.html#attr-is}

### `aria-activedescendant`

- Type: `string | undefined`

Identifies the currently active element when DOM focus is on a composite widget, textbox, group, or application.

### `aria-atomic`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether assistive technologies will present all, or only parts of, the changed region based on the change notifications defined by the aria-relevant attribute.

### `aria-autocomplete`

- Type: `"none" | "list" | "inline" | "both" | undefined`

Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be
presented if they are made.

### `aria-braillelabel`

- Type: `string | undefined`

Defines a string value that labels the current element, which is intended to be converted into Braille.

@see

aria-label.

### `aria-brailleroledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized abbreviated description for the role of an element, which is intended to be converted into Braille.

@see

aria-roledescription.

### `aria-busy`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

### `aria-checked`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "checked" state of checkboxes, radio buttons, and other widgets.

@see

aria-pressed
aria-selected.

### `aria-colcount`

- Type: `number | undefined`

Defines the total number of columns in a table, grid, or treegrid.

@see

aria-colindex.

### `aria-colindex`

- Type: `number | undefined`

Defines an element's column index or position with respect to the total number of columns within a table, grid, or treegrid.

@see

aria-colcount
aria-colspan.

### `aria-colindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-colindex.

@see

aria-rowindextext.

### `aria-colspan`

- Type: `number | undefined`

Defines the number of columns spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-colindex
aria-rowspan.

### `aria-controls`

- Type: `string | undefined`

Identifies the element (or elements) whose contents or presence are controlled by the current element.

@see

aria-owns.

### `aria-current`

- Type: `boolean | "true" | "false" | "page" | "step" | "location" | "date" | "time" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "page" | "step" | "location" | "date" | "time"`

Indicates the element that represents the current item within a container or set of related elements.

### `aria-describedby`

- Type: `string | undefined`

Identifies the element (or elements) that describes the object.

@see

aria-labelledby

### `aria-description`

- Type: `string | undefined`

Defines a string value that describes or annotates the current element.

@see

related aria-describedby.

### `aria-details`

- Type: `string | undefined`

Identifies the element that provides a detailed, extended description for the object.

@see

aria-describedby.

### `aria-disabled`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is perceivable but disabled, so it is not editable or otherwise operable.

@see

aria-hidden
aria-readonly.

### `aria-dropeffect`

- Type: `"none" | "link" | "copy" | "execute" | "move" | "popup" | undefined`

Indicates what functions can be performed when a dragged object is released on the drop target.

@deprecated

in ARIA 1.1

### `aria-errormessage`

- Type: `string | undefined`

Identifies the element that provides an error message for the object.

@see

aria-invalid
aria-describedby.

### `aria-expanded`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed.

### `aria-flowto`

- Type: `string | undefined`

Identifies the next element (or elements) in an alternate reading order of content which, at the user's discretion,
allows assistive technology to override the general default of reading in document source order.

### `aria-grabbed`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates an element's "grabbed" state in a drag-and-drop operation.

@deprecated

in ARIA 1.1

### `aria-haspopup`

- Type: `boolean | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "dialog" | "grid" | "listbox" | "menu" | "tree"`

Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an element.

### `aria-hidden`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether the element is exposed to an accessibility API.

@see

aria-disabled.

### `aria-invalid`

- Type: `boolean | "true" | "false" | "grammar" | "spelling" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "grammar" | "spelling"`

Indicates the entered value does not conform to the format expected by the application.

@see

aria-errormessage.

### `aria-keyshortcuts`

- Type: `string | undefined`

Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element.

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.

### `aria-labelledby`

- Type: `string | undefined`

Identifies the element (or elements) that labels the current element.

@see

aria-describedby.

### `aria-level`

- Type: `number | undefined`

Defines the hierarchical level of an element within a structure.

### `aria-live`

- Type: `"off" | "assertive" | "polite" | undefined`

Indicates that an element will be updated, and describes the types of updates the user agents, assistive technologies, and user can expect from the live region.

### `aria-modal`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether an element is modal when displayed.

### `aria-multiline`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates whether a text box accepts multiple lines of input or only a single line.

### `aria-multiselectable`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the user may select more than one item from the current selectable descendants.

### `aria-orientation`

- Type: `"horizontal" | "vertical" | undefined`

Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous.

### `aria-owns`

- Type: `string | undefined`

Identifies an element (or elements) in order to define a visual, functional, or contextual parent/child relationship
between DOM elements where the DOM hierarchy cannot be used to represent the relationship.

@see

aria-controls.

### `aria-placeholder`

- Type: `string | undefined`

Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value.
A hint could be a sample value or a brief description of the expected format.

### `aria-posinset`

- Type: `number | undefined`

Defines an element's number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-setsize.

### `aria-pressed`

- Type: `boolean | "true" | "false" | "mixed" | undefined`
- Detailed type: `undefined | false | true | "true" | "false" | "mixed"`

Indicates the current "pressed" state of toggle buttons.

@see

aria-checked
aria-selected.

### `aria-readonly`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that the element is not editable, but is otherwise operable.

@see

aria-disabled.

### `aria-relevant`

- Type: `"text" | "additions" | "additions removals" | "additions text" | "all" | "removals" | "removals additions" | "removals text" | "text additions" | "text removals" | undefined`

Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified.

@see

aria-atomic.

### `aria-required`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates that user input is required on the element before a form may be submitted.

### `aria-roledescription`

- Type: `string | undefined`

Defines a human-readable, author-localized description for the role of an element.

### `aria-rowcount`

- Type: `number | undefined`

Defines the total number of rows in a table, grid, or treegrid.

@see

aria-rowindex.

### `aria-rowindex`

- Type: `number | undefined`

Defines an element's row index or position with respect to the total number of rows within a table, grid, or treegrid.

@see

aria-rowcount
aria-rowspan.

### `aria-rowindextext`

- Type: `string | undefined`

Defines a human readable text alternative of aria-rowindex.

@see

aria-colindextext.

### `aria-rowspan`

- Type: `number | undefined`

Defines the number of rows spanned by a cell or gridcell within a table, grid, or treegrid.

@see

aria-rowindex
aria-colspan.

### `aria-selected`

- Type: `Booleanish | undefined`
- Detailed type: `undefined | false | true | "true" | "false"`

Indicates the current "selected" state of various widgets.

@see

aria-checked
aria-pressed.

### `aria-setsize`

- Type: `number | undefined`

Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM.

@see

aria-posinset.

### `aria-sort`

- Type: `"none" | "ascending" | "descending" | "other" | undefined`

Indicates if items in a table or grid are sorted in ascending or descending order.

### `aria-valuemax`

- Type: `number | undefined`

Defines the maximum allowed value for a range widget.

### `aria-valuemin`

- Type: `number | undefined`

Defines the minimum allowed value for a range widget.

### `aria-valuenow`

- Type: `number | undefined`

Defines the current value for a range widget.

@see

aria-valuetext.

### `aria-valuetext`

- Type: `string | undefined`

Defines the human readable text alternative of aria-valuenow for a range widget.

### `dangerouslySetInnerHTML`

- Type: `{ __html: string | TrustedHTML; } | undefined`
- Detailed type: `undefined | { __html: string | TrustedHTML; }`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onCopyCapture`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onCutCapture`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onPasteCapture`

- Type: `ClipboardEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionEnd`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionEndCapture`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionStart`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionStartCapture`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionUpdate`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onCompositionUpdateCapture`

- Type: `CompositionEventHandler<HTMLParagraphElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLParagraphElement> | undefined`

### `onFocusCapture`

- Type: `FocusEventHandler<HTMLParagraphElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLParagraphElement> | undefined`

### `onBlurCapture`

- Type: `FocusEventHandler<HTMLParagraphElement> | undefined`

### `onChange`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onChangeCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onBeforeInput`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onBeforeInputCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onInput`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onInputCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onReset`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onResetCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onSubmit`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onSubmitCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onInvalid`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onInvalidCapture`

- Type: `FormEventHandler<HTMLParagraphElement> | undefined`

### `onLoad`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onError`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onErrorCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

### `onKeyDownCapture`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

### `onKeyPress`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

@deprecated

Use `onKeyUp` or `onKeyDown` instead

### `onKeyPressCapture`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

@deprecated

Use `onKeyUpCapture` or `onKeyDownCapture` instead

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

### `onKeyUpCapture`

- Type: `KeyboardEventHandler<HTMLParagraphElement> | undefined`

### `onAbort`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onAbortCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onCanPlay`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onCanPlayCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onCanPlayThrough`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onCanPlayThroughCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onDurationChange`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onDurationChangeCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEmptied`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEmptiedCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEncrypted`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEncryptedCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEnded`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onEndedCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadedData`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadedDataCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadedMetadata`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadedMetadataCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadStart`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onLoadStartCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPause`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPauseCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPlay`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPlayCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPlaying`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onPlayingCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onProgress`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onProgressCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onRateChange`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onRateChangeCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onResize`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onResizeCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSeeked`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSeekedCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSeeking`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSeekingCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onStalled`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onStalledCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSuspend`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSuspendCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onTimeUpdate`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onTimeUpdateCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onVolumeChange`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onVolumeChangeCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onWaiting`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onWaitingCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onAuxClick`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onAuxClickCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onClick`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onClickCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onContextMenu`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onContextMenuCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onDoubleClick`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onDoubleClickCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onDrag`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragEnd`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragEndCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragEnter`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragEnterCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragExit`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragExitCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragLeave`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragLeaveCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragOver`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragOverCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragStart`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDragStartCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDrop`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onDropCapture`

- Type: `DragEventHandler<HTMLParagraphElement> | undefined`

### `onMouseDown`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseDownCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseEnter`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseLeave`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseMove`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseMoveCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseOut`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseOutCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseOver`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseOverCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseUp`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onMouseUpCapture`

- Type: `MouseEventHandler<HTMLParagraphElement> | undefined`

### `onSelect`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onSelectCapture`

- Type: `ReactEventHandler<HTMLParagraphElement> | undefined`

### `onTouchCancel`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchCancelCapture`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchEnd`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchEndCapture`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchMove`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchMoveCapture`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchStart`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onTouchStartCapture`

- Type: `TouchEventHandler<HTMLParagraphElement> | undefined`

### `onPointerDown`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerDownCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerMove`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerMoveCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerUp`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerUpCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerCancel`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerCancelCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerEnter`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerLeave`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerOver`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerOverCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerOut`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onPointerOutCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onGotPointerCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onGotPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onLostPointerCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onLostPointerCaptureCapture`

- Type: `PointerEventHandler<HTMLParagraphElement> | undefined`

### `onScroll`

- Type: `UIEventHandler<HTMLParagraphElement> | undefined`

### `onScrollCapture`

- Type: `UIEventHandler<HTMLParagraphElement> | undefined`

### `onWheel`

- Type: `WheelEventHandler<HTMLParagraphElement> | undefined`

### `onWheelCapture`

- Type: `WheelEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationStart`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationStartCapture`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationEnd`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationEndCapture`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationIteration`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onAnimationIterationCapture`

- Type: `AnimationEventHandler<HTMLParagraphElement> | undefined`

### `onTransitionEnd`

- Type: `TransitionEventHandler<HTMLParagraphElement> | undefined`

### `onTransitionEndCapture`

- Type: `TransitionEventHandler<HTMLParagraphElement> | undefined`

### `dataset`

- Type: `Dataset | undefined`

@deprecated

Pass data attributes as regular props instead

@example

```
<DialogDescription data-testid="dialog-description">...</DialogDescription>
```

### `ref`

- Type: `LegacyRef<HTMLDivElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLDivElement | null) => void | RefObject<HTMLDivElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`