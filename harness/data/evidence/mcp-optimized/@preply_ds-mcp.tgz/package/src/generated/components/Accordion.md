---
name: Accordion
import: import { Accordion } from '@preply/ds-web-lib';
description: |-
  An Accordion container.

  Add `AccordionItem` children to render a list of disclosable contents.
---

# Accordion

```
import { Accordion } from '@preply/ds-web-lib';
```

An Accordion container.

Add `AccordionItem` children to render a list of disclosable contents.

@example

```
<Accordion>
    <AccordionItem>
        <AccordionHeader>
            Is Preply the best platform for learning a language?
        </AccordionHeader>
        <AccordionContent>Of course it is!</AccordionContent>
    </AccordionItem>
    <AccordionItem>
        <AccordionHeader>Why?</AccordionHeader>
        <AccordionContent>
            If you are wondering, it means you have not tried it out yet!
        </AccordionContent>
    </AccordionItem>
</Accordion>
```

@see

AccordionItem *
AccordionHeader *
AccordionContent

## Props

### `dataset`

- Type: `Dataset | undefined`

Sets data attributes on the DOM element.

@example

```
<Accordion dataset={{ 'qa-id': 'benefits' }} /> // will add data-qa-id="benefits" to the HTML element.
```

### `id`

- Type: `string | undefined`

### `aria-label`

- Type: `string | undefined`

Defines a string value that labels the current element.

@see

aria-labelledby.