---
name: PasswordField
import: import { PasswordField } from '@preply/ds-web-lib';
description: ""
---

# PasswordField

```
import { PasswordField } from '@preply/ds-web-lib';
```

## Props

### `id`

- Type: `string | undefined`

The id to be passed to the input element.
If not provided, will be generated for accessibility purposes.

### `dataset`

- Type: `Dataset | undefined`

### `onClick`

- Type: `(MouseEventHandler<HTMLDivElement> & MouseEventHandler<HTMLInputElement>) | undefined`

### `description`

- Type: `ReactNode`

Additional descriptive text that appears below the input field
to provide more context or instructions to the user.

### `hideLabel`

- Type: `boolean | undefined`

Use this to hide the `label` visually, but keep it in the accessibility
tree.

### `required`

- Type: `boolean | undefined`

Indicates if the field is required. When false, adds a "Optional"
indicator next to the label.

### `hasError`

- Type: `boolean | undefined`

Whether the field has an error.

@deprecated

Use `error` prop to explicitly describe the error to users

### `label`

- Type: `ReactNode`
- Required

The field label. This is needed for accessibility purposes, but can be
hidden using the `hideLabel` prop.

### `error`

- Type: `ReactNode`

Error message to display when the field has an invalid value.

### `useLegacyRequiredLabel`

- Type: `boolean | undefined`

When true, adds a "Required" indicator next to the label for the required fields.
When false, adds a "Optional" indicator next to the label for the optional fields instead.

@deprecated

This is a temporary solution for gradual migration to the "Optional" label.

### `name`

- Type: `string | undefined`

### `onKeyDown`

- Type: `KeyboardEventHandler<HTMLInputElement> | undefined`

### `onKeyUp`

- Type: `KeyboardEventHandler<HTMLInputElement> | undefined`

### `disabled`

- Type: `boolean | undefined`

### `onCopy`

- Type: `ClipboardEventHandler<HTMLInputElement> | undefined`

### `onCut`

- Type: `ClipboardEventHandler<HTMLInputElement> | undefined`

### `onPaste`

- Type: `ClipboardEventHandler<HTMLInputElement> | undefined`

### `onFocus`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onBlur`

- Type: `FocusEventHandler<HTMLInputElement> | undefined`

### `onChange`

- Type: `ChangeEventHandler<HTMLInputElement> | undefined`

### `placeholder`

- Type: `string | undefined`

### `icon`

- Type: `ReactElement<any, string | JSXElementConstructor<any>> | undefined`
- Detailed type: `undefined | ReactElement<any, string | JSXElementConstructor<any>>`

### `onValueChange`

- Type: `((value: string) => void) | undefined`

### `readOnly`

- Type: `boolean | undefined`

### `maxLength`

- Type: `number | undefined`

### `value`

- Type: `string | undefined`

### `defaultValue`

- Type: `string | undefined`

### `autoComplete`

- Type: `"off" | "new-password" | "current-password" | undefined`

### `inputDataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLInputElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLInputElement | null) => void | RefObject<HTMLInputElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`