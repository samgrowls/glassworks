---
name: LayoutGridItem
import: import { LayoutGridItem } from '@preply/ds-web-lib';
description: ""
---

# LayoutGridItem

```
import { LayoutGridItem } from '@preply/ds-web-lib';
```

## Props

### `alignSelf`

- Type: `Responsive<LayoutAlignSelf> | undefined`
- Detailed type: `undefined | "center" | "start" | "end" | "stretch" | ResponsiveProp<LayoutAlignSelf>`

### `tag`

- Type: `LayoutTag | undefined`
- Detailed type: `undefined | "article" | "figure" | "main" | "table" | "p" | "div" | "span" | "header" | "footer" | "section" | "ul" | "ol" | "li" | "fieldset" | "th" | "tr" | "td" | "thead" | "tfoot" | "tbody" | "caption" | "figcaption"`

### `hide`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `relative`

- Type: `Responsive<boolean> | undefined`
- Detailed type: `undefined | false | true | ResponsiveProp<boolean>`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLElement | null) => void | RefObject<HTMLElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`