---
name: GlobalStyle
import: import { GlobalStyle } from '@preply/ds-web-root';
description: ""
---

# GlobalStyle

```
import { GlobalStyle } from '@preply/ds-web-root';
```