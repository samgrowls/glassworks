---
name: TextInline
import: import { TextInline } from '@preply/ds-web-lib';
description: ""
---

# TextInline

```
import { TextInline } from '@preply/ds-web-lib';
```

## Props

### `accent`

- Type: `TextAccent | undefined`
- Detailed type: `undefined | "primary" | "secondary" | "tertiary" | "critical" | "inverted" | "warning" | "positive" | "accentDark" | "placeholder" | "info"`

### `weight`

- Type: `TextWeight | undefined`
- Detailed type: `undefined | "medium" | "bold" | "normal"`
- Default value: `normal`

### `italic`

- Type: `boolean | undefined`
- Default value: `false`

### `tag`

- Type: `TextInlineTag | undefined`
- Detailed type: `undefined | "strong" | "span" | "em"`
- Default value: `span`

### `dataset`

- Type: `Dataset | undefined`

### `ref`

- Type: `LegacyRef<HTMLSpanElement> | undefined`
- Detailed type: `undefined | null | string | (instance: HTMLSpanElement | null) => void | RefObject<HTMLSpanElement>`

Allows getting a ref to the component instance.
Once the component unmounts, React will set `ref.current` to `null`
(or call the ref with `null` if you passed a callback ref).

@see

{@link https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom React Docs}

### `key`

- Type: `Key | null | undefined`
- Detailed type: `undefined | null | string | number | bigint`