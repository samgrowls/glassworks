import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import pkg from '../package.json' with { type: 'json' };
import { listComponents } from './tools/list-components';
import { getComponentDocs } from './tools/get-component-docs';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { searchTokenByName } from './tools/search-token-by-name';
import { searchTokenByValue } from './tools/search-token-by-value';
import { searchIcon } from './tools/search-icon';
import { logger } from './utils/logger';
import { identify } from './utils/event-tracking';

const server = new McpServer({
    name: 'ds-mcp',
    version: pkg.version,
});

server.registerTool(listComponents.name, listComponents.config, listComponents.callback);
server.registerTool(getComponentDocs.name, getComponentDocs.config, getComponentDocs.callback);
server.registerTool(searchTokenByName.name, searchTokenByName.config, searchTokenByName.callback);
server.registerTool(
    searchTokenByValue.name,
    searchTokenByValue.config,
    searchTokenByValue.callback,
);
server.registerTool(searchIcon.name, searchIcon.config, searchIcon.callback);

export async function startServer({ verbose }: { verbose?: boolean }) {
    if (verbose) {
        logger.level = 'debug';
    }

    const transport = new StdioServerTransport();

    await server.connect(transport);

    identify();
    logger.info('Server started');
}
