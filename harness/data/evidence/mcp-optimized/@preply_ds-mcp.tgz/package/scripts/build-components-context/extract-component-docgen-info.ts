/* eslint-disable import/no-named-as-default-member */
import path from 'path';
import ts from 'typescript';
import { ComponentDoc, withCompilerOptions } from 'react-docgen-typescript';
import { logger } from '#/utils/logger';

/** Follow aliases (`export {Foo} …`, `export * from …`, etc.) until we
 *  reach the symbol that is *actually* declared in some file. */
function resolveSymbol(symbol: ts.Symbol, checker: ts.TypeChecker): ts.Symbol {
    while (symbol.flags & ts.SymbolFlags.Alias) {
        const next = checker.getAliasedSymbol(symbol);
        if (next === symbol) break; // defensive – shouldn’t happen
        symbol = next;
    }
    return symbol;
}

/** Ask react-docgen-typescript for the doc block that belongs to `symbol`.
 *  If the declaration file contains several components we filter by name;
 *  otherwise we just take the single result react-docgen gives us. */
function getDocForSymbol(program: ts.Program, symbol: ts.Symbol, aliasName: string) {
    const decl = symbol.getDeclarations()?.[0];
    if (!decl) return null;

    const sourcePath = decl.getSourceFile().fileName;

    // create a parser *once* that re-uses the already built Program
    const parser = withCompilerOptions(program.getCompilerOptions(), {
        shouldExtractValuesFromUnion: true,
        shouldIncludePropTagMap: true,
    }).parseWithProgramProvider;

    // run react-docgen on the file that really holds the component
    const docs = parser.call(
        null,
        sourcePath,
        () => program, // give it our existing Program for speed + alias support
    );

    return docs.find(d => d.displayName === aliasName);
}

/**
 * Extracts the docgen info from the given entry file.
 *
 * @example
 * ```ts
 * const entry = path.resolve(__dirname, '../../web-lib/src/components/index.ts');
 * const docgenInfo = extractDocgenInfo(entry);
 * ```
 *
 * @param entry - Absolute path to the entry file to extract the docgen info from.
 * @returns {ComponentDoc[]} An array of docgen info objects.
 */
export function extractDocgenInfo(entry: string) {
    logger.info(`Extracting docgen info from ${entry}`);

    const configPath = ts.findConfigFile(
        path.dirname(path.resolve(entry)),
        ts.sys.fileExists,
        'tsconfig.json',
    );

    if (!configPath) {
        throw new Error('No tsconfig.json found');
    }

    const { config } = ts.readConfigFile(configPath, ts.sys.readFile);
    const { options, fileNames } = ts.parseJsonConfigFileContent(
        config,
        ts.sys,
        path.dirname(configPath),
    );

    const program = ts.createProgram({
        rootNames: fileNames,
        options,
    });

    const checker = program.getTypeChecker();
    const source = program.getSourceFile(entry);
    if (!source) {
        throw new Error(`Cannot load: ${entry}`);
    }

    const moduleSymbol = checker.getSymbolAtLocation(source);
    if (!moduleSymbol) {
        throw new Error(`No symbol information for: ${entry}`);
    }

    // walk ALL exports – this already includes those brought in via
    // “export * from …” and “export {Foo} from …”.
    const exportSymbols = checker.getExportsOfModule(moduleSymbol);

    const docs: ComponentDoc[] = [];

    logger.info(`Parsing ${exportSymbols.length} exports`);

    const failed: string[] = [];

    for (const exp of exportSymbols) {
        const aliasName = exp.getName();
        const realSym = resolveSymbol(exp, checker);

        // Skip TypeScript type-only exports (interfaces, type aliases, etc.).
        // React components exist at runtime, so they must have a Value flag.
        if ((realSym.flags & ts.SymbolFlags.Value) === 0) {
            continue;
        }
        const doc = getDocForSymbol(program, realSym, aliasName);

        if (doc) {
            // console.log(aliasName, realSym.flags);
            docs.push(doc);
        } else {
            // not a React component or couldn’t be parsed
            failed.push(aliasName);
        }
    }

    logger.info(`Parsed ${docs.length - failed.length} exports`);

    if (failed.length) {
        logger.error(`Failed to parse ${failed.length} exports:\n${failed.join('\n')}`);
    }

    return docs;
}
