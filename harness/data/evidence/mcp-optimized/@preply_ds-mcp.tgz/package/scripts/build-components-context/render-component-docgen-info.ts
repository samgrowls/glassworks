import { ComponentDoc, PropItem } from 'react-docgen-typescript';
import { md } from '#/utils/md';
import { logger } from '#/utils/logger';
import { Entry } from './types';

/**
 * Renders a single component's documentation into markdown format.
 *
 * @example
 * const buttonMarkdown = renderComponentDoc(buttonDocgenInfo);
 * // Returns:
 * // ## Button
 * //
 * // A clickable button component
 * //
 * // @example
 * //
 * // ```
 * // <Button onClick={handleClick}>Click me</Button>
 * // ```
 * //
 * // ### Button Props
 * //
 * // **onClick** (`(() => void) | undefined`)
 * //
 * // Callback fired when button is clicked
 */
export function renderComponentDoc(docgenInfo: ComponentDoc, entry: Entry) {
    const { displayName, description, tags, props } = docgenInfo;

    if (!description) {
        logger.debug(`${displayName} has no description`);
    }

    if (!tags?.example) {
        logger.debug(`${displayName} has no examples`);
    }

    const importExample = `import { ${displayName} } from '${entry.importPath}';`;

    return md.joinBlocks([
        md.frontMatter({
            name: displayName,
            import: importExample,
            description: description,
            deprecated: !!tags?.deprecated || undefined,
        }),
        md.heading(displayName),
        md.codeBlock(importExample),
        description,
        renderTags(tags),
        renderProps(displayName, props),
    ]);
}

/**
 * Renders JSDoc tags into markdown format, handling special cases like @example.
 *
 * @example
 * const tagsMarkdown = renderTags({ example: '<Button>Click me</Button>', since: 'v1.0' });
 * // Returns:
 * // @example
 * //
 * // ```
 * // <Button>Click me</Button>
 * // ```
 * //
 * // @since
 * //
 * // v1.0
 */
function renderTags(tags?: Record<string, string>, exclude: string[] = []) {
    if (!tags) return '';

    const blocks: string[] = [];

    for (const [key, value] of Object.entries(tags)) {
        if (['default', ...exclude].includes(key)) continue;

        blocks.push(`@${key}`);

        if (key === 'example') {
            blocks.push(md.codeBlock(value));
        } else {
            blocks.push(value);
        }
    }

    return md.joinBlocks(blocks);
}

/**
 * Renders component props documentation into markdown format.
 *
 * @example
 * const propsMarkdown = renderProps('Dialog', { open: propItem, size: propItem });
 * // Returns:
 * // ### Dialog Props
 * //
 * // **open** (`boolean`), required
 * //
 * // Controls the visibility of the dialog
 * //
 * // **size** (`Responsive<"xs" | "sm" | "md" | "lg"> | undefined` - `undefined | "xs" | "sm" | "md" | "lg" | ResponsiveProp<"xs" | "sm" | "md" | "lg">`), default: `md`
 * //
 * // Controls the width of the dialog on desktop and height on mobile
 */
function renderProps(displayName: string, props?: Record<string, PropItem>) {
    if (!props || Object.keys(props).length === 0) return '';

    const blocks = [md.heading('Props', { level: 2 })];

    for (const prop of Object.values(props)) {
        if (!prop.description) {
            logger.debug(`${displayName}.${prop.name} has no description`);
        }

        blocks.push(renderProp(prop));
    }

    return md.joinBlocks(blocks);
}

const IGNORE_UNWRAPPED_UNION_TYPES = ['ReactNode', 'boolean', 'boolean | undefined'];

function renderPropDataList(prop: PropItem) {
    const list: (string | undefined)[] = [];

    let type = prop.type.name;
    let detailedType: string | undefined = undefined;

    if (prop.type.name === 'enum') {
        type = prop.type.raw ?? 'unknown';

        const isIgnoreUnwrappedUnionType = IGNORE_UNWRAPPED_UNION_TYPES.includes(type);
        const isDuplicatesUnwrappedUnionType = type.split(' | ').length === prop.type.value.length;

        if (!isIgnoreUnwrappedUnionType && !isDuplicatesUnwrappedUnionType) {
            detailedType = prop.type.value.map((v: { value: string }) => v.value).join(' | ');
        }
    }

    list.push(
        `Type: ${md.code(type)}`,
        detailedType && `Detailed type: ${md.code(detailedType)}`,
        prop.defaultValue && `Default value: ${md.code(`${prop.defaultValue.value}` || '""')}`,
        prop.required ? 'Required' : undefined,
    );

    return md.list(list.filter((item): item is string => item !== undefined && item !== null));
}

function renderProp(prop: PropItem) {
    return md.joinBlocks([
        md.heading(md.code(prop.name), { level: 3 }),
        renderPropDataList(prop),
        prop.description,
        renderTags(prop.tags),
    ]);
}
