export type Entry = {
    importPath: string;
    entrypoint: string;
};
