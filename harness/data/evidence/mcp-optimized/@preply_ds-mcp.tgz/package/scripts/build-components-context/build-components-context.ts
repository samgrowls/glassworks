import path from 'path';
import { writeFile } from '#/utils/fs';
import { extractDocgenInfo } from './extract-component-docgen-info';
import { renderComponentDoc } from './render-component-docgen-info';
import { logger } from '#/utils/logger';
import { Entry } from './types';

/**
 * Scans the given entries and generates documentation for the components exported from them.
 *
 * @example
 * ```ts
 * await buildComponentsContext({
 *   entries: [
 *     {
 *       importPath: '@preply/ds-web-lib',
 *       entrypoint: path.resolve(root, '../web-lib/src/index.ts'),
 *     },
 *   ],
 *   outputDir: path.resolve(root, 'src/generated/components'),
 * });
 * ```
 */
export async function buildComponentsContext(params: { entries: Entry[]; outputDir: string }) {
    for (const entry of params.entries) {
        // Parse components documentation
        const docgenInfos = extractDocgenInfo(entry.entrypoint);
        for (const docgenInfo of docgenInfos) {
            // Render component documentation
            const componentDocs = renderComponentDoc(docgenInfo, entry);
            if (componentDocs) {
                writeFile(
                    path.join(params.outputDir, `${docgenInfo.displayName}.md`),
                    componentDocs,
                );
            }
        }
    }

    logger.info('Documentation generated successfully!');
}
