import path from 'node:path';
import { packageRoot } from '#/utils/fs';
import { buildComponentsContext } from './build-components-context/build-components-context';
import { buildTokensContext } from './build-tokens-context/build-tokens-context';
import { buildIconsContext } from './build-icons-context/build-icons-context';

const root = packageRoot();

await buildComponentsContext({
    entries: [
        {
            importPath: `@preply/ds-web-lib`,
            entrypoint: path.resolve(root, '../web-lib/src/index.ts'),
        },
        {
            importPath: `@preply/ds-web-lib/components/deprecated`,
            entrypoint: path.resolve(root, '../web-lib/src/components/deprecated/index.tsx'),
        },
        {
            importPath: `@preply/ds-web-root`,
            entrypoint: path.resolve(root, '../web-root/src/index.ts'),
        },
    ],
    outputDir: path.join(root, 'src/generated/components'),
});

await buildTokensContext({
    tokenTypesPath: path.resolve(root, '../../support/tools/data/tokens.json'),
    themePath: path.resolve(root, '../../support/tools/data/themes/tokyo-ui.json5'),
    outputPath: path.resolve(root, 'src/generated/tokens.json'),
});

await buildIconsContext({
    iconsDir: path.resolve(root, '../media-icons/svg/24'),
    outputPath: path.resolve(root, 'src/generated/icons.json'),
});
