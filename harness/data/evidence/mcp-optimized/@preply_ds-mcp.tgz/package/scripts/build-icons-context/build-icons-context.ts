import { listDirFiles, writeFile } from '#/utils/fs';
import { logger } from '#/utils/logger';

function stripTokyoUiPrefix(filename: string) {
    // Remove extension first
    const base = filename.replace(/\.svg$/i, '');
    return base.replace(/^TokyoUI/, '');
}

/**
 * Scans the given icons directory and generates a JSON list of icons.
 * Note that it only includes icons with the "TokyoUI" prefix.
 *
 * @example
 * ```ts
 * await buildIconsContext({
 *   iconsDir: path.resolve(root, '../media-icons/svg/24'),
 *   outputPath: path.resolve(root, 'src/generated/icons.json'),
 * });
 * ```
 */
export async function buildIconsContext(params: { iconsDir: string; outputPath: string }) {
    const files = listDirFiles(params.iconsDir)
        .filter(f => f.toLowerCase().endsWith('.svg'))
        .filter(f => /^TokyoUI/i.test(f))
        .map(stripTokyoUiPrefix);

    const names = Array.from(new Set(files));

    writeFile(params.outputPath, JSON.stringify(names, null, 2));

    logger.info('Icons generated successfully!');
}
