import { readJson, readJson5, writeFile } from '../../src/utils/fs';
import { logger } from '#/utils/logger';
import { z } from 'zod';

// prettier-ignore
const themeSchema = z.record(
    z.string(),
    z.union([
        z.string(),
        z.number(),
        z.object({
            base: z.union([
                z.string(),
                z.number(),
            ]),
        }),
    ]),
);
type Theme = z.infer<typeof themeSchema>;

// prettier-ignore
const tokenTypesSchema = z.record(
    z.string(),
    z.object({ type: z.string().optional() }),
);
type TokenTypes = z.infer<typeof tokenTypesSchema>;

/**
 * Copied from support/tools/src/tool/code-generator/models/functions/token-types.ts
 */
const units: Record<string, string> = {
    borderWidth: 'px',
    borderRadius: 'px',
    fontSize: 'px',
    letterSpacing: 'em',
    lineHeightPixels: 'px',
    gap: 'px',
    height: 'px',
    horizontalPadding: 'px',
    outlineOffset: 'px',
    outlineWidth: 'px',
    padding: 'px',
    size: 'px',
    space: 'px',
    verticalPadding: 'px',
};

const getTokenType = (name: string, tokenTypes: TokenTypes): string | undefined => {
    const nameParts = name.split('.');
    const matchingKeys = Object.keys(tokenTypes).filter(key => {
        const keyParts = key.split('.');
        if (keyParts.length !== nameParts.length) return false;
        return keyParts.every((part, index) => part === nameParts[index] || part === '*');
    });

    if (matchingKeys.length === 0) {
        return undefined;
    }

    if (matchingKeys.length > 1) {
        logger.warn(
            `Multiple matching token type keys found for ${name}:\n${matchingKeys.join('\n')}\n\nUsing ${matchingKeys[0]}`,
        );
    }

    return tokenTypes[matchingKeys[0]]?.type;
};

function getTokenValue(name: string, theme: Theme, tokenTypes: TokenTypes): string | number {
    let rawValue = theme[name];

    // If it's scheme aware token, use the base value
    if (typeof rawValue === 'object') {
        rawValue = rawValue.base;
    }

    // If it's a {reference}, extrapolate the value
    if (typeof rawValue === 'string' && rawValue.startsWith('{')) {
        return getTokenValue(rawValue.slice(1, -1), theme, tokenTypes);
    }

    const type = getTokenType(name, tokenTypes);
    if (type && units[type]) {
        return `${rawValue}${units[type]}`;
    }

    return rawValue;
}

const privateTokenPatterns = ['dsInternalPrimitive', 'root'];

/**
 * Generates tokens reference file using the given theme and token types.
 * ```json
 * {
 *    "gap.0": {"value": "0px", "private": false},
 *    "gap.4": {"value": "4px", "private": false},
 *    "gap.8": {"value": "8px", "private": false},
 *    "dsInternalPrimitive.color.background.0": {"value": "#000000", "private": true},
 *    ...
 * }
 * ```
 *
 * @example
 * ```ts
 * await buildTokensContext({
 *   tokenTypesPath: path.resolve(root, '../../support/tools/data/tokens.json'),
 *   themePath: path.resolve(root, '../../support/tools/data/themes/tokyo-ui.json5'),
 *   outputPath: path.resolve(root, 'src/generated/tokens.json'),
 * });
 * ```
 */
export async function buildTokensContext(params: {
    tokenTypesPath: string;
    themePath: string;
    outputPath: string;
}) {
    const theme = params.themePath.endsWith('.json5')
        ? readJson5(params.themePath, themeSchema)
        : readJson(params.themePath, themeSchema);
    const tokenTypes = readJson(params.tokenTypesPath, tokenTypesSchema);

    const output = Object.fromEntries(
        Object.keys(theme).map(name => [
            name,
            {
                value: getTokenValue(name, theme, tokenTypes),
                private: privateTokenPatterns.some(pattern => name.startsWith(pattern)),
            },
        ]),
    );
    writeFile(params.outputPath, JSON.stringify(output, null, 2));
    logger.info('Tokens generated successfully!');
}
